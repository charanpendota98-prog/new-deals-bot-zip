BESTGAA DEAL BOT - DEPLOY BUNDLE
=================================
Built 2026-09-06 from branch arena/01a07252-new-deals-bot-zip.
Every test green: 524 line-fidelity checks, 225 pipeline, 160 render-job,
plus duplicate/best-copy/rescan suites and the identity sync check.


HOW TO DEPLOY  (3 commands on the server)
-----------------------------------------
  cd /home/ubuntu/bestgaa-bot/bestgaa-bot
  unzip -o ~/bestgaa_deploy.zip
  bash deploy_bestgaa.sh

That is all. The script:
  * creates or reuses .env (secrets are never printed)
  * ADDS AMAZON_TAG_TARGETS=all if missing  <-- new this build
  * compiles the bot before touching anything
  * backs up the running main_bot.py (main_bot.backup.<timestamp>.py)
  * rolls back automatically if anything fails
  * verifies by sha256 that the live file IS the shipped file
  * restarts the service and prints its status

WhatsApp bridge (only if you also want to update it):
  cd /home/ubuntu/tg-wa-bridge
  unzip -o ~/bestgaa_deploy.zip 'tg-wa-bridge/*' -j -d .
  bash install_bridge.sh


BEFORE YOU RUN IT - check two lines in .env
-------------------------------------------
  grep AMAZON /home/ubuntu/bestgaa-bot/bestgaa-bot/.env

  AMAZON_TAG=mama086-21        <- must be your tag, or nothing earns
  AMAZON_TAG_TARGETS=all       <- added automatically if absent


WHAT CHANGED IN THIS BUILD
--------------------------
REVIEW CHANNEL (t.me/smartbuyhub11) - strict, and strict ONLY here:
  * ONE product per post, never a list. The choice is stable across
    retries, so a re-render can never publish a second item as a new deal.
  * Product name / Price / link / "#ad (paid link)". Nothing else.
  * No hype, no MRP, no percentages, no star ratings, no review counts,
    no coupon conditions, no emoji, no photos, no channel pointers.
  * Amazon only. Flipkart and other stores are refused here and keep
    going to the other channels.
  * Native amazon.in links - never hidden behind a shortener.
  * Daily cap 50, human pacing.

EVERY OTHER CHANNEL - unchanged, no conditions:
  * The source copy exactly as the source wrote it: hype, MRP,
    percentages, ratings, review counts, coupons, emoji, photos.
  * Verified byte-identical against the pre-session code on 12 real post
    shapes. The single intended difference is the list pairing below.

ALL CHANNELS:
  * Amazon products link as https://www.amazon.in/dp/ASIN?tag=mama086-21
    built natively, so the commission is yours instead of EarnKaro's.
  * Lists still use Bitly for non-Amazon stores; Amazon links never are.

DEFECTS FIXED THIS SESSION
  * "899 (MRP 2990)" published Rs.2,990 as the price - the MRP, not what
    the buyer pays. Price also drives routing and dedup.
  * "Rs.99 off" parsed as a price of 9 (regex backtracking).
  * "[Boat Airdopes 141](url)" lost the product name and posted a bare URL.
  * Lists written inline, or with links dumped at the bottom, were not
    paired - now every product sits above its own link.
  * One list could mix shortened and native links.
  * The review channel refused every post whose source used an amzn.to link.
  * Short branded names ("Cello Box", "Ergonomic Dustpan") had no dedup
    identity and could post twice in the same channel.
  * A stranger's Associates tag could reach the declared channel.
  * "Price: 99" with no product name was published as a listing.
  * A bitli.in link unfurled a "linkredirect.in / Shopsy" preview card.


AFTER DEPLOY - watch for 10 minutes
-----------------------------------
  sudo journalctl -u bestgaa -f
  # or: tail -f /home/ubuntu/bestgaa-bot/bestgaa-bot/logs/bot.log

Check three things:
  1. A review-channel post: ONE product, "Price: Rs...", "#ad (paid link)",
     and a native amazon.in link carrying tag=mama086-21.
  2. A loot-channel post: hype, MRP and ratings all still present.
  3. No repeating "EarnKaro failed" or "BITLY unavailable" lines.

IF SOMETHING IS WRONG - roll back in 20 seconds
  cd /home/ubuntu/bestgaa-bot/bestgaa-bot
  ls -t main_bot.backup.*.py | head -1        # newest backup
  cp -a main_bot.backup.<timestamp>.py main_bot.py
  sudo systemctl restart bestgaa


ONE THING CODE CANNOT DO FOR YOU
--------------------------------
Eight channels now send traffic carrying tag=mama086-21, but only
smartbuyhub11 and LootZoneIndia11 have been declared to Amazon. Amazon
identifies the traffic source FROM THE TAG - their reports show one
referrer per channel automatically. An undeclared channel carrying the
tag is the exact wording of the notice that closed the earlier account.

If Amazon ever queries it, list all eight (full URLs, public channels) at
  https://affiliate-program.amazon.in/home/account/profile/sitelist
The list is in ops/AMAZON_SITELIST_BEFORE_TAG_EVERYWHERE.txt.

To go back to the safe setting at any time, remove this line from .env
and redeploy - the tag then rides on the review channel only:
  AMAZON_TAG_TARGETS=all
