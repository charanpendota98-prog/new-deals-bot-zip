BESTGAA DEAL BOT + WHATSAPP BRIDGE — DEPLOY BUNDLE
=================================================

This one file carries everything the services need. Sizes and hashes are in
BUILD_INFO.txt and MANIFEST.sha256; nothing here was hand-copied.

BOT (3 commands on the server)
------------------------------
  cd /home/ubuntu/bestgaa-bot/bestgaa-bot
  unzip -o ~/bestgaa_deploy.zip
  bash deploy_bestgaa.sh

The script refuses a foreign AMAZON_TAG, backs up the running bot, compiles it,
rolls back on failure, verifies the live file by sha256, then restarts.

WHATSAPP BRIDGE (only if you want it updated too)
-------------------------------------------------
  cd /home/ubuntu/tg-wa-bridge
  unzip -o ~/bestgaa_deploy.zip 'tg-wa-bridge/*' -j -d .
  bash install_bridge.sh

tg-wa-bridge/safety_rules.json is the SAME policy file as the bot's, shipped
inside the bridge directory because the bridge reads the policy from its own
folder first.

VERIFY BEFORE YOU DEPLOY ANYTHING
---------------------------------
  unzip -o ~/bestgaa_deploy.zip -d /tmp/bundle_check
  cd /tmp/bundle_check && sha256sum -c MANIFEST.sha256
  python3 -c "import main_bot_new"      # imports deal_facts, safety_filter, ...

DASHBOARD
---------
Not in this zip: it runs from the repo checkout, so
  cd /home/ubuntu/bestgaa-bot/bestgaa-bot && git pull
  sudo systemctl restart bestgaa-dashboard

REBUILD THIS ZIP
----------------
  python3 ops/build_deploy_zip.py            # writes bestgaa_deploy.zip
  python3 ops/build_deploy_zip.py --check     # proves it matches the tree
  python3 test_deploy_zip.py                  # unpacks it and runs the bot offline
