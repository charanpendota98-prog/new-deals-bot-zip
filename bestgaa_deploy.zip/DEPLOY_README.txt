BESTGAA DEAL BOT - DEPLOY BUNDLE
=================================
Built 2026-09-06 from branch arena/01a076d9-new-deals-bot-zip.
Every test green: 597 line-fidelity checks, 225 pipeline, 160 render-job,
plus duplicate/best-copy/rescan suites, the identity sync check and the
bridge self-test.


HOW TO DEPLOY  (3 commands on the server)
-----------------------------------------
  cd /home/ubuntu/bestgaa-bot/bestgaa-bot
  unzip -o ~/bestgaa_deploy.zip
  bash deploy_bestgaa.sh

That is all. The script:
  * creates or reuses .env (secrets are never printed)
  * REFUSES a foreign AMAZON_TAG (only mama086-21 ships)  <-- new this build
  * ADDS AMAZON_TAG_TARGETS=all if missing
  * compiles the bot before touching anything
  * backs up the running main_bot.py (main_bot.backup.<timestamp>.py)
  * rolls back automatically if anything fails
  * verifies by sha256 that the live file IS the shipped file
  * restarts the service and prints its status

WhatsApp bridge (only if you also want to update it):
  cd /home/ubuntu/tg-wa-bridge
  unzip -o ~/bestgaa_deploy.zip 'tg-wa-bridge/*' -j -d .
  bash install_bridge.sh


BEFORE YOU RUN IT - check two lines in .env
-------------------------------------------
  grep AMAZON /home/ubuntu/bestgaa-bot/bestgaa-bot/.env

  AMAZON_TAG=mama086-21        <- must be your tag, or the deploy ABORTS
  AMAZON_TAG_TARGETS=all       <- added automatically if absent


WHAT CHANGED IN THIS BUILD
--------------------------
REVIEW CHANNEL (t.me/smartbuyhub11) - strict, and strict ONLY here:
  * ONE product per post, never a list. The choice is stable across
    retries, so a re-render can never publish a second item as a new deal.
  * Product name / Price / link / "#ad (paid link)". Nothing else.
  * No hype, no MRP, no percentages, no star ratings, no review counts,
    no coupon conditions, no emoji, no photos, no channel pointers.
  * Amazon only. Flipkart and other stores are refused here and keep
    going to the other channels.
  * Native amazon.in links - never hidden behind a shortener.
  * Daily cap 50, human pacing.

ALL CHANNELS:
  * Amazon PRODUCT links go out as https://www.amazon.in/dp/ASIN?tag=mama086-21,
    built natively, so the commission is yours instead of EarnKaro's.
  * Amazon SEARCH / hidden-keywords / browse-node links (/s?k=, /s?hidden-keywords=,
    /b?node=) now carry tag=mama086-21 natively too. EarnKaro has no campaign for
    a search page, so they earned zero before; the tag is self-proving now.
  * Lists still use Bitly for non-Amazon stores; tagged Amazon links never are.

DEFECTS FIXED THIS SESSION
  * A wrong AMAZON_TAG (e.g. a source's deals0911-21) could ride into every
    channel. The installer now ABORTS instead of shipping somebody else's tag.
  * indiadesire.com (a deal blog - "we do not sell any products") and
    amzn.urlgeni.us (URLgenius's Amazon app-deep-link domain) burned the whole
    retry budget and dropped the deal. They are non-shops, so the link is cut
    and the post still goes out - never re-queued.
  * Amazon search links went to EarnKaro, found no campaign, and earned zero.
    They now carry tag=mama086-21 natively.
  * Earlier: "899 (MRP 2990)" published Rs.2,990 as the price; "Rs.99 off"
    parsed as 9; markdown links lost the product name; inline lists were not
    paired; a stranger's tag could reach the declared channel; a bitli.in link
    unfurled a "linkredirect.in / Shopsy" preview card. All fixed.


AFTER DEPLOY - watch for 10 minutes
-----------------------------------
  sudo journalctl -u bestgaa -f
  # or: tail -f /home/ubuntu/bestgaa-bot/bestgaa-bot/logs/bot.log

Check three things:
  1. A review-channel post: ONE product, "Price: Rs...", "#ad (paid link)",
     and a native amazon.in link carrying tag=mama086-21.
  2. A loot-channel post: hype, MRP and ratings all still present.
  3. No repeating "EarnKaro failed" or "BITLY unavailable" lines, and no
     "affiliate conversion returned no link: indiadesire.com" retries.

IF SOMETHING IS WRONG - roll back in 20 seconds
  cd /home/ubuntu/bestgaa-bot/bestgaa-bot
  ls -t main_bot.backup.*.py | head -1        # newest backup
  cp -a main_bot.backup.<timestamp>.py main_bot.py
  sudo systemctl restart bestgaa


ONE THING CODE CANNOT DO FOR YOU
--------------------------------
Eight channels now send traffic carrying tag=mama086-21, but only
smartbuyhub11 and LootZoneIndia11 have been declared to Amazon. Amazon
identifies the traffic source FROM THE TAG - their reports show one
referrer per channel automatically. An undeclared channel carrying the
tag is the exact wording of the notice that closed the earlier account.

If Amazon ever queries it, list all eight (full URLs, public channels) at
  https://affiliate-program.amazon.in/home/account/profile/sitelist
The list is in ops/AMAZON_SITELIST_BEFORE_TAG_EVERYWHERE.txt.

To go back to the safe setting at any time, remove this line from .env
and redeploy - the tag then rides on the review channel only:
  AMAZON_TAG_TARGETS=all
