#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BestGAA Production Bot v19.0

Durable Telegram deal pipeline — "source lo post rattane, mana target lo
immediately, exactly once, clean":
- SQLite queue and delivery ledger (restart-safe), workers woken instantly on
  insert, dispatched newest-first with an age-out sweeper (never posts stale)
- concurrent resolve / convert / health-check / shorten per post with cached
  verdicts and hard time budgets, so one slow site cannot delay everything
- EarnKaro conversion with retry/cache/circuit breaker; an output on a redirect
  domain this build does not recognize is FOLLOWED and accepted only when its
  destination proves it is ours (a new network domain never costs a commission,
  and a stranger's link is still refused)
- a dead short link, an unresolvable destination or an oversized photo costs the post
  NOTHING: the offending link is cut and the deal goes out complete (never a retry-until-
  stale, never a skip)
- a link the network has no campaign for is never posted BARE when the merchant page
  itself accepts our publisher id (Flipkart/Myntra): affExtParam2 is stamped, the
  reader still reaches the product, and the click pays US instead of nobody
- an Amazon SHORT link (amzn.to/amzn.in/a.co) is a wrapper, never a destination: it is
  resolved to the long product page first, tagged with OUR Associates tag, and then
  shortened with our own shortener - the short code itself is never posted (gluing a
  tag onto someone else's short code opens THEIR page and pays nobody). A short link
  that will not resolve is cut from the post, never republished
- a source post with a photo and NO link is still a post: it goes out as written (deal
  terms required, nothing invented); a caption with no deal terms is not a deal and stays out
- the source's photos are posted the way the source posted them: a multi-photo album
  arrives as ONE album (the grid), and only the source's own links are ever replaced
- exactly one line of ours may sit above the deal - our own channel link, added on the
  way out so the stored copy stays the source's - and never a second one
- a post that reached the intake ALWAYS reaches the targets: a share button in
  the source text, a merchant page that 404s to our datacenter IP, or a coupon
  code glued to a price can veto nothing - they are cleaned or ignored, never a
  reason to retry a job until the deal expires
- strict generated-link-only output (source links are always replaced by ours;
  an unverified leftover link is repaired out instead of dropping the deal)
- best-copy selection: when several sources post the same product (exact merchant
  id) the queue publishes the STRONGER deal, as one row, with the displaced copy
  restored if the better one cannot render; a numeric fidelity gate drops prices
  or discounts the source never printed (never the post)
- zero artificial waiting on Telegram: channel fan-out is back-to-back and one
  merchant page probe is capped (a slow site can no longer hold a live deal)
- per-product 24-hour cross-source dedup (pinned; env override blocked),
  backed by a canonical (chat_key,msg_id) unique index so one source message
  can never queue twice
- same-price fallback for unidentified posts is OFF unless opted in
  (PRICE_DEDUP_SECONDS=0: a common price must never eat a real deal; set 3600
  to restore the 1-hour hold)
- dedup committed only after at least one target post succeeds
- Buy Now/entity/button URL support
- source promo / channel links / URL residue / dangling CTA labels stripped
- v17: a final outbound guard so a published post can never contain markdown
  debris ("[url](url)"), a shortener fragment glued to a price
  ("₹260tG7oChgiQuTgS25b"), an empty "()" or a corrupted link of our own
- v17: campaign fingerprint includes the prices, so products that share one
  banner line are no longer mistaken for duplicates of each other
- v17 legacy behavior (superseded by strict-all): a merchant pass-through could
  be posted after an affiliate miss. Current production rendering skips that
  item/post unless a verified owned link can be produced; outages fail closed.
- v17: an edited source post that never reached a target is re-queued
- long caption/message chunking
- Under-99 / Under-499 price routing: single deals are band-checked, a product
  LIST reaches both price channels whatever its item prices, bank/card offers fan
  out to core owned channels, and Premium keeps only the best-scored deals
- v19 category mirrors: confidence-scored multilingual product phrases route a
  deal to exactly one configured Footwear/Fashion/Electronics/Home & Kitchen/
  Beauty/Grocery Telegram target while keeping the Main feed; ambiguous roundups
  stay Main-only and new Amazon-tag channels require an explicit Associates allowlist
"""
from __future__ import annotations

import asyncio
import base64
import contextlib
import hashlib
import html
import json
import logging
import logging.handlers
import os
import random
import re
import signal
import sqlite3
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

# Price/discount/MRP reading lives in deal_facts so the card renderer, the
# dashboard's card studio and the routing all read one caption the same way.
try:
    from bestgaa.deal_facts import (parse_price, parse_discount,          # noqa: F401
                                    has_lowest_price_claim,
                                    premium_score, eligible_for_premium)
except ImportError:  # running as a plain script from inside bestgaa/
    from deal_facts import (parse_price, parse_discount,                  # noqa: F401
                            has_lowest_price_claim,
                            premium_score, eligible_for_premium)
# PUBLIC-CHANNEL CONTENT SAFETY (user rule 2026-10-19): our channels are public
# and read by women and families, so a source's adult / abusive / betting /
# "DM me" junk must never become OUR post. One policy file, shared with the
# WhatsApp bridge (tg-wa-bridge/safety_filter.js) so both surfaces agree.
try:
    from bestgaa.safety_filter import scan as safety_scan  # noqa: F401
except ImportError:  # running as a plain script from inside bestgaa/
    from safety_filter import scan as safety_scan  # noqa: F401
from urllib.parse import parse_qs, parse_qsl, unquote, urlencode, urlparse

import aiohttp
from telethon import TelegramClient, events, utils as tl_utils
from telethon.helpers import add_surrogate, del_surrogate
from telethon.errors import (
    ChannelPrivateError,
    ChatAdminRequiredError,
    FloodWaitError,
)
from telethon.tl.functions.messages import CheckChatInviteRequest
from telethon.tl.functions.channels import GetParticipantRequest
from telethon.tl.types import (
    MessageEntityTextUrl,
    MessageEntityUrl,
    MessageMediaInvoice,
    MessageMediaWebPage,
    ReplyInlineMarkup,
)

# The inline URL-button type was renamed in Telethon 1.45 (KeyboardButtonUrl ->
# KeyboardButton.button = InlineButtonTypeUrl). requirements.txt allows every
# 1.x, so a fresh `pip install -r requirements.txt` used to install a Telethon
# that made this module fail at IMPORT time - the bot could not even start. The
# symbol is therefore optional, and button URLs are read by SHAPE (below), which
# works on both generations of the library.
try:
    from telethon.tl.types import KeyboardButtonUrl  # type: ignore[attr-defined]
except ImportError:  # pragma: no cover - depends on the installed Telethon
    KeyboardButtonUrl = None  # type: ignore[assignment]


def button_url(button) -> str:
    """The URL an inline-keyboard button carries, on ANY Telethon version.

    Sources that paste their deal as a BUTTON (very common for private deal
    channels) put the link in the keyboard, not in the text. Telethon <1.45
    gives us a `KeyboardButtonUrl` with `.url`; from 1.45 the row holds a
    `KeyboardButton` whose `.button` is an `InlineButtonTypeUrl` with `.url`.
    Reading both shapes means such a post still yields its link instead of being
    skipped as "no URL in this message".
    """
    for candidate in (button, getattr(button, "button", None)):
        url = getattr(candidate, "url", "") or ""
        if isinstance(url, str) and url.startswith("http"):
            return url
    return ""

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
# BOT_LOG_DIR / BOT_MEDIA_DIR exist so a TOOL (a test suite, an audit, a deploy
# check) can import this module without writing logs/media into the source tree.
# 2026-10-04: the deploy imported the bot from a checkout, the checkout grew a
# logs/bot.log, and conversion_report then read those test lines as live data.
LOG_DIR = Path(os.getenv("BOT_LOG_DIR") or (BASE_DIR / "logs"))
LOG_DIR.mkdir(parents=True, exist_ok=True)
MEDIA_DIR = Path(os.getenv("BOT_MEDIA_DIR") or (BASE_DIR / "media"))
MEDIA_DIR.mkdir(parents=True, exist_ok=True)


def load_env_file(path: Path) -> None:
    """Load a simple KEY=VALUE file without overriding real environment vars."""
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip().strip('"').strip("'")
        if key:
            os.environ.setdefault(key, value)


load_env_file(BASE_DIR / ".env")
DB_PATH = Path(os.getenv("BOT_DB_PATH", str(BASE_DIR / "bestgaa.sqlite3")))
SESSION_PATH = str(BASE_DIR / os.getenv("TELEGRAM_SESSION", "bestgaa_fresh"))


def env_required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


API_ID = int(env_required("TELEGRAM_API_ID"))
API_HASH = env_required("TELEGRAM_API_HASH")
# MULTIPLE EarnKaro keys (comma-separated): tried in order, first = active, with
# failover on an authentication refusal. A key that pays a DIFFERENT publisher is
# dropped at startup - the publisher guard (OUR_EK_ID) exists precisely so that a
# published link never pays somebody else, and a failover must still pay us.
EK_KEYS = [x.strip() for x in env_required("EARNKARO_API_KEY").split(",") if x.strip()]
EK_KEY = EK_KEYS[0]
EK_ROTATION: dict[str, int] = {"index": 0, "rotations": 0}
EK_API = os.getenv("EARNKARO_API_URL", "https://ekaro-api.affiliaters.in/api/converter/public")
# A realistic desktop UA for outbound API/fetch calls. EarnKaro's endpoint sits
# behind Cloudflare, which rejects default library UAs with "error code: 1010".
API_USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
# The public converter accepts {"deal": <url or whole post>} plus an optional
# `convert_option`. "convert_only" is the documented value - convert the link(s)
# and NOTHING else: never post, never share, never apply an account-level
# default. It is sent on every call (it used to be omitted, which let the
# account default decide the RESPONSE SHAPE, and a shape we could not read is a
# lost commission).
EARNKARO_CONVERT_OPTION = os.getenv("EARNKARO_CONVERT_OPTION", "convert_only").strip() or "convert_only"


def earnkaro_token_claims(token: str) -> dict[str, Any]:
    """Decode the payload of an EarnKaro/Affiliaters API token.

    The token is a JWT whose payload names the account it earns for:
    `earnkaro` = the EarnKaro publisher id, `_id` = the Affiliaters account,
    `iat` = when it was issued. Reading it is what lets the bot (a) pin the
    publisher id `valid_generated()` uses to reject a converted link that pays
    SOMEBODY ELSE, and (b) say out loud at startup WHICH account is earning -
    instead of failing at every conversion with a silent 401.
    """
    try:
        parts = (token or "").split(".")
        if len(parts) < 2:
            return {}
        payload = parts[1]
        payload += "=" * (-len(payload) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload.encode("ascii")).decode("utf-8"))
        return claims if isinstance(claims, dict) else {}
    except Exception:
        return {}


EK_TOKEN_CLAIMS = earnkaro_token_claims(EK_KEY)
EK_TOKEN_PUBLISHER = str(EK_TOKEN_CLAIMS.get("earnkaro") or "").strip()
_env_ek_id = os.getenv("EARNKARO_PUBLISHER_ID", "").strip()
# The TOKEN is the truth: it is the credential the API answers to, so the
# publisher id it carries is the one every generated link will pay. The .env
# value is only a fallback (and a cross-check).
OUR_EK_ID = EK_TOKEN_PUBLISHER or _env_ek_id

if len(EK_KEYS) > 1:
    _kept = [EK_KEYS[0]]
    for _position, _candidate in enumerate(EK_KEYS[1:], 2):
        _candidate_publisher = str(
            earnkaro_token_claims(_candidate).get("earnkaro") or "").strip()
        if OUR_EK_ID and _candidate_publisher and _candidate_publisher != OUR_EK_ID:
            logging.getLogger("bestgaa").warning(
                "EARNKARO_API_KEY key %s pays publisher %s, not %s - dropped: a failover "
                "key must still pay OUR account", _position, _candidate_publisher, OUR_EK_ID)
            continue
        _kept.append(_candidate)
    if len(_kept) != len(EK_KEYS):
        EK_KEYS[:] = _kept
    logging.getLogger("bestgaa").info(
        "EarnKaro failover | %s key(s) for publisher %s; the bot rotates on an auth refusal",
        len(EK_KEYS), OUR_EK_ID or "unknown")


def ek_current_key() -> str:
    """The EarnKaro key in use right now (index 0 until one is refused)."""
    return EK_KEYS[EK_ROTATION["index"]]


def ek_rotate(reason: str) -> bool:
    """Move to the next key. True when a DIFFERENT key is now active."""
    if len(EK_KEYS) < 2:
        return False
    previous = EK_ROTATION["index"]
    EK_ROTATION["index"] = (previous + 1) % len(EK_KEYS)
    EK_ROTATION["rotations"] += 1
    logging.getLogger("bestgaa").warning(
        "EK ROTATE | key %s/%s refused (%s); now using key %s/%s",
        previous + 1, len(EK_KEYS), reason, EK_ROTATION["index"] + 1, len(EK_KEYS))
    return EK_ROTATION["index"] != previous
try:
    EK_TOKEN_ISSUED_AT = datetime.fromtimestamp(
        float(EK_TOKEN_CLAIMS.get("iat")), timezone.utc).strftime("%Y-%m-%d")
except (TypeError, ValueError, OverflowError, OSError):
    EK_TOKEN_ISSUED_AT = "unknown"
if EK_TOKEN_PUBLISHER:
    logging.getLogger("bestgaa").info(
        "EarnKaro token OK | publisher=%s (token issued %s) - every converted link pays this account",
        EK_TOKEN_PUBLISHER, EK_TOKEN_ISSUED_AT)
else:
    logging.getLogger("bestgaa").warning(
        "EARNKARO_API_KEY does not look like the EarnKaro/Affiliaters API token "
        "(a JWT carrying the 'earnkaro' publisher id). Conversion may answer 401/403; "
        "strict-all will skip any deal without a verified owned affiliate link. Get "
        "the token from the Affiliaters/EarnKaro API page and re-run ops/set_earnkaro_key.sh.")
if EK_TOKEN_PUBLISHER and _env_ek_id and EK_TOKEN_PUBLISHER != _env_ek_id:
    logging.getLogger("bestgaa").warning(
        "EARNKARO_PUBLISHER_ID=%s in .env disagrees with the token's publisher %s - "
        "the TOKEN wins (it is what the API answers to); fix the .env line so the "
        "foreign-publisher guard checks the right account",
        _env_ek_id, EK_TOKEN_PUBLISHER)
# USER RULE (2026-09-06): "kothaga thiskunna mama086-21 idi manade". The
# previously seen tag (deals0911-21) belonged to a SOURCE, so it was pinned
# empty to stop a stale .env re-enabling somebody else's tag. We now own
# mama086-21, so the tag is read from the environment again - but a tag that
# is not ours must still never come back, so any value is checked against the
# tags we actually own before it is used.
OUR_AMAZON_TAGS = {"mama086-21"}
_configured_tag = os.getenv("AMAZON_TAG", "").strip()
if _configured_tag and _configured_tag.lower() not in {t.lower() for t in OUR_AMAZON_TAGS}:
    # A source's tag in our .env would credit THEM for our sales and, worse,
    # put an undeclared tag on our channels. Refuse it loudly rather than post.
    logging.getLogger("bestgaa").warning(
        "AMAZON_TAG %r is not one of ours %s - ignoring it and posting tagless",
        _configured_tag, sorted(OUR_AMAZON_TAGS))
    _configured_tag = ""
OUR_TAG = _configured_tag
BITLY_TOKENS = [x.strip() for x in os.getenv("BITLY_TOKENS", "").split(",") if x.strip()]
# AMAZON POLICY, IN ORDER (history kept on purpose - each line was a user rule):
#   2026-09-03: Associates was rejecting the account, so native tagging paid
#               nothing and EVERY Amazon link went through EarnKaro. No ratio, no
#               env knob (a stale AMAZON_EARNKARO_RATIO= line in a server .env
#               can never re-enable that branch).
#   2026-09-24: EarnKaro-first stayed (Associates still refusing), with the
#               native ?tag= link as the FALLBACK.
#   2026-10-04: "amazin assacite approve chesindi manadi" - the Associates
#               account is APPROVED for OUR tag (mama086-21). The native tagged
#               link therefore pays the WHOLE commission to us with no network
#               share, so it becomes the FIRST choice and EarnKaro becomes the
#               second chance for a shape the native path cannot build.
#               AMAZON_DIRECT_ASSOCIATES=false restores the 2026-09-24 order.
AMAZON_EARNKARO_RATIO = 1.0  # kept only so external tooling reading it sees a value
AMAZON_VIA_EARNKARO = os.getenv(
    "AMAZON_VIA_EARNKARO", "true").strip().lower() not in ("0", "false", "no", "off")
AMAZON_DIRECT_ASSOCIATES = os.getenv(
    "AMAZON_DIRECT_ASSOCIATES", "true").strip().lower() not in ("0", "false", "no", "off")

# --- HYPD creator-store affiliate links (USER RULE 2026-09-24) -------------
# "hypd idi meesho products ni mana link tho convert cheyu ... paina links ni
# perefctga manam links ga chesi cheyu ... bitly tho shorten ga chesi cheyu,
# convert chesi shorten chesi"
#
# HYPD (hypd.store) is a creator-store platform: our store is 93944
# ("smartdeals") and every product we curate there gets a share link
#
#     https://hypd.store/<store>/afflink/<token>
#
# which redirects to the merchant page carrying HYPD's OWN affiliate
# attribution (affid=infhypd&affExtParam1=<account>&affExtParam2=<token>).
# Those links can carry our HYPD attribution - and the old pipeline destroyed
# it by resolving the redirect and stripping affid/affExtParam1/affExtParam2.
# Now only an owned share link with a verified Meesho destination qualifies:
#   * that HYPD link stays intact and is never sent to EarnKaro;
#   * it is Bitly-shortened when possible (the raw owned link is the outage fallback);
#   * the verified Meesho page is recorded, so a later bare Meesho link can use
#     the same mapping. Shopsy and unknown destinations are explicitly excluded.
# A hypd.store link belonging to ANOTHER store is somebody else's commission,
# so it is treated like any foreign affiliate wrapper (never republished).
HYPD_DOMAINS = {"hypd.store"}
HYPD_STORE_ID = os.getenv("HYPD_STORE_ID", "93944").strip().lstrip("@").lower()
HYPD_STORE_SLUG = os.getenv("HYPD_STORE_SLUG", "smartdeals").strip().lstrip("@").lower()
OUR_HYPD_STORES = {s for s in (HYPD_STORE_ID, HYPD_STORE_SLUG) if s}
HYPD_ALWAYS_BITLY = os.getenv(
    "HYPD_ALWAYS_BITLY", "true").strip().lower() not in ("0", "false", "no", "off")
# USER SCOPE: HYPD is enabled for Meesho ONLY and only for our configured store
# (93944 / smartdeals). Shopsy is deliberately excluded, even if an old .env
# still lists it; unsupported HYPD destinations are never reused or learned.
HYPD_MERCHANT_DOMAINS = {"meesho.com"}
HYPD_API_URL = os.getenv("HYPD_API_URL", "").strip()
HYPD_API_TOKEN = os.getenv("HYPD_API_TOKEN", "").strip()

PRODUCT_DEDUP_SECONDS = 24 * 3600  # STRICT 24h: same product never reposts within 24h — pinned, env override blocked (user rule 2026-09-04)
# v17.8 SAME PRODUCT, ONE CHANNEL, ONE TIME. `posted_deals` keys on a merchant
# product id, which is exact but blind while a short link has not been resolved
# yet - so the same earphones re-posted by a second source under a different
# bitli link used to reach LootZoneIndia11 twice. `product_signature()` below
# recognises the product from its own words instead, and the channel that has
# already carried it stays quiet for this window (0 turns the rule off). A
# strictly better copy of the product (cheaper or deeper discount) still posts.
SAME_PRODUCT_SKIP_SECONDS = 24 * 3600  # STRICT 24h: asalu ravoddu same product 24h — pinned (user rule 2026-09-04)
# How much deeper a discount has to be before a repeat of an already-posted
# product counts as news (percentage points).
try:
    SAME_PRODUCT_DISCOUNT_MARGIN = 15  # STRICT: only 15%+ better discount can override 24h (prevents 5% loophole spam)
except ValueError:
    SAME_PRODUCT_DISCOUNT_MARGIN = 5
# A cheaper repeat of an already-posted product is news only when the drop is
# real: a token one-rupee / rounding wobble between two captions of the same
# deal must not repost it (same-product-multiple-times, 2026-10-12).
SAME_PRODUCT_PRICE_DROP_FRACTION = 0.05
# USER RULE (2026-10-12): "1 hour lopala malli post cheyoddu" - inside this
# cool-down a same-product repeat is ALWAYS skipped, even a cheaper copy. The
# same deal races across sources within minutes wearing different captions and
# slightly different figures; most of that "better" is caption noise, not a new
# offer. Past the cool-down (but inside SAME_PRODUCT_SKIP_SECONDS) a genuinely
# better copy still posts; past the window anything posts.
SAME_PRODUCT_COOLDOWN_SECONDS = 3600
# Every product in a roundup participates in dedup; never truncate tail IDs.
# User rule (round 7, restated round 10): a post carries what the SOURCE wrote,
# and nothing we invent. Our own "join the loot family" footer and the folder
# link are therefore OFF by default; set ADD_OUR_CHANNEL_FOOTER=true to put them
# back on ordinary deal posts (the Tricks channel always keeps its footer).
ADD_OUR_CHANNEL_FOOTER = os.getenv("ADD_OUR_CHANNEL_FOOTER", "false").strip().lower() in ("1", "true", "yes", "on")
PRICE_DEDUP_SECONDS = max(0, int(os.getenv("PRICE_DEDUP_SECONDS", "0")))
# The one-hour same-price gate is a FALLBACK for posts with no product identity
# (no ASIN/PID). Set it to true to also block a different product that happens
# to carry an already-posted price — kept configurable because the strict
# version suppresses legitimate distinct deals ("source lo vasthe mana channel
# lo raavatam" is the primary rule).
PRICE_DEDUP_IGNORES_IDENTITY = os.getenv("PRICE_DEDUP_IGNORES_IDENTITY", "false").strip().lower() in {"1", "true", "yes", "on"}


def _num(name: str, fallback: float, low: float, high: float) -> float:
    """Read a numeric env var and clamp it into a safe range."""
    try:
        value = float(os.getenv(name, ""))
    except (TypeError, ValueError):
        value = fallback
    return min(high, max(low, value))


# --- Immediacy (USER RULE: "source lo post rattane target lo post avvali") ---
# The pipeline is event-driven end to end: a queued deal is woken up instantly
# (no idle polling delay), rendered with concurrent HTTP, and retried within
# seconds instead of minutes. Every knob below is clamped so a typo in .env can
# never turn the bot back into a slow/batched poster.
QUEUE_WORKERS = max(1, int(os.getenv("QUEUE_WORKERS", "8")))
QUEUE_IDLE_POLL_SECONDS = _num("QUEUE_IDLE_POLL_SECONDS", 0.5, 0.1, 10)
# Newest-first: a brand-new deal must never queue behind hours-old inventory
# (that is exactly what made posts look random/late). Old inventory drains by
# age-out instead of being posted stale.
QUEUE_ORDER = "newest" if os.getenv("QUEUE_ORDER", "newest").strip().lower() != "oldest" else "oldest"
# Stale loot is never posted: pending jobs older than this are dropped (logged),
# matching the "prices do not survive" trust policy instead of flushing them late.
MAX_JOB_AGE_HOURS = _num("MAX_JOB_AGE_HOURS", 6, 0.25, 72)
# Job-level retry backoff. The old 5*2**attempts (capped at 5 minutes) was the
# main cause of "the bot posts whenever it feels like it".
JOB_RETRY_BASE_SECONDS = _num("JOB_RETRY_BASE_SECONDS", 3, 1, 60)
JOB_RETRY_MAX_SECONDS = _num("JOB_RETRY_MAX_SECONDS", 20, 2, 300)
JOB_MAX_ATTEMPTS = max(3, int(os.getenv("JOB_MAX_ATTEMPTS", "10")))
# Strict monetization policy (user-confirmed): every published URL must be an
# affiliate destination we can verify earns for this account. Unsupported stores,
# service-offer URLs, dead/unknown shorteners, and plain merchant fallbacks are
# refused; a post with no verified owned link is skipped. This is pinned ON so a
# stale .env setting cannot silently re-enable source/unmonetized links.
STRICT_OUR_LINKS = True
# Retained only for the isolated legacy-formatting tests; production rendering
# ignores this opt-in whenever STRICT_OUR_LINKS is on.
PASSTHROUGH_UNMONETIZED = os.getenv("PASSTHROUGH_UNMONETIZED", "true").strip().lower() not in ("0", "false", "no", "off")

# SOURCE FIDELITY (the user's standing rule): publish what the source published,
# its own hype header included - "🔥🔥 TOP DEAL OF THE DAY 🔥🔥", "⚡️ 11 PM FLASH SALE ⚡️"
# are part of how that channel writes a deal, so they are NOT junk and stay. What
# IS removed: other-channel branding/signature, join/follow/share promo,
# referral & app-install farming, CTA filler, glued random tokens, markdown
# debris, URL residue - and every merchant/source link is swapped for OUR link.
# Set STRIP_CAMPAIGN_BANNERS=true only if you ever want those hype lines gone too.
STRIP_CAMPAIGN_BANNERS = os.getenv("STRIP_CAMPAIGN_BANNERS", "false").strip().lower() in ("1", "true", "yes", "on")
EK_MAX_CONCURRENCY = max(1, int(os.getenv("EK_MAX_CONCURRENCY", "8")))
POST_RETRIES = max(1, int(os.getenv("POST_RETRIES", "3")))
# (queue_id, target) pairs whose post is already OUT on Telegram but whose
# ledger record failed even after patient retries (SETTLE FAILED). The next
# pass retries ONLY the bookkeeping for these, never the send - re-sending an
# already-sent post is exactly the post-deploy repeat this guards against
# (2026-10-11, second hole: the settle writes after deliver() could still
# throw the job back into fail_job's requeue mill). Process-local: a crash
# loses it, and the crash window stays at-least-once like any Telegram send.
SETTLED_BUT_UNRECORDED: dict[tuple[int, str], dict] = {}
# Breathing room between ledger-write retries for an already-sent target, so a
# wedged database idles instead of hot-looping the claim/finish cycle.
UNRECORDED_SETTLE_RETRY_DELAY = 30.0
# Every outbound HTTP probe gets a real budget instead of the 18-30s default,
# and repeated probes of the same URL are cached, so one slow merchant site can
# no longer hold up the whole queue.
HTTP_TOTAL_TIMEOUT_SECONDS = _num("HTTP_TOTAL_TIMEOUT_SECONDS", 12, 3, 45)
LINK_CHECK_ATTEMPTS = max(1, int(os.getenv("LINK_CHECK_ATTEMPTS", "2")))
LINK_CHECK_RETRY_SLEEP_SECONDS = _num("LINK_CHECK_RETRY_SLEEP_SECONDS", 0.4, 0, 10)
LINK_HEALTH_CACHE_SECONDS = _num("LINK_HEALTH_CACHE_SECONDS", 900, 0, 86400)
# A service-outage verdict is NOT cached for the usual 15 minutes: the whole
# point of it is that the host was momentarily without a backend, and the retry
# a few seconds later must probe again instead of re-reading a stale "down".
LINK_OUTAGE_CACHE_SECONDS = _num("LINK_OUTAGE_CACHE_SECONDS", 45, 0, 3600)
PRESEND_CHECK_BUDGET_SECONDS = _num("PRESEND_CHECK_BUDGET_SECONDS", 6, 0, 240)
# The pre-send pass is the LAST chance to notice that a link died between render
# and delivery. A verdict seconds old is reused (immediacy: no second round trip
# for every post), but one older than this is re-probed, so a job that sat in the
# queue - or a merchant that went down after render - cannot ride a stale "alive"
# onto the channel. It stays concurrent and inside PRESEND_CHECK_BUDGET_SECONDS,
# and an exhausted budget still keeps the already-verified links (a slow probe is
# not a dead deal).
PRESEND_FRESH_SECONDS = _num("PRESEND_FRESH_SECONDS", 30, 0, 86400)
# USER RULE (2026-10-19): "10 time check perefctga convert then post". Every link
# in the final text is verified for POSTING - is it OURS, and does it open right
# now - up to this many times before the post is allowed out. The happy path
# costs exactly ONE pass (it stops at the first clean result); the retries only
# run while a link is still answering an outage or a dead page.
POST_VERIFY_ATTEMPTS = max(1, int(os.getenv("POST_VERIFY_ATTEMPTS", "10")))
POST_VERIFY_SLEEP_SECONDS = _num("POST_VERIFY_SLEEP_SECONDS", 2.0, 0, 60)
# Hard cap for ONE merchant page probe. Without it a slow site held the whole post
# for 2 x 12s (the single-link fast path had no budget at all) - which the user
# sees as "the bot posts late". A site that does not answer in time is
# inconclusive, not dead: the deal goes out.
LINK_PROBE_BUDGET_SECONDS = _num("LINK_PROBE_BUDGET_SECONDS", 3.5, 0.5, 60)
# A probe is allowed to make a post HONEST, never to make it disappear: DROP_DEAD_LINKS
# is therefore false by default (post with an unverified link) and only an operator who
# would rather lose the deal than risk a dead page turns it on.
DROP_DEAD_LINKS = os.getenv("DROP_DEAD_LINKS", "false").strip().lower() in ("1", "true", "yes", "on")
# USER RULE (2026-09-05): "asalu link yeh ledu" - a deal published with no link at
# all is useless to the reader and earns nothing, so a post whose every link died
# is skipped rather than sent as a linkless teaser. A source post that never had a
# link but DOES carry the product photo is unaffected (round 13's rule). Set
# REQUIRE_LINK_IN_POST=false to restore the old "post it anyway" behaviour.
REQUIRE_LINK_IN_POST = os.getenv(
    "REQUIRE_LINK_IN_POST", "true").strip().lower() not in ("0", "false", "no", "off")

# A huge source video must never freeze a worker; oversized/slow media is
# posted as text so the deal itself goes out on time.
MAX_MEDIA_MB = _num("MAX_MEDIA_MB", 45, 1, 2048)
# USER RULE (round 13): the source posts its photos as ONE album - a grid inside a
# single bubble - so our channel has to show the same grid, every photo in the source's
# order, and never only the first image. 10 is Telegram's own album ceiling.
MAX_ALBUM_PHOTOS = int(_num("MAX_ALBUM_PHOTOS", 10, 1, 10))
# USER RULE (round 13): one neat line at the TOP with our own channel link, so a reader
# on any of our channels can reach the rest of the family instead of wandering off to
# someone else's. It is the ONLY thing of ours that may sit above the deal text, it never
# appears twice, and the Tricks path (its own footer) is left exactly as it was.
ADD_OUR_CHANNEL_LINK_TOP = os.getenv(
    "ADD_OUR_CHANNEL_LINK_TOP", "false").strip().lower() in ("1", "true", "yes", "on")  # TAGLESS: default false – never auto-add our folder link
MEDIA_DOWNLOAD_TIMEOUT_SECONDS = _num("MEDIA_DOWNLOAD_TIMEOUT_SECONDS", 120, 5, 900)
SOURCE_REFRESH_SECONDS = _num("SOURCE_REFRESH_SECONDS", 180, 60, 3600)
# Dead-man's switch: re-scan every live source's recent messages on a short
# cycle so a silently dead event stream never loses deals until a restart.
SOURCE_RESCAN_SECONDS = _num("SOURCE_RESCAN_SECONDS", 120, 30, 3600)
SOURCE_RESCAN_LIMIT = max(5, int(os.getenv("SOURCE_RESCAN_LIMIT", "40")))
# How many sources are probed at once by the rescan cycle (a 20+ source list
# used to take minutes to walk serially, so a missed post could wait a long
# time before the next cycle found it).
SOURCE_RESCAN_CONCURRENCY = max(1, int(os.getenv("SOURCE_RESCAN_CONCURRENCY", "4")))
# Short random gap between the fan-out targets of ONE job (Telegram never waits
# for a human-like rhythm, this only spreads channel-to-channel delivery).
# USER RULE (restated in round 9): a source post must reach our channels the
# instant it arrives - so the fan-out gap DEFAULTS TO ZERO and the delivery loop
# does not sleep at all. The knobs stay for the rare case a target starts
# rate-limiting: set TARGET_FANOUT_GAP_MIN/MAX (seconds) to space the copies out.
TARGET_FANOUT_GAP_MIN = _num("TARGET_FANOUT_GAP_MIN", 0, 0, 30)
TARGET_FANOUT_GAP_MAX = max(TARGET_FANOUT_GAP_MIN, _num("TARGET_FANOUT_GAP_MAX", 0, 0, 60))
# Queue wake-up event, created in main(); workers stop on it instantly instead
# of only noticing new work at the end of their idle poll.
QUEUE_WAKE: asyncio.Event | None = None


def notify_queue() -> None:
    """Wake the idle workers the moment new work exists (best-effort)."""
    with contextlib.suppress(Exception):
        if QUEUE_WAKE is not None:
            QUEUE_WAKE.set()


def job_retry_delay(attempts: int) -> float:
    """Prompt, bounded retry backoff — never minutes for a hot deal."""
    delay = JOB_RETRY_BASE_SECONDS * (2 ** max(0, int(attempts)))
    return min(JOB_RETRY_MAX_SECONDS, max(1.0, delay)) + random.uniform(0, 1.5)


# Timestamp of the last ingested source event (live ingest health signal).
LAST_INGEST_AT = time.time()
BACKFILL_HOURS = max(0, int(os.getenv("BACKFILL_HOURS", "6")))
BACKFILL_LIMIT = max(0, int(os.getenv("BACKFILL_LIMIT", "50")))
STATE_RETENTION_DAYS = max(2, int(os.getenv("STATE_RETENTION_DAYS", "7")))
LINK_CACHE_DAYS = max(2, int(os.getenv("LINK_CACHE_DAYS", "14")))
MAINTENANCE_SECONDS = max(3600, int(os.getenv("MAINTENANCE_SECONDS", "21600")))
OZ_SOURCE = "https://t.me/+vZKuuHCZcX44M2I1"

UNDER99_TARGET = "Under99Deals11"
UNDER499_TARGET = "under499loots"
POWER_FILTER_TARGET = "PowerLoots1"
PREMIUM_TARGET = "Premiumlootsdeals"
SECRET_TARGET = "SecretLootIndia1"
TRICKS_TARGET = "LootzoneTricks"
# USER RULE (2026-09-05): the channel submitted for Amazon Associates review.
# It carries the same deals in a programme-safe form (product name, price,
# link - no loot/urgency wording, no "buy max quantity", no unverifiable claim).
# Defined here so routing and the safe-copy renderer share one name.
SHOPPING_TARGET = "smartbuyhub11"

# Optional product-category Telegram destinations. Every valid deal still reaches
# LootZoneIndia11; a confident product classification adds exactly one category
# target. The target values are Telegram usernames (with or without @), created
# by the operator and reachable by the Telethon session account.
CATEGORY_RULES_PATH = BASE_DIR / "category_rules.json"
try:
    CATEGORY_RULES = json.loads(CATEGORY_RULES_PATH.read_text(encoding="utf-8"))
except (OSError, json.JSONDecodeError) as exc:
    # A missing rules file must never stop the core feed; categories degrade to
    # main-feed-only and emit a visible startup warning.
    CATEGORY_RULES = {"version": 0, "min_score": 3, "min_margin": 2, "categories": []}
    logging.getLogger("bestgaa").warning(
        "CATEGORY ROUTING DISABLED | %s could not be loaded: %s", CATEGORY_RULES_PATH, exc)
CATEGORY_DEFINITIONS = {
    item["key"]: item for item in CATEGORY_RULES.get("categories", [])
    if isinstance(item, dict) and item.get("key")
}
CATEGORY_TARGETS = {
    key: os.getenv(f"TG_CATEGORY_{key.upper()}_TARGET", "").strip().lstrip("@")
    for key in CATEGORY_DEFINITIONS
}
_category_names: dict[str, list[str]] = {}
for _category_key, _category_target in CATEGORY_TARGETS.items():
    if _category_target:
        _category_names.setdefault(_category_target.strip().lower(), []).append(_category_key)
CATEGORY_TARGET_COLLISIONS = {
    target: tuple(categories) for target, categories in _category_names.items()
    if len(categories) > 1
}
for _target_name, _category_keys in CATEGORY_TARGET_COLLISIONS.items():
    for _category_key in _category_keys:
        CATEGORY_TARGETS[_category_key] = ""
AMAZON_TAG_CATEGORY_TARGETS = {
    value.strip().lstrip("@") for value in
    os.getenv("AMAZON_TAG_CATEGORY_TARGETS", "").split(",") if value.strip()
}
MAIN_TARGETS = [SECRET_TARGET, "LootZoneIndia11", TRICKS_TARGET, POWER_FILTER_TARGET]
NO_TRICKS_TARGETS = [SECRET_TARGET, "LootZoneIndia11", POWER_FILTER_TARGET]
LZI_SECRET = ["LootZoneIndia11", SECRET_TARGET]
TRICKS_SOURCES = {"TrickXpert", "Offerzone_deals", "offers_deals_xyz"}


def normalize_source_name(source: str) -> str:
    """One spelling per source, whatever shape it arrives in.

    A source key is a public username (`DealsUnder99_com`), an @-prefixed
    handle, or a PRIVATE INVITE LINK (`https://t.me/+O3j4ghbtJzhjZjJl`, whose
    hash carries uppercase characters). Preference/priority sets are matched
    against the queue's `source` column and the SQL side compares
    `lower(source)`, so the Python side must normalise exactly the same way -
    otherwise a first-preference source silently loses its turn (or, worse,
    is never recognised as preferred at all).
    """
    name = (source or "").strip()
    name = re.sub(r"[?#].*$", "", name).rstrip("/")   # drop ?query / trailing /
    return name.lstrip("@").lower()


def is_priority_source(source: str) -> bool:
    """True when a queue job came from a first-preference source."""
    return normalize_source_name(source) in PRIORITY_SOURCES


# USER RULE (2026-09-24): "e three channel source ga pettu 1st preference
# ivvu" - three more channels (all private invite links) join the feed as
# FIRST-PREFERENCE sources. Their posts are claimed from the queue ahead of
# every other source AND carry the +1 priority boost, so on every non-Tricks
# channel an equivalent deal from one of them is rendered and delivered first.
FIRST_PREFERENCE_SOURCES = (
    "https://t.me/+O3j4ghbtJzhjZjJl",
    "https://t.me/+8KzU3P58MJ9jN2M1",
    "https://t.me/+6LA1ljXGlbNmMjA1",
)
# Sources the user wants posted FIRST on every non-Tricks channel. Their queue
# jobs get a +1 priority boost (capped at the top tier) so an equivalent deal
# from one of these sources renders/delivers ahead of the same tier from any
# other source. "pricehistory" = user's explicit first-preference source.
PRIORITY_SOURCES = {"pricehistory"}
# USER RULE (2026-09-04): t.me/under_99_loot_deals is the FIRST-PREFERENCE
# source for the price channels - its posts go out ahead of the same tier from
# any other source; the rest follow when it has nothing new.
PRIORITY_SOURCES.add("under_99_loot_deals")
# The three new channels are first preference too (normalised, because an
# invite hash is case-sensitive to Telegram but not to the queue lookup).
PRIORITY_SOURCES.update(normalize_source_name(s) for s in FIRST_PREFERENCE_SOURCES)
OUR_FOLDER_LINK = "https://t.me/addlist/5V7_ViAGDxAwNTI1"
# Core owned channels used by card/service wide fan-out. Category targets are
# deliberately excluded here: the classifier adds only one matched shelf so a
# bank/card deal is never copied indiscriminately to every category.
# USER RULE (2026-09-06): the user added the new channel's own link as a
# SOURCE. A channel that is both a source and a target feeds its own posts back
# into the queue: the bot would re-read what it just published, re-shorten the
# link, and post it again - the exact "multiple times" the user wants gone. Any
# channel we OWN is therefore never accepted as a source of deals.
def is_own_channel_source(source: str) -> bool:
    """True when a queue job came from a channel we publish to ourselves."""
    name = (source or "").strip().lstrip("@").lower()
    if not name:
        return False
    owned = {SHOPPING_TARGET, SECRET_TARGET, "LootZoneIndia11", TRICKS_TARGET,
             POWER_FILTER_TARGET, PREMIUM_TARGET, UNDER99_TARGET, UNDER499_TARGET,
             *CATEGORY_TARGETS.values()}
    owned.update(t for targets in globals().get("SOURCE_TO_TARGETS", {}).values() for t in targets)
    return name in {t.lower() for t in owned if t}


ALL_OWNED_TARGETS = list(dict.fromkeys(
    [SECRET_TARGET, "LootZoneIndia11", POWER_FILTER_TARGET, PREMIUM_TARGET,
     UNDER99_TARGET, UNDER499_TARGET, TRICKS_TARGET]
))
# The shopping channel takes PRODUCT deals only: a trick/recharge/app-promo post
# is not a shoppable product and must never be shown to a marketplace reviewer.
# Set SHOPPING_TARGET_ENABLED=false to hold the channel back entirely.
SHOPPING_TARGET_ENABLED = os.getenv(
    "SHOPPING_TARGET_ENABLED", "true").strip().lower() not in ("0", "false", "no", "off")
# AMAZON ASSOCIATES COMPLIANCE (2026-09-05).
# Amazon's Operating Agreement requires that EVERY site/channel carrying your
# Associates links is declared in Associates Central, and explicitly warns that
# links appearing on undeclared channels can close the account. So the tag must
# NOT simply appear everywhere the moment AMAZON_TAG is set: it is restricted to
# the channels actually declared to Amazon. Every other channel keeps posting the
# same deal with an untagged (or EarnKaro) link - no deal is lost, the account is
# not exposed. Comma-separated usernames; defaults to the review channel only.
# USER RULE (2026-09-06): "tag ni anni channels lo use cheyu okavela approve
# vasthadi" - once the account is approved, earn on every channel, not just one.
# Amazon's own rule is that a channel carrying the tag must be DECLARED in
# Associates Central. Both can be true at once, so this is one switch:
#
#   AMAZON_TAG_TARGETS=all   -> tag on the core owned channels only. Use this
#                               only AFTER those channels are listed in
#                               Associates Central. New category mirrors are
#                               excluded until explicitly declared and listed in
#                               AMAZON_TAG_CATEGORY_TARGETS.
#   (unset)                  -> tag on the review channel only (safe default,
#                               correct while the application is pending).
#   a,b,c                    -> exactly those channels.
def normalize_channel_target_name(value: str) -> str:
    """Compare public Telegram handles consistently (case and @ do not matter)."""
    return str(value or "").strip().lstrip("@").lower()


_tag_targets_env = os.getenv("AMAZON_TAG_TARGETS", "").strip()
# Newly-created category channels are deliberately NOT swept in by `all`:
# Amazon Associates requires every tagged channel to be declared first. Add
# their exact Telegram usernames to AMAZON_TAG_CATEGORY_TARGETS only after the
# channels have been added to the Associates site list.
if _tag_targets_env.lower() in ("all", "*"):
    AMAZON_TAG_TARGETS = {SHOPPING_TARGET, *ALL_OWNED_TARGETS,
                          *AMAZON_TAG_CATEGORY_TARGETS}
elif _tag_targets_env:
    AMAZON_TAG_TARGETS = {
        *(t.strip().lstrip("@") for t in _tag_targets_env.split(",") if t.strip()),
        *AMAZON_TAG_CATEGORY_TARGETS,
    }
else:
    AMAZON_TAG_TARGETS = {SHOPPING_TARGET, *AMAZON_TAG_CATEGORY_TARGETS}
AMAZON_TAG_TARGET_KEYS = {normalize_channel_target_name(t) for t in AMAZON_TAG_TARGETS}
# --- Review-channel posting policy (t.me/smartbuyhub11) ---------------------
# USER RULE (2026-09-05): "daily 20-30 posts, Amazon vi veyu, reject cheyakunda".
# Three programme rules decide what this channel may publish:
#
#  1. LINK-LEVEL DISCLOSURE. Amazon/FTC require a clear disclosure NEXT TO the
#     link on every post - the channel bio alone is not enough. Amazon names
#     "(paid link)", "#ad" and "#CommissionsEarned" as acceptable. Missing this
#     is one of the most common rejection reasons, so it is appended to every
#     post automatically and can never be forgotten.
#  2. AMAZON ONLY. The channel is submitted for the AMAZON programme, so it
#     carries Amazon deals only; a Flipkart/Myntra link on the reviewed channel
#     is off-programme noise. Other stores keep going to the other channels.
#  3. A DAILY CAP. 20-30 quality posts a day reads like a curated shop; a
#     200-post firehose reads like spam and is a rejection risk.
SHOPPING_DISCLOSURE = os.getenv("SHOPPING_DISCLOSURE", "#ad (paid link)").strip()
SHOPPING_AMAZON_ONLY = os.getenv(
    "SHOPPING_AMAZON_ONLY", "true").strip().lower() not in ("0", "false", "no", "off")
SHOPPING_DAILY_CAP = max(0, int(os.getenv("SHOPPING_DAILY_CAP", "50")))
# 7. NO SHORTENER ON THE REVIEWED CHANNEL. USER RULE (2026-09-06): "review
#    channelo shorten ga marchatam bitly use cheyaku". A bit.ly/is.gd hop hides
#    where the link goes; the reviewer must see the store domain in the post.
#    Amazon product links are already collapsed natively to
#    https://www.amazon.in/dp/ASIN?tag=... (~48 chars), so this costs no
#    neatness. Every other channel keeps using the shortener as before.
# 8. HUMAN PACING. USER RULE (2026-09-06): "oka human laga daily oka 50 posts".
#    A burst of 50 posts at 3am reads as an automated feed; the same 50 spread
#    across the day reads as a person curating a shop. Posts are spaced across
#    an active window with jitter, so the timing is never machine-regular.
SHOPPING_HUMAN_PACING = os.getenv(
    "SHOPPING_HUMAN_PACING", "true").strip().lower() not in ("0", "false", "no", "off")
SHOPPING_ACTIVE_START = max(0, min(23, int(os.getenv("SHOPPING_ACTIVE_START", "8"))))
SHOPPING_ACTIVE_END = max(1, min(24, int(os.getenv("SHOPPING_ACTIVE_END", "23"))))
SHOPPING_NATIVE_LINKS = os.getenv(
    "SHOPPING_NATIVE_LINKS", "true").strip().lower() not in ("0", "false", "no", "off")
# 4. NO IMAGES. The 2026-09-06 rejection cited "images (screenshots/screen
#    recordings)" of Amazon. A forwarded deal photo is almost always an Amazon
#    product-page screenshot, which is exactly the trademarked use that gets an
#    application killed. The review channel therefore posts TEXT ONLY; every
#    other channel keeps its media untouched.
SHOPPING_TEXT_ONLY = os.getenv(
    "SHOPPING_TEXT_ONLY", "true").strip().lower() not in ("0", "false", "no", "off")
# 5. NO AMAZON TRADEMARKS IN THE COPY. Verbatim rejection reason (2026-09-06):
#    "unapproved use of Amazon trademarked words, images ... or reviews (which
#    may include variations or misspellings)". Writing "Amazon", "Prime",
#    "Great Indian Festival" etc. in the post body is an unlicensed use of the
#    mark. LINKING to amazon.in is fine and stays; naming it in the text does
#    not. A post that needs the word is simply not shown to the reviewer - it
#    still goes to every other channel unchanged.
_AMAZON_MARK_RE = re.compile(
    r"(?i)(?:\bam[ae]z[o0]?n\w*|\bamzn?\b|\bamz\b|\bprime\s*(?:day|deals?|sale|member\w*|video|music)\b"
    r"|\bgreat\s+indian\s+festival\b|\bgif\s+sale\b|\balexa\b|\bkindle\b|\becho\s*(?:dot|show)?\b"
    r"|\bfire\s*(?:tv|stick)\b|\baudible\b|\bamazon\s*basics\b|\bamazonbasics\b"
    r"|\bab\s*deals?\b|\bmini\s*tv\b|\bpantry\b|\bsubscribe\s*&?\s*save\b)")
# 6. NO POINTERS TO THE LOOT CHANNELS. The rejection email named
#    "https://t.me/LootZoneIndia11" as its worked example, so a reviewer who
#    finds any route from this channel to a loot channel fails the whole
#    application. Nothing on t.me may survive into the review copy.
_TELEGRAM_POINTER_RE = re.compile(
    r"(?i)(?:https?://)?(?:t\.me|telegram\.(?:me|dog))/\S+|@[A-Za-z]\w{3,}"
    # A pointer does not need a handle to be a pointer. "Join our channel for
    # more", "follow the group", "more deals in our channel" all route the
    # reviewer somewhere else, which is the thing the rejection email named.
    r"|\b(?:join|follow|subscribe|check)\b[^\n]{0,30}?"
    r"\b(?:channel|group|telegram|whatsapp)\b"
    r"|\b(?:channel|group)\b[^\n]{0,20}?\b(?:link|below|above|here)\b"
    r"|\bmore\s+(?:deals?|loots?|offers?)\b[^\n]{0,20}?"
    r"\b(?:channel|group|here|below)\b")


def has_amazon_trademark(text: str) -> bool:
    """True when the COPY names an Amazon mark (links are exempt and fine)."""
    return bool(_AMAZON_MARK_RE.search(URL_RE.sub(" ", text or "")))


def has_telegram_pointer(text: str) -> bool:
    """True when the copy points at another Telegram channel (our loot ones)."""
    return bool(_TELEGRAM_POINTER_RE.search(text or ""))


def add_link_disclosure(text: str) -> str:
    """Append the link-level affiliate disclosure exactly once."""
    body = (text or "").strip()
    if not body or not SHOPPING_DISCLOSURE:
        return body
    # Already disclosed (any of the accepted forms)? Never say it twice.
    if re.search(r"(?i)#ad\b|\bpaid link\b|#commissionsearned\b|"
                 r"amazon associate i earn", body):
        return body
    return f"{body}\n\n{SHOPPING_DISCLOSURE}"


def retag_foreign_amazon_links(text: str) -> str:
    """Put OUR Associates tag on every Amazon link, replacing any other.

    Used for the DECLARED channel only. Three cases, one rule:
      * a stranger's tag -> replaced with ours (that link would otherwise pay a
        third party from the one property we are allowed to earn on);
      * NO tag at all     -> ours is added. A link that skipped the tagging pass
        earns nothing, and an untagged post on the reviewed channel is a sale
        Amazon cannot attribute to us - the 3-qualifying-sales clock never moves;
      * already ours       -> untouched.
    Only the `tag` parameter changes, so the product and the price are intact.
    """
    out = text or ""
    if not OUR_TAG:
        return out
    for raw in dict.fromkeys(URL_RE.findall(out)):
        url = clean_url(raw)
        host = (urlparse(url).hostname or "").lower()
        if not in_domains(host, AMAZON_DOMAINS):
            continue
        parsed = urlparse(url)
        pairs = parse_qsl(parsed.query, keep_blank_values=True)
        tag = next((v for k, v in pairs if k.lower() == "tag"), "")
        if tag.lower() == OUR_TAG.lower():
            continue
        query = [(k, v) for k, v in pairs if k.lower() != "tag"]
        query.append(("tag", OUR_TAG))
        fixed = parsed._replace(query=urlencode(query, doseq=True)).geturl()
        out = out.replace(raw, fixed)
    return out


# Amazon's own short domains. They ARE Amazon links, but they are not in
# AMAZON_DOMAINS (which is the list used for tagging, where only a full
# amazon.in URL can carry a tag). Judging "is this an Amazon post?" by that
# list alone refused every post whose source used an amzn.to link.
AMAZON_SHORT_DOMAINS = frozenset({"amzn.to", "amzn.eu", "amzn.in", "a.co",
                                  # "link.amazon/<code>" is the same kind of
                                  # wrapper (2026-10-20: a Samsung QLED post used
                                  # it). Without this it was neither recognised as
                                  # Amazon nor cut/repaired, so an unresolved
                                  # wrapper could reach the channel - and the
                                  # strict gate accepted an Amazon output on it
                                  # as "ours" because the host looked unknown.
                                  "link.amazon", "link.amazon.in"})


def is_amazon_short_host(host: str) -> bool:
    """True for Amazon's OWN short domains - a wrapper, never a destination.

    USER REPORT 2026-10-04: a channel showed `https://amzn.to/4dnF9lU?tag=mama086-21`
    and opening it served SOMEBODY ELSE'S page. The short code belongs to whoever
    created it; gluing our tag onto it earns us nothing and reads as a broken link,
    so these hosts are only ever followed to the real amazon.in page.
    """
    return bool(host) and in_domains(host, AMAZON_SHORT_DOMAINS)


# USER RULE (2026-10-04, "LONG LINK lo MARCHI SHORTEN GA CHESI POST CHEYALIGAA"): an
# Amazon link we publish is SHORTENED with our own shortener, not merely compacted to
# a ~50-char /dp link. The compact tagged form stays the fallback when the shortener
# cannot answer, so a quota problem never costs the deal (or the commission).
SHORTEN_AMAZON_LINKS = os.getenv(
    "SHORTEN_AMAZON_LINKS", "true").strip().lower() not in ("0", "false", "no", "off")


def pick_one_product_for_review(text: str) -> str:
    """Reduce a multi-product post to ONE product for the review channel.

    USER RULE (2026-09-06): "list of products mana review channello cheyaku,
    okkoti edo random cheyu - mana review success avvali."

    A roundup is a worse review sample than a single listing: it reads as a
    link dump, and one bad item in it taints the whole post. The other channels
    keep the full list; only this one is reduced.

    Which item? Not the first - the first row of a source list is often the
    weakest, and always picking it would make the channel repetitive. Not
    random-by-chance either: the SAME post must reduce to the SAME product on a
    retry, or a re-render would publish a second item as a duplicate. So the
    choice is deterministic-but-spread: a hash of the post picks the index.
    """
    lines = [ln for ln in (text or "").splitlines()]
    blocks: list[list[str]] = []
    current: list[str] = []
    for line in lines:
        if not line.strip():
            continue
        current.append(line)
        if URL_RE.fullmatch(line.strip()):
            blocks.append(current)
            current = []
    # Trailing text with no link of its own is not a product block.
    if len(blocks) < 2:
        return text
    # Keep only blocks that actually name something (a link with no label is a
    # stray, not a product).
    named = [blk for blk in blocks
             if any(not URL_RE.fullmatch(ln.strip()) and re.search(r"[A-Za-z]{3}", ln)
                    for ln in blk)]
    if len(named) < 2:
        return text
    seed = hashlib.sha1((text or "").encode("utf-8", "ignore")).hexdigest()
    chosen = named[int(seed[:8], 16) % len(named)]
    out = [ln.strip() for ln in chosen]
    # The list's own heading may sit on its own line above the first product
    # ("Loot of the day" / "Deals") - carrying it into a single-product post
    # would read as part of the product name.
    _HEADING_ONLY = re.compile(
        r"(?i)^\s*(?:\U0001f525|\u26a1|\u2b50|\U0001f381|\U0001f6d2|\s)*"
        r"(?:top\s+|mega\s+|super\s+)?(?:deals?|loots?|offers?|sale|dhamaka|steals?)"
        r"\s*(?:of\s+the\s+day|today|zone|store)?\s*"
        r"[:\-\u2013\u2014|]?\s*(?:\U0001f525|\u26a1|\u2b50|\s)*$")
    if len(out) > 2:
        head = out[0]
        if (parse_price(head) is None and not URL_RE.search(head)
                and (_HEADING_ONLY.match(head) or is_promo_noise_line(head))):
            out = out[1:]
    # ...or it may be glued to the FRONT of the first product's line, because
    # the source wrote the whole list inline ("Deals Boat 141 @899 <link>").
    # Strip a leading heading word only when the rest still names a product.
    if out:
        stripped = re.sub(
            r"(?i)^\s*(?:\U0001f525|\u26a1|\u2b50|\U0001f381|\U0001f6d2|\s)*"
            r"(?:top\s+)?(?:deals?|loots?|offers?|sale|dhamaka|steals?)\s*"
            r"(?:of\s+the\s+day|today)?\s*[:\-\u2013\u2014|]?\s*",
            "", out[0])
        if stripped.strip() and re.search(r"[A-Za-z]{3}", stripped):
            out[0] = stripped.strip()
    return "\n".join(out)


def is_amazon_only_post(text: str) -> bool:
    """True when every link in the post is an Amazon link (and there is one)."""
    urls = [clean_url(u) for u in dict.fromkeys(URL_RE.findall(text or ""))]
    if not urls:
        return False
    return all(in_domains((urlparse(u).hostname or "").lower(),
                          AMAZON_DOMAINS | AMAZON_SHORT_DOMAINS)
               for u in urls)


_AMAZON_RATING_RE = re.compile(
    r"(?:\u2b50\s*)?\b(?:rating|rated|stars?)\s*[:\-]?\s*[0-5](?:[.,]\d)?\s*(?:/\s*5)?\s*(?:\u2b50|stars?)?"
    r"|\b[0-5][.,]\d\s*(?:\u2b50|/\s*5|stars?)"
    r"|\b[\d,]+\s*(?:\+\s*)?(?:ratings?|reviews?)\b",
    re.IGNORECASE)


def strip_amazon_ratings(text: str) -> str:
    """Remove copied Amazon star ratings and review counts.

    Amazon lists republished ratings/reviews as an account-closure reason: the
    numbers go stale, and the programme requires them to refresh live through
    the Product API. The product name, the price and the link are untouched, so
    the deal itself reads exactly as before.
    """
    out = []
    for line in (text or "").splitlines():
        # LAST-MILE REPAIR (USER REPORT 2026-10-18): the separator tidy-up below
        # used to run on EVERY line, and its trailing-strip ate the "-" of the
        # Indian "/-" price suffix - "Price: ₹18,999/-" posted as "₹18,999/".
        # A line with no rating in it must pass through byte-identical: the
        # posted text carries the source's money exactly as written.
        if not _AMAZON_RATING_RE.search(line):
            out.append(line)
            continue
        cleaned = _AMAZON_RATING_RE.sub(" ", line)
        # tidy the separators the removal leaves behind ("899 |  | 70% OFF")
        cleaned = re.sub(r"\s*\|\s*(?=\||$)", "", cleaned)
        cleaned = re.sub(r"^\s*[|,\-\u2013\u2014]\s*", "", cleaned)
        cleaned = re.sub(r"\s{2,}", " ", cleaned)
        cleaned = re.sub(r"(?<!/)[\s|,\-\u2013\u2014]+\Z", "", cleaned)
        # a line that was ONLY a rating disappears; one that had other words stays
        if cleaned.strip() or not line.strip():
            out.append(cleaned if cleaned.strip() else line if not line.strip() else cleaned)
    return "\n".join(out)


def cut_amazon_short_links(text: str, affiliate=None) -> tuple[str, list[str]]:
    """Remove Amazon SHORT links from a finished post; return (text, cut urls).

    LAST-MILE REPAIR (USER REPORT 2026-10-04). A queued row can still hold a render
    made by an older build - e.g. `https://amzn.to/4dnF9lU?tag=mama086-21`, which
    opens SOMEBODY ELSE'S page because the short code belongs to its creator. The
    provenance gate would refuse the whole post for such a link, i.e. lose the deal;
    instead the link is CUT (the deal text goes out complete, exactly like a dead
    destination) and the log names it. A short link WE minted is expanded to its own
    long form first, so nothing of ours is ever cut by this.
    """
    out = text or ""
    cut: list[str] = []
    if not out:
        return out, cut
    reverse = dict(getattr(affiliate, "_short_to_long", {}) or {})
    for raw in dict.fromkeys(URL_RE.findall(out)):
        url = clean_url(raw)
        host = (urlparse(url).hostname or "").lower()
        if not is_amazon_short_host(host):
            continue
        native = reverse.get(url) or reverse.get(raw) or ""
        if native and in_domains((urlparse(native).hostname or "").lower(), AMAZON_DOMAINS):
            out = replace_url_everywhere(out, raw, native)
            continue
        out = replace_url_everywhere(out, raw, " ")
        cut.append(raw)
    if cut:
        out = re.sub(r"[ \t]{2,}", " ", out)
    return out, cut


def link_is_outage(affiliate, url: str) -> bool:
    """Did this URL's last health verdict say "no server behind the host"?

    Tolerant on purpose: `affiliate` is an AffiliateClient in production, but a
    test double (or a legacy caller) may only implement `link_not_broken`.
    Anything that cannot answer is treated as "not an outage", which falls back
    to the old behaviour instead of turning a doubt into a lost post.
    """
    probe = getattr(affiliate, "link_outage", None)
    if not callable(probe):
        return False
    try:
        return bool(probe(url))
    except Exception:  # noqa: BLE001 - a health hint must never break delivery
        return False


def short_url_destination(affiliate, short_url: str) -> str:
    """The verified long URL behind a short link WE minted ("" when unknown).

    The delivery-time health check needs this: when a hop answers 503, the link a
    reader would get is dead even though the product page behind it is fine, so
    the long URL is published instead of the hop. `_short_to_long` holds exactly
    the pairs this build minted (Amazon's are durable across restarts, everything
    else lives as long as the process), which is the only safe source: a SOURCE's
    own short link is deliberately absent, because expanding somebody else's
    wrapper here would publish a URL we never verified.
    """
    if not short_url:
        return ""
    mapping = getattr(affiliate, "_short_to_long", {}) or {}
    # clean_url() normalises a bare code to "/code/", while the minted pair is
    # stored exactly as the shortener returned it - compare without the trailing
    # slash so both spellings find the same destination.
    key = clean_url(short_url).rstrip("/")
    candidate = mapping.get(short_url) or mapping.get(short_url.rstrip("/")) or ""
    if not candidate:
        for short, long_url in mapping.items():
            if long_url and clean_url(short).rstrip("/") == key:
                candidate = long_url
                break
    if not candidate:
        return ""
    candidate = clean_url(candidate)
    return candidate if URL_RE.fullmatch(candidate) else ""


def strip_amazon_tag_for_undeclared(text: str, target: str, affiliate=None) -> str:
    """Remove OUR Associates tag from Amazon links bound for an undeclared channel.

    THE BUG THIS FIXES (found by the user, 2026-09-06): "LootZoneIndia11 ... anni
    tags tho post ayyayi so reject chesaru". Links are SHORTENED in render_job
    before this runs at delivery, so by the time we got here the post read
    "https://bit.ly/3xYz" - no amazon.in hostname to match, nothing stripped, and
    our tag rode into an undeclared loot channel INSIDE the redirect. Amazon sees
    the referrer, and that is the violation that killed the application.

    So a short link WE minted is resolved back to its destination first; if that
    destination is a tagged Amazon URL, the untagged native URL is published
    instead. A source's own short link is left alone - we cannot know where it
    goes, and it was never carrying our tag anyway.

    Only our own tag is touched. The product, the price and the link still work,
    so the reader of that channel loses nothing.
    """
    if (not text or not OUR_TAG
            or normalize_channel_target_name(target) in AMAZON_TAG_TARGET_KEYS):
        return text
    out = text
    # Pass 1: our tag hidden behind a shortener we created.
    reverse = dict(getattr(affiliate, "_short_to_long", {}) or {})
    for short, long_url in reverse.items():
        if short not in out:
            continue
        host = (urlparse(clean_url(long_url)).hostname or "").lower()
        if not in_domains(host, AMAZON_DOMAINS):
            continue
        if OUR_TAG.lower() not in long_url.lower():
            continue
        parsed = urlparse(clean_url(long_url))
        query = [(k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True)
                 if k.lower() != "tag"]
        out = out.replace(short, parsed._replace(query=urlencode(query, doseq=True)).geturl())
    # Pass 2: the plainly visible amazon.in links.
    for raw in dict.fromkeys(URL_RE.findall(out)):
        url = clean_url(raw)
        host = (urlparse(url).hostname or "").lower()
        if not in_domains(host, AMAZON_DOMAINS):
            continue
        parsed = urlparse(url)
        query = [(k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True)
                 if k.lower() != "tag"]
        untagged = parsed._replace(query=urlencode(query, doseq=True)).geturl()
        if untagged != raw:
            out = out.replace(raw, untagged)
    return out
OUR_MAIN_CHANNEL_LINKS = ("https://t.me/SecretLootIndia1", "https://t.me/LootZoneIndia11")
PREMIUM_MAX_PER_NIGHT = max(1, int(os.getenv("PREMIUM_MAX_PER_NIGHT", "12")))
# The Premium channel is curated, not a firehose — but the gap between its
# picks is now a *setting* instead of a hard-coded 15-35 minutes, so the
# "everything goes out late" feeling can be tuned without a code change.
PREMIUM_GAP_MIN_SECONDS = int(_num("PREMIUM_GAP_MIN_SECONDS", 900, 0, 4 * 3600))
PREMIUM_GAP_MAX_SECONDS = int(max(PREMIUM_GAP_MIN_SECONDS,
                                  _num("PREMIUM_GAP_MAX_SECONDS", 2100, 0, 8 * 3600)))
IST = timezone(timedelta(hours=5, minutes=30))


# ---------------------------------------------------------------------------
# Night quiet window (IST): TARGET posting pauses between POST_QUIET_START and
# POST_QUIET_END (user setting: 02:00-06:00). Ingest, rescan and rendering all
# keep running, so every deal that arrives at night is queued and delivered
# the moment the window ends — nothing is lost, posting just sleeps.
# Set both values equal (e.g. 00:00/00:00) to disable the window.
# ---------------------------------------------------------------------------
def _parse_clock_minutes(value: str, fallback: str) -> int:
    try:
        hour, minute = value.strip().split(":")
        return (int(hour) % 24) * 60 + (int(minute) % 60)
    except Exception:
        hour, minute = fallback.split(":")
        return int(hour) * 60 + int(minute)


POST_QUIET_START_MIN = _parse_clock_minutes(os.getenv("POST_QUIET_START", "02:00"), "02:00")
POST_QUIET_END_MIN = _parse_clock_minutes(os.getenv("POST_QUIET_END", "06:00"), "06:00")


def in_post_quiet(now: datetime | None = None) -> bool:
    """True while target posting must pause (02:00-06:00 IST by default)."""
    if POST_QUIET_START_MIN == POST_QUIET_END_MIN:
        return False
    current = now.astimezone(IST) if now else datetime.now(IST)
    minute = current.hour * 60 + current.minute
    if POST_QUIET_START_MIN <= POST_QUIET_END_MIN:
        return POST_QUIET_START_MIN <= minute < POST_QUIET_END_MIN
    return minute >= POST_QUIET_START_MIN or minute < POST_QUIET_END_MIN


def born_in_post_quiet(timestamp: float) -> bool:
    """True when the job was created inside the night quiet window."""
    if POST_QUIET_START_MIN == POST_QUIET_END_MIN:
        return False
    return in_post_quiet(datetime.fromtimestamp(float(timestamp), IST))

# Latest routing requirements. Empty base targets use price routing only.
SOURCE_TO_TARGETS: dict[str, list[str]] = {
    "deals": list(LZI_SECRET),
    "powerloot": list(LZI_SECRET),
    "loot_alerts": list(MAIN_TARGETS),
    "TeluguTechworld": list(MAIN_TARGETS),
    "icoolzTricks": list(MAIN_TARGETS),
    "SB_Loots_And_Deals": list(LZI_SECRET),
    "Flipkarthiik": list(MAIN_TARGETS),
    "HiddenDeals1": ["SecretLootIndia1", "LootzoneTricks"],
    "idoffers": ["SecretLootIndia1", "LootzoneTricks"],
    "Magixdeals_Magix": list(LZI_SECRET),
    "dealsvelocity": list(NO_TRICKS_TARGETS),
    "pricehistory": [],
    "telugutechtvdeals": [],
    "indian_online_offer": [],
    "idoffers2": [],
    "DealsUnder99_com": [],
    # USER RULE (2026-09-04): under_99_loot_deals feeds LootZone and PowerLoots
    # too; the Under99/Under499 price channels layer on automatically by price
    # (a >₹99 item from it must not reach the Under-99 channel - that guard
    # stays), and dedup still means exactly one copy per channel.
    "under_99_loot_deals": ["LootZoneIndia11", POWER_FILTER_TARGET],
    "https://t.me/+LP6MYEpCwi0zOGYx": [],
    "Mobile_phone_offers_tv_ac_deals": list(MAIN_TARGETS),
    "Mobile_phone_offers_tv_ac_dealsk": list(LZI_SECRET),
    "https://t.me/+qhlEwwkhb2hlNWZl": list(LZI_SECRET),
    "techglaredeals": list(MAIN_TARGETS),
    "https://t.me/+uV5wcTkUWJEwM2Y1": ["LootzoneTricks"],
    "hidden_loot_deals_amazon": ["LootzoneTricks"],
    "dealdost": list(NO_TRICKS_TARGETS),
    "https://t.me/+WvEWEYf7j3MyYzNl": list(LZI_SECRET),
    "https://t.me/+t--iQ-QFeJZiNmVl": ["LootzoneTricks"],
    "https://t.me/+ky8g5O5KTr5mZmQ9": list(LZI_SECRET),
    "https://t.me/+LNRQ0Y1-9RkzZDRl": list(LZI_SECRET),
    "rapiddeals_unlimited": list(LZI_SECRET),
    "amazinglootsdealsoffers": list(LZI_SECRET),
    "https://t.me/+-mv6ttVsltczNzFl": list(NO_TRICKS_TARGETS),
    "realearnkaro": list(LZI_SECRET),
    "CKoffers": list(LZI_SECRET),
    "LootDealsPortal": list(LZI_SECRET),
    "LOOTS_DEAL_OFFER_ONLINE_SHOPPING": list(LZI_SECRET),
    "RealShoppingDeals": list(LZI_SECRET),
    "rebeldealss": list(LZI_SECRET),
    "Only_discount_Deals": list(LZI_SECRET),
    "GrabOnIndiaOfficial": list(LZI_SECRET),
    "myntra_Ajio_Sale_Deals_offers_li": list(LZI_SECRET),
    "BiggestLootDeals": list(LZI_SECRET),
    "lootping": list(LZI_SECRET),
    "Shopping_Loot_Fashion_Deals": list(LZI_SECRET),
    "msho_shpsy_offers": list(LZI_SECRET),
    "Myntra_Ajio_Deals_Shopsy": list(LZI_SECRET),
    "https://telegram.me/+sRe5uRLTK55kZWU1": list(LZI_SECRET),
}

# Dedicated Tricks feed: remove every legacy route into LootzoneTricks, then
# allow only the two user-approved trick/video sources.
for _targets in SOURCE_TO_TARGETS.values():
    while TRICKS_TARGET in _targets:
        _targets.remove(TRICKS_TARGET)

# Newly requested deal sources feed the non-Tricks main targets. Existing keys
# are deliberately overwritten to make this final routing authoritative.
for _source in (
    "vaasutechdeals", "SB_Loots_And_Deals", "dealsvelocity",
    "Magixdeals_Magix", "techglaredeals", "lootsxpert",
    "https://t.me/+WvEWEYf7j3MyYzNl", "https://t.me/+FpXKV70NYNY0NzQ1",
    "https://t.me/+vZKuuHCZcX44M2I1", "https://telegram.me/+sRe5uRLTK55kZWU1",
    "Only_discount_Deals", "amazinglootsdealsoffers", "FlashDealsUnlimited",
    # Full user source list (2026-08-30): every deal source fans out to the
    # main non-Tricks targets — best deals ALWAYS reach LootZoneIndia11, the
    # rest (Secret, PowerLoots1) get their share; premium/under-99/under-499/
    # card routes are layered on automatically. Previously several of these
    # had EMPTY target lists (dead sources) or an older partial route.
    "deals", "powerloot", "pricehistory", "telugutechtvdeals",
    "indian_online_offer", "idoffers2", "https://t.me/+LP6MYEpCwi0zOGYx",
    # 2026-08-30 (source list pt.2): fresh sources + the +qhlEwwkhb2hlNWZl
    # private channel (user wants it feeding LootZone + PowerLoots + the
    # under-₹99 / under-₹499 price channels, which layer on automatically).
    "tech24deals", "Offer_Xpress", "https://t.me/+qhlEwwkhb2hlNWZl",
):
    SOURCE_TO_TARGETS[_source] = list(NO_TRICKS_TARGETS)

SOURCE_TO_TARGETS["TrickXpert"] = [TRICKS_TARGET]
SOURCE_TO_TARGETS["Offerzone_deals"] = [TRICKS_TARGET]
# USER (2026-09-04): t.me/offers_deals_xyz is a TRICKS source - its content goes
# ONLY to the Tricks channel, never to the product channels.
SOURCE_TO_TARGETS["offers_deals_xyz"] = [TRICKS_TARGET]
# Latest explicit non-Tricks main-source routing.
SOURCE_TO_TARGETS["idoffers"] = list(NO_TRICKS_TARGETS)
SOURCE_TO_TARGETS["SB_Loots_And_Deals"] = list(NO_TRICKS_TARGETS)
SOURCE_TO_TARGETS["loot_alerts"] = list(NO_TRICKS_TARGETS)
# OZ Loot Bazaar private source: all non-Tricks main targets. Premiumlootsdeals
# is added dynamically only when its premium filter passes.
SOURCE_TO_TARGETS[OZ_SOURCE] = list(NO_TRICKS_TARGETS)
# USER RULE (2026-09-07): "t.me/DealsUnder99_com idi main preference ivvu -
# telegram and whatsapp 2 channels lo". The old route was EMPTY (a dead
# source): its posts reached only the guaranteed main feed. It is the user's
# FIRST-preference under-₹99 source, so it now feeds every non-Tricks main
# target, the under-₹99/under-₹499 price channels layer on automatically for
# its ≤₹99 posts, and PREFERRED_SOURCES (below, used by Store.claim_job)
# claims its posts from the queue ahead of every other source.
SOURCE_TO_TARGETS["DealsUnder99_com"] = list(NO_TRICKS_TARGETS)

# USER RULE (2026-09-24): "e three channel source ga pettu 1st preference
# ivvu". The three new first-preference channels fan out to every non-Tricks
# main target (LootZone, Secret, PowerLoots). The Under-99 / Under-499 price
# channels, the card/bank fan-out, Premiumlootsdeals and the Amazon review
# channel layer on automatically by price/content exactly as they do for every
# other source, and dedup still means one copy per channel.
for _source in FIRST_PREFERENCE_SOURCES:
    SOURCE_TO_TARGETS[_source] = list(NO_TRICKS_TARGETS)

# USER RULE (2026-09-07): the queue is claimed in this order -
#   (1) posts from the PREFERRED source(s)      - DealsUnder99_com first
#   (2) every other single/top deal, by priority
#   (3) product LISTS last ("then list of products")
# Within a tier the QUEUE_ORDER knob (newest/oldest) still decides. Env-
# extensible; matched case-insensitively against the queue's source column.
PREFERRED_SOURCES = {normalize_source_name(s)
                     for s in os.getenv("PREFERRED_SOURCES", "DealsUnder99_com").split(",")
                     if s.strip()}
# USER RULE (2026-09-24): the three new channels are first preference as well.
# The env knob EXTENDS the preferred tier; it can never shrink it back below
# the sources the user asked for by name.
PREFERRED_SOURCES.update(normalize_source_name(s) for s in FIRST_PREFERENCE_SOURCES)

# These sources must contain true sub-₹99 deals; valid posts go to both price targets.
UNDER99_SOURCES = {
    "under_99_loot_deals",
    "DealsUnder99_com",
    "https://t.me/+LP6MYEpCwi0zOGYx",
}

# Dashboard-managed channels (2026-10-13): operator-added targets from
# channels.json (next to the bot database) merge over the maps above at
# startup and the upgraded live watcher handles new destinations/sources.
# Existing policy edits still need an approved restart. Missing/corrupt files mean "no
# dashboard channels": this block can never break startup.
# DASHBOARD_CATEGORY_FILTERS maps a dashboard target (lowercased) to the
# product categories it keeps - e.g. an electronics-only shelf. Targets
# absent from the map take every category, exactly as before.
BUILTIN_SOURCE_NAMES = frozenset(SOURCE_TO_TARGETS)
DASHBOARD_SCOPED_SOURCES: set[str] = set()
SOURCE_DETAILS: dict[str, dict] = {}
SOURCE_ACTIVATED_AT: dict[str, float] = {}
DASHBOARD_CATEGORY_FILTERS: dict[str, frozenset] = {}
# A WATCHED SOURCE can carry its own category policy ("this channel is fashion
# only"). Keyed by the source name exactly as it is routed, so a post is dropped
# before any target is chosen - the source itself is limited, not one shelf.
SOURCE_CATEGORY_FILTERS: dict[str, frozenset] = {}
try:
    try:
        from bestgaa import channels_config as _dashboard_channels
    except ImportError:
        # Script-style launch (bestgaa/ itself on sys.path): plain import.
        import channels_config as _dashboard_channels

    _dashboard_data = _dashboard_channels.load_channels()
    _dashboard_targets = {
        SECRET_TARGET, "LootZoneIndia11", TRICKS_TARGET, POWER_FILTER_TARGET,
        UNDER99_TARGET, UNDER499_TARGET, PREMIUM_TARGET, SHOPPING_TARGET,
        *(t for t in CATEGORY_TARGETS.values() if t),
    }
    _dashboard_summary = _dashboard_channels.apply_to_routing(
        SOURCE_TO_TARGETS, AMAZON_TAG_TARGETS, _dashboard_data,
        existing_targets=_dashboard_targets, tricks_sources=TRICKS_SOURCES,
        main_sources=BUILTIN_SOURCE_NAMES)
    # USER RULE (2026-10-22): "channel link petti source add chesthe perfect ga post
    # cheyali". A watched SOURCE is stored by the dashboard with where its posts
    # should go; attaching that route here (before DASHBOARD_SCOPED_SOURCES is
    # computed) is what makes a brand-new source feed the channels instead of
    # being a line in a JSON file.
    _dashboard_watch = _dashboard_channels.apply_watch_to_routing(
        SOURCE_TO_TARGETS, _dashboard_data, NO_TRICKS_TARGETS,
        tricks_sources=TRICKS_SOURCES, existing_targets=_dashboard_targets)
    for _watch_row in _dashboard_channels.watch_entries(_dashboard_data):
        _watch_cats = [str(c).strip().lower() for c in (_watch_row.get("categories") or [])
                       if str(c).strip()]
        if _watch_cats:
            SOURCE_CATEGORY_FILTERS[str(_watch_row.get("channel", "")).strip().lower()] = frozenset(
                _watch_cats)
    DASHBOARD_SCOPED_SOURCES.update(set(SOURCE_TO_TARGETS) - BUILTIN_SOURCE_NAMES)
    AMAZON_TAG_TARGET_KEYS = {normalize_channel_target_name(t) for t in AMAZON_TAG_TARGETS}
    DASHBOARD_CATEGORY_FILTERS = {
        str(name).strip().lower(): frozenset(str(c).strip().lower() for c in cats)
        for name, cats in (_dashboard_summary.get("category_filters") or {}).items()
        if str(name).strip()
    }
    _dashboard_log = logging.getLogger("bestgaa")
    if _dashboard_summary.get("added"):
        _dashboard_log.info(
            "DASHBOARD CHANNELS | +%s target(s): %s",
            len(_dashboard_summary["added"]), ", ".join(_dashboard_summary["added"]))
    for _dashboard_cat_name, _dashboard_cat_keys in DASHBOARD_CATEGORY_FILTERS.items():
        _dashboard_log.info("DASHBOARD CHANNELS | @%s keeps categories: %s",
                            _dashboard_cat_name, ", ".join(sorted(_dashboard_cat_keys)))
    for _dashboard_warning in _dashboard_summary.get("warnings", []):
        _dashboard_log.warning("DASHBOARD CHANNELS | %s", _dashboard_warning)
    for _watch_source, _watch_cats in SOURCE_CATEGORY_FILTERS.items():
        _dashboard_log.info("DASHBOARD SOURCES | %s keeps categories: %s",
                            _watch_source, ", ".join(sorted(_watch_cats)))
    for _watched in _dashboard_watch.get("watching", []):
        _dashboard_log.info("DASHBOARD SOURCES | watching %s -> %s",
                            _watched["channel"], ", ".join(_watched["targets"]))
    for _dashboard_warning in _dashboard_watch.get("warnings", []):
        _dashboard_log.warning("DASHBOARD SOURCES | %s", _dashboard_warning)
    try:
        _snapshot_targets = set(_dashboard_targets)
        for _targets in SOURCE_TO_TARGETS.values():
            _snapshot_targets.update(_targets)
        _snapshot_path = _dashboard_channels.snapshot_path()
        _snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        _snapshot_path.write_text(json.dumps({
            "started_at": time.time(),
            "sources": sorted(str(s) for s in SOURCE_TO_TARGETS),
            "main_sources": sorted(str(s) for s in BUILTIN_SOURCE_NAMES if s not in TRICKS_SOURCES),
            "source_details": SOURCE_DETAILS,
            "targets": sorted(str(t) for t in _snapshot_targets),
            "dashboard_added": list(_dashboard_summary.get("added", [])),
            "watch": [{"channel": row["channel"], "targets": row["targets"]}
                      for row in _dashboard_watch.get("watching", [])],
            "watch_warnings": list(_dashboard_watch.get("warnings", [])),
            "watch_categories": {str(name): sorted(cats)
                                 for name, cats in SOURCE_CATEGORY_FILTERS.items()},
            "main_feed": list(NO_TRICKS_TARGETS),
            "category_rules_version": CATEGORY_RULES.get("version", 0),
            "categories": {str(key): str(item.get("label", key))
                           for key, item in CATEGORY_DEFINITIONS.items()
                           if isinstance(item, dict)},
            # The routing truth the dashboard's "source -> target" planner reads.
            # Published by the bot itself (not re-implemented in the dashboard),
            # so a preview can never disagree with what the real router does.
            "source_targets": {str(key): [str(t) for t in targets]
                               for key, targets in SOURCE_TO_TARGETS.items()},
            "price_targets": {"under99": UNDER99_TARGET, "under499": UNDER499_TARGET,
                              "premium": PREMIUM_TARGET, "power": POWER_FILTER_TARGET,
                              "secret": SECRET_TARGET, "tricks": TRICKS_TARGET},
            "tricks_sources": sorted(str(t) for t in TRICKS_SOURCES),
            # Original channel spelling ("ElectroShelf"), so the dashboard can show
            # the channel the operator named rather than its lookup key.
            "category_filters": {str(name): sorted(cats) for name, cats in
                                 (_dashboard_summary.get("category_filters")
                                  or DASHBOARD_CATEGORY_FILTERS).items()},
            "channels_mtime": os.path.getmtime(_dashboard_channels.channels_json_path())
            if _dashboard_channels.channels_json_path().exists() else 0,
        }, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as exc:
        _dashboard_log.warning("DASHBOARD CHANNELS | snapshot not written: %s", exc)
except Exception as exc:
    logging.getLogger("bestgaa").warning("DASHBOARD CHANNELS | config not applied: %s", exc)


def source_category_blocked(source: str, deal_category: str) -> str:
    """Why this post must not leave a category-limited SOURCE ("" = allowed).

    A watched source can be limited to categories ("fashion only"). The check is
    on the source, before any destination is chosen: the post is not a routing
    detail for one shelf, it is simply not what that source is watched for. An
    unclassified post (a service promo, or a caption the classifier would not
    commit to) is never allowed through a limited source - silence is safer than
    a mislabelled post on a category channel.
    """
    wanted = SOURCE_CATEGORY_FILTERS.get(str(source or "").strip().lower())
    if not wanted:
        return ""
    category = str(deal_category or "").strip().lower()
    if category and category in wanted:
        return ""
    return (f"source @{source} is limited to {', '.join(sorted(wanted))}"
            f" (post classified as {category or 'unclassified'})")


def dashboard_category_ok(target: str, deal_category: str) -> bool:
    """True when a dashboard target keeps a post of this category.

    Targets without a category filter always pass; filtered targets (an
    electronics-only shelf, ...) pass only when the post was classified into
    one of their categories. Unclassified posts and service promos (category
    "") never reach a filtered shelf.
    """
    wanted = DASHBOARD_CATEGORY_FILTERS.get(str(target or "").strip().lower())
    if not wanted:
        return True
    return bool(deal_category) and str(deal_category).strip().lower() in wanted


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
log = logging.getLogger("bestgaa")
log.setLevel(logging.INFO)
log.handlers.clear()
log.propagate = False
formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
console = logging.StreamHandler(sys.stdout)
console.setFormatter(formatter)
rotating = logging.handlers.RotatingFileHandler(
    LOG_DIR / "bot.log", maxBytes=8_000_000, backupCount=5, encoding="utf-8"
)
rotating.setFormatter(formatter)
log.addHandler(console)
log.addHandler(rotating)
for _target_name, _category_keys in CATEGORY_TARGET_COLLISIONS.items():
    log.warning("CATEGORY TARGET COLLISION | @%s is assigned to %s; those category routes are disabled",
                _target_name, ", ".join(_category_keys))

# ---------------------------------------------------------------------------
# Domain and parsing helpers
# ---------------------------------------------------------------------------
URL_RE = re.compile(r"https?://[^\s<>\[\](){}\"']+", re.I)


try:
    from .category_classifier import classify_category
except ImportError:
    from category_classifier import classify_category


def classify_deal_category(text: str | None,
                           link_context: Iterable[str] = ()) -> str | None:
    """Offline conservative shelf classification, shared with dashboard preview."""
    return classify_category(text, link_context, CATEGORY_RULES)["category"]


# Same pattern but with a CAPTURE group: re.split drops the separator itself,
# while a capturing group keeps every URL inside the split parts (odd index),
# so text-side cleanup can mask URLs and never touch query chars like '+'.
URL_KEEP_RE = re.compile(r"(https?://[^\s<>\[\](){}\"']+)", re.I)
INTENT_RE = re.compile(r"intent://[^\s]+", re.I)
ASIN_RE = re.compile(r"(?:/dp/|/gp/product/|/gp/aw/d/)([A-Z0-9]{10})(?:[/?#]|$)", re.I)

SHORT_DOMAINS = {
    "amzn.to", "amzn.in", "amazn.lt", "link.amazon", "fkrt.co", "fkrt.cc", "fkrt.in",
    "fktr.in", "myntr.it", "myntr.in", "ajiio.co", "bit.ly", "bitli.in", "bitl.in",
    "bittli.in", "bilty.co", "tinyurl.com", "cutt.ly", "rb.gy", "t.ly", "tiny.cc",
    "shorturl.at", "is.gd", "v.gd", "snip.ly", "linkredirect.in", "ekaro.in",
    "clnk.in", "clnk.app", "ekaro.app", "l.ead.me",
    # USER RULE (2026-09-04): WHATEVER shortener the source used, the link is
    # resolved to its real store page and monetized as OUR link. These are the
    # rest of the wrappers the loot channels actually paste:
    "bitly.com", "j.mp", "t.co", "goo.gl", "buff.ly", "ow.ly", "tidd.ly",
    "geni.us", "spoo.me", "da.gd", "surl.li", "shrtco.de", "9qr.de", "cli.re",
    "shorte.st", "v.ht", "y2u.be", "dl.flipkart.com", "msho.in", "meesho.app",
    "extp.in", "wishlink.com", "hypd.store", "bylink.in", "mylink.store",
    "applink.adjust.com", "app.ajio.com", "ajiio.in", "tatacliq.app",
}
OUR_SHORTENER_DOMAINS = {
    "ekaro.in", "clnk.in", "clnk.app", "ekaro.app", "fktr.in", "myntr.it",
    "ajiio.in", "bitli.in", "j.mp", "cuelinks.com", "l.ead.me", "affiliaters.in",
}
OUR_RUNTIME_SHORTENER_DOMAINS = {"bit.ly", "is.gd"}
FOREIGN_ECHO_DOMAINS = {
    "amzn.to", "amzn.in", "amazn.lt", "link.amazon", "fkrt.co", "fkrt.cc", "fkrt.in",
    "myntr.in", "ajiio.co", "tinyurl.com", "cutt.ly", "rb.gy", "t.ly", "tiny.cc",
    "shorturl.at", "is.gd", "v.gd", "snip.ly", "linkredirect.in", "bilty.co", "bitly.co",
    # LOOKALIKES of our EarnKaro shortener (bitli.in): "bitl.in" / "bittli.in"
    # are other channels' short domains. An API result on one of these is a
    # foreign echo, never our commission link - reject it like fkrt.co.
    "bitl.in", "bittli.in",
}
AMAZON_DOMAINS = {"amazon.in", "www.amazon.in", "amazon.com", "www.amazon.com"}
KNOWN_MERCHANT_DOMAINS = {
    "amazon.in", "amazon.com", "flipkart.com", "myntra.com", "ajio.com",
    "myntr.in", "myntr.it", "ajiio.co", "fkrt.co", "fkrt.cc", "fktr.in",
    "meesho.com", "shopsy.in", "tatacliq.com", "nykaa.com", "croma.com",
    "reliancedigital.in", "jiomart.com", "firstcry.com", "snapdeal.com",
    "decathlon.in", "pepperfry.com", "limeroad.com", "paytmmall.com",
}
TRACKING_QUERY_KEYS = {
    "tag", "ref", "ref_", "linkcode", "camp", "creative", "creativeasin",
    "ascsubtag", "affid", "affextparam1", "affextparam2", "aff_id", "affiliate",
    "shareid", "source", "subid", "sub_id", "clickid", "irclickid", "irgwc",
    "referral_code", "referral", "refcode", "invite_code", "invitecode",
    "gclid", "fbclid", "msclkid",
}
# Amazon-only junk: search/session attribution that bloats /s? links to 300+
# chars (btn_ref=srctok-..., ds=, qid=...). Meaningful filters (k, i, rh, s,
# rnid keeps the filter group) are preserved so Men/Women/Girls/Boys category
# links stay distinct.
# ---------------------------------------------------------------------------
# OUR ATTRIBUTION ON A MERCHANT PAGE (USER REPORT 2026-10-04):
#   "product open avuthundi kaani adi mana links kaadu ... commission asalu
#    ravatledu" - the click worked, the deal stayed, and NOBODY was paid.
#
# A pass-through (the network answered "no campaign") used to publish a BARE
# merchant URL. Strict-all now skips that item/post unless it can be attributed.
# For the documented Flipkart family, `affExtParam2=<publisher>` is the native
# form returned by EarnKaro for OUR account (also validated by earnkaro_check.py),
# so eligible callers can rebuild that page with our exact publisher id. Amazon
# uses the Associates tag, Meesho uses a verified HYPD mapping, and no other store
# may be promoted as ours merely because its product page opens.
# ---------------------------------------------------------------------------
# SHopsy belongs here (2026-10-19). It is Flipkart's own low-price marketplace
# and the converter mints exactly the Flipkart shape on it - the user's own link
# proof:
#   https://www.shopsy.in/<slug>/p/itm5722ca2c8fa09?pid=...&marketplace=FLIPKART
#       &affid=deals101&cmpid=AFF_deals101
#       &affExtParam1=ENKR20261019A2241424426&affExtParam2=5478322
# Leaving it out had two costs: a Shopsy page that ALREADY carried our publisher
# id was not recognised as ours (so the deal was dropped when the converter had
# nothing to add, even though the link paid us), and a bare Shopsy page could
# never be rebuilt with our id. Both are fixed by listing the host; the id check
# itself is unchanged, so a foreign affExtParam2 is still refused.
EK_ATTRIBUTION_HOSTS = {h.strip().lower() for h in os.getenv(
    "EK_ATTRIBUTION_HOSTS", "flipkart.com,shopsy.in,myntra.com").split(",") if h.strip()}
ATTRIBUTE_PASSTHROUGH_LINKS = os.getenv(
    "ATTRIBUTE_PASSTHROUGH_LINKS", "true").strip().lower() not in ("0", "false", "no", "off")
# Attribution parameters that belong to whoever else's link we are rebuilding -
# they are replaced by ours, never carried along (a kept foreign id pays them).
FOREIGN_ATTRIBUTION_KEYS = {
    "affid", "aff_id", "affid1", "affid2", "affextparam1", "affextparam2",
    "affiliate", "affiliate_id", "affiliateid", "subid", "sub_id",
}

# NOTE (USER QUESTION 2026-10-04, "idi manadenaa link"): on a Flipkart-family
# link `affid` is the AFFILIATE ACCOUNT id - the network's account, exactly as
# Flipkart documents its own affiliate URLs - and `affExtParam2` is the publisher
# who gets credited inside it. An EarnKaro-converted link carries BOTH
# (affid=deals101&cmpid=AFF_deals101&affExtParam1=ENKR...&affExtParam2=OURS) and
# is OURS: `affExtParam2=5478322` is the id the money is credited to. Those
# network parameters must never be stripped from a converted link - removing
# them is the one change that could really lose the commission - so the posting
# path is deliberately left alone here and the AUDIT is taught whose link it is
# (see ops/quality_audit.py, which now agrees with whose_link()).


# ---------------------------------------------------------------------------
# USER RULE (2026-10-19): "valla long link lo mana number pedthe manaku vasthadi
# anukoku" - DO NOT assume our number on somebody's long link earns anything.
#
# A Flipkart-family conversion is credited on the pair the network mints:
#   affid=<account> & affExtParam1=<click/conversion id>  (money is attributed)
#   affExtParam2=<publisher>                              (the sub-id inside it)
# A page carrying nothing but affExtParam2=<our id> has no conversion behind it,
# so it is NOT proof that we are paid - it has to be CONVERTED, not assumed.
# `attribute_with_our_publisher()` below can only add that number, so it is a
# convenience for legacy mode and never ownership proof.
EK_CONVERSION_SIGNATURE_HOSTS = ("flipkart.com", "shopsy.in")


def conversion_signature_missing(url: str) -> str:
    """'' when a Flipkart-family URL carries a real conversion id, else why not.

    myntra.com (and any other host in EK_ATTRIBUTION_HOSTS) is deliberately not
    covered: the converter's Myntra shape has only been observed with
    affExtParam2, so demanding a conversion id there would refuse real links.
    """
    try:
        parsed = urlparse(clean_url(url))
        host = (parsed.hostname or "").lower()
        if not in_domains(host, EK_CONVERSION_SIGNATURE_HOSTS):
            return ""
        query = {str(key).lower(): values for key, values in parse_qs(parsed.query).items()}
        if any(str(value).strip() for value in query.get("affextparam1", [])):
            return ""
        return ("carries our publisher id but NO conversion id (affExtParam1) - Flipkart pays "
                "on the affid+affExtParam1 pair, so this page earns NOTHING until it is really "
                "converted")
    except Exception:
        return "not a parseable URL"


def attribute_with_our_publisher(url: str, publisher: str = "") -> str:
    """OUR EarnKaro publisher id on a Flipkart-family product URL.

    A no-op (the URL comes back unchanged) for any other host, when no publisher
    is configured, or when ATTRIBUTE_PASSTHROUGH_LINKS=false. Foreign ids are
    removed first, so the rebuilt link can only ever pay us. `publisher` lets a
    caller state whose id to stamp (the audit uses its own resolution); the
    default is this install's EarnKaro account.

    NOT PROOF (2026-10-19): this only appends the number. A URL it rebuilt has no
    conversion id, so Store.has_native_owned_attribution() refuses it and the
    posting gate will not treat it as ours - the deal has to be converted.
    """
    publisher = (publisher or OUR_EK_ID).strip()
    if not (publisher and ATTRIBUTE_PASSTHROUGH_LINKS):
        return url
    try:
        parsed = urlparse(clean_url(url))
        host = (parsed.hostname or "").lower()
        if not in_domains(host, EK_ATTRIBUTION_HOSTS):
            return url
        pairs = [(key, value) for key, value in parse_qsl(parsed.query, keep_blank_values=True)
                 if key.lower() not in FOREIGN_ATTRIBUTION_KEYS]
        pairs.append(("affExtParam2", publisher))
        return parsed._replace(scheme="https", netloc=host,
                               query=urlencode(pairs), fragment="").geturl()
    except Exception:
        return url


AMAZON_JUNK_QUERY_KEYS = {
    "btn_ref", "btn_type", "ds", "dc", "qid", "sprefix", "crid", "sr",
    "pd_rd_r", "pd_rd_w", "pd_rd_wg", "pf_rd_i", "pf_rd_m", "pf_rd_p",
    "pf_rd_r", "pf_rd_s", "pf_rd_t", "content-id", "spla", "qu", "srs",
}
NON_STORE_DOMAINS = {
    "t.me", "telegram.org", "youtube.com", "youtu.be", "facebook.com", "instagram.com",
    "twitter.com", "x.com", "reddit.com", "whatsapp.com", "discord.com", "pinterest.com",
    "linkedin.com", "github.com", "google.com", "drive.google.com", "imgur.com",
}
# USER RULE (2026-09-06): a deal blog or an app-deep-link wrapper is NOT a shop.
# indiadesire.com is a coupons/deals aggregator that says, in its own words, "we
# do not sell any products"; *.urlgeni.us is URLgenius's Amazon app-deep-link
# domain. Neither is a product page EarnKaro has a campaign for, and each used to
# burn the whole job retry budget (JOB_MAX_ATTEMPTS) and then drop the post - a
# source deal vanished for a link that was never a shop in the first place. They
# are cut from the copy like a dead short link, and the deal still goes out.
NON_SHOP_DOMAINS = {
    "indiadesire.com", "urlgeni.us",
}
# A share/forward/invite link is not a destination: nothing is bought at
# "wa.me/?text=..." or "t.me/share/url", and a link to another channel's post is
# that channel's promotion, not our reader's deal. These hosts are still excluded from
# the merchant destination list on purpose - and the reason matters. A source post
# carrying a WhatsApp share button used to be retried forever ("affiliate conversion
# returned no link: wa.me") and then dropped when the price went stale: the source
# channel had the deal, our channels never saw it. So a share link is never converted,
# never health-checked, and above all never a reason to swallow a post.
# A host whose only job is redirecting. Enumerating them is hopeless (a source channel
# posts bit.ly today and bitly.com/74265 tomorrow), so this list is only the part we are
# SURE about - is_unresolvable_short_link() below adds the shape test and is what decides.
# Anything here whose link never resolves is cut from the copy; the deal still goes out.
SHORTENER_HOSTS = (FOREIGN_ECHO_DOMAINS | OUR_RUNTIME_SHORTENER_DOMAINS
                   | OUR_SHORTENER_DOMAINS
                   | {"bit.ly", "j.mp", "bitly.com", "t.co", "buff.ly", "ow.ly",
                      "tiny-urls", "short.link", "go.link", "spl.ink", "tini.go",
                      "tidd.ly", "geni.us", "amzn.to", "amzn.in", "s.click"})


def looks_like_shortener(host: str, url: str) -> bool:
    """True for a host/shape that exists only to redirect.

    The shape does the work here, not a blocklist: any host that is not a known
    merchant or service store and carries a single short slug is a shortener as
    far as we are concerned. (A source channel posts bit.ly today and
    bitly.com/74265 tomorrow, so a list could never be complete.)
    """
    if not host or in_domains(host, KNOWN_MERCHANT_DOMAINS) or in_domains(host, SERVICE_OFFER_DOMAINS):
        return False
    if in_domains(host, SHORTENER_HOSTS):
        return True
    path = (urlparse(str(url or "")).path or "").strip("/")
    return bool(path) and "/" not in path and len(path) <= 24


def is_unresolvable_short_link(host: str, url: str) -> bool:
    """True for a link that exists only to redirect and gave us nothing.

    Such a link is not a destination: it has no product page behind it that we could
    publish, monetize or verify. Retrying the WHOLE post for it (the old behaviour) is how
    a source post vanished - so the caller cuts the link and posts the deal.
    """
    return looks_like_shortener(host, url)


SHARE_INTENT_DOMAINS = NON_STORE_DOMAINS | {
    "wa.me", "api.whatsapp.com", "chat.whatsapp.com", "web.whatsapp.com", "wa.link",
    "telegram.me", "telegram.dog", "tl.me", "addtoany.com", "sharethis.com",
    "getpocket.com", "pocket.co", "vk.com", "twitter.com", "x.com", "m.me", "facebook.net",
    "viber.com", "line.me",
}


def is_share_intent(url: str) -> bool:
    """True for share / forward / invite links, which are not merchant pages."""
    raw = str(url or "")
    if raw.startswith(("tg://", "whatsapp://", "viber://", "line://", "sms:", "mailto:", "tel:")):
        return True
    if "wa.me/" in raw.lower() and "/sendtext=" in raw.lower():
        return True
    host = (urlparse(raw).hostname or "").lower()
    if not host:
        return False
    if in_domains(host, SHARE_INTENT_DOMAINS):
        return True
    # t.me/<channel>/<id> and t.me/+invite are channel links, never product pages.
    return host in ("t.me", "telegram.me", "telegram.dog", "telegram.org", "tl.me")


BROKEN_PAGE_MARKERS = (
    "just a quick repair needed",
    "we're doing everything we can to fix this",
    "we’re doing everything we can to fix this",
    "the page you requested cannot be found",
    "this page could not be found",
    "product is no longer available",
)

# SERVICE OUTAGE, not "doubt". These exact sentences are the ones a load
# balancer writes when it has no backend behind it at all:
#
#   Shopsy/Flipkart behind HAProxy:  "503 Service Unavailable
#                                     No server is available to handle this request."
#   nginx / Apache default:          "503 Service Temporarily Unavailable"
#                                    "The server is temporarily unable to service
#                                     your request"
#
# USER REPORT (2026-10-19): a posted bitli.in link opened this page, i.e. the bot
# published a link that had no working server behind it. The probe below treated
# every 5xx as inconclusive ("our IP might be blocked") and posted anyway, so the
# one 5xx that DOES say the site is down was waved through. These markers are
# deliberately narrow: a bare 500/502/504 with none of these words stays
# inconclusive exactly as before (that is what protects a live deal from a
# datacenter-IP block), and an outage verdict is a different verdict from a dead
# product page - it is retried, never published.
SERVICE_OUTAGE_MARKERS = (
    "no server is available to handle this request",
    "503 service unavailable",
    "503 service temporarily unavailable",
    "service temporarily unavailable",
    "the server is temporarily unable to service your request",
)


def looks_broken_page(status: int, body: str) -> bool:
    """True ONLY when the page's own words say it is gone.

    A bare 4xx/5xx status from OUR datacenter IP proves nothing: Amazon and
    Flipkart serve 404/repair pages to datacenter IPs all day long for
    products that are live for every real customer (USER REPORT 2026-10-11:
    "mana links ravatledu" - live deals posted WITHOUT our links because a
    datacenter-404 vetoed the conversion before the API was even called, and
    discarded proven conversions after it). The veto needs the page's own
    dead words (Flipkart's repair text, "no longer available", ...); `status`
    stays in the signature for the caller's log line but never decides alone.
    Doubt always resolves toward attempting the conversion - the EarnKaro API
    (not our probe) is the authority on whether a campaign exists.
    """
    text = (body or "").lower()
    return any(marker in text for marker in BROKEN_PAGE_MARKERS)


def looks_like_service_outage(status: int, body: str) -> bool:
    """True ONLY for an explicit upstream-outage page (5xx + its own words).

    `status` DOES decide here, unlike `looks_broken_page`: the wording alone can
    legitimately appear inside a healthy page's JavaScript bundle, so a 200 that
    merely mentions "503 Service Unavailable" must never be called an outage. A
    5xx that carries the load balancer's own sentence, though, is not ambiguous -
    nothing is listening behind the host right now.

    Flipkart-family hosts (Shopsy included) answer under load with exactly:

        503 Service Unavailable
        No server is available to handle this request.

    and that is the page the reader got when they clicked our link. The bot must
    retry it (the condition is usually seconds long) instead of publishing it.
    """
    if status < 500:
        return False
    text = (body or "").lower()
    return any(marker in text for marker in SERVICE_OUTAGE_MARKERS)


def host_matches(host: str, domain: str) -> bool:
    host = (host or "").lower().rstrip(".")
    domain = domain.lower().rstrip(".")
    return host == domain or host.endswith("." + domain)


def in_domains(host: str, domains: Iterable[str]) -> bool:
    return any(host_matches(host, d) for d in domains)


try:
    from .hypd_policy import hypd_parts, meesho_product_id, meesho_key, mapping_valid
except ImportError:
    from hypd_policy import hypd_parts, meesho_product_id, meesho_key, mapping_valid


def hypd_store_of(url: str) -> str:
    parts = hypd_parts(url)
    return parts[0] if parts else ""


def hypd_afflink_token(url: str) -> str:
    parts = hypd_parts(url)
    return f"{parts[0]}:{parts[1]}" if parts else ""


def is_hypd_link(url: str) -> bool:
    """True for any hypd.store share link, ours or another creator's."""
    return bool(hypd_store_of(url))


def hypd_product_keys(value: str) -> list[str]:
    """Every spelling of ONE product page the HYPD map matches on.

    A source writes the same product page as a bare link, with HYPD's own
    tracking still on it, or with session parameters - all three must find the
    same HYPD share link, otherwise strict-all has to skip a deal for which we
    already hold a verified commission link.
    """
    url = clean_url(value or "")
    if not url:
        return []
    keys: list[str] = []
    pid = meesho_product_id(url)
    key_match = re.fullmatch(r"PID:(?:www\.|m\.)?meesho\.com:([a-z0-9]{6,})", url, re.I)
    pid = pid or (key_match[1].lower() if key_match else "")
    if pid:
        keys.extend(f"PID:{host}:{pid}" for host in ("www.meesho.com", "meesho.com", "m.meesho.com"))
    for candidate in (url, merchant_url(url), canonical_url(url)):
        candidate = clean_url(candidate)
        if candidate and candidate not in keys:
            keys.append(candidate)
    return keys


def is_our_hypd_link(url: str) -> bool:
    """True when the HYPD link earns on OUR store (93944 / smartdeals).

    Only our own share links are ours: another creator's hypd.store link pays
    THEM, so it is treated like any foreign affiliate wrapper.
    """
    store = hypd_store_of(url)
    return bool(store) and store in OUR_HYPD_STORES


# Long-link threshold for shortening: anything longer than this (a messy
# merchant URL with filters/tracking) gets a Bitly/is.gd short link so Telegram
# posts stay clean. A tidy Amazon /dp link with our tag (~52 chars) is under it
# and posts direct (no quota); lists always shorten (multi_link). Overridable.
SHORTEN_MIN_LEN = int(os.getenv("SHORTEN_MIN_LEN", "70"))

# USER REPORT (2026-10-21): "ilaga invalid url link vasthunnai mana channels lo"
# with two `https://is.gd/xxxx` links in a channel that resolved to UNTAGGED
# amazon.in/dp pages. An is.gd hop is the one link shape we can never prove: the
# URL carries no publisher, no account and no record of who minted it, so a
# tokenless shortener will happily wrap a page that pays nobody - and once such a
# hop is in a channel it looks exactly like ours. Bitly stays (it is minted with
# OUR token, so a proof row can bind it to our account); the tokenless fallback is
# OFF unless this host explicitly opts in. With Bitly unavailable the native
# tagged link is published instead - a deal is never lost to a cosmetic hop.
TOKENLESS_SHORTENER = os.getenv(
    "SHORTENER_TOKENLESS_FALLBACK", "0").strip().lower() in ("1", "true", "yes", "on")
# Hosts whose links are provable by nothing but a stored proof: a tokenless hop.
TOKENLESS_SHORTENER_DOMAINS = {"is.gd", "v.gd", "tinyurl.com", "tiny.cc", "rb.gy",
                               "cutt.ly", "t.ly", "shorturl.at", "shorturl.gg",
                               "spoo.me", "da.gd", "surl.li", "shrtco.de", "9qr.de",
                               "cli.re", "v.ht", "shorte.st", "snip.ly"}


def should_use_bitly(resolved_url: str, multi_link: bool) -> bool:
    """USER RULE: Bitly ONLY for lists (2+ links) and very long links —
    normal single Amazon links post with our Associates tag directly, so the
    Bitly monthly quota never runs out on ordinary product deals. (The very
    long single links are caught by the caller's length check.) An Amazon link
    INSIDE a list is shortened with the rest of the list (2026-09-06); the
    review channel expands our short links back to the native tagged URL."""
    return multi_link


def tag_native_amazon(url: str) -> str:
    """Put OUR Associates tag on a native Amazon URL; no-op for anything else.

    Used wherever the bot restores a NATIVE store page from one of our earned
    links (the reviewed channel must show amazon.in/dp/ASIN?tag=mama086-21 -
    an untagged link on a declared channel earns nothing). Delivery strips the
    tag again on every channel that is not declared to Amazon.
    """
    if not OUR_TAG:
        return url
    try:
        if in_domains((urlparse(clean_url(url)).hostname or "").lower(), AMAZON_DOMAINS):
            return apply_amazon_tag(url)
    except Exception:
        pass
    return url


def apply_amazon_tag(link: str) -> str:
    """Force the configured Associates Store ID on direct Amazon API output."""
    try:
        parsed = urlparse(clean_url(link))
        host = (parsed.hostname or "").lower()
        if not in_domains(host, AMAZON_DOMAINS):
            return clean_url(link)
        query = parse_qsl(parsed.query, keep_blank_values=True)
        query = [(key, value) for key, value in query if key.lower() != "tag"]
        # Tag era: OUR_AMAZON_TAGS has already refused any non-owned tag at
        # startup, so OUR_TAG is always ours - set it on every tagged link.
        if OUR_TAG:
            query.append(("tag", OUR_TAG))
        return parsed._replace(query=urlencode(query, doseq=True)).geturl()
    except Exception:
        return clean_url(link)


def compact_amazon_product_link(link: str) -> str:
    """Collapse an Amazon PRODUCT (/dp/ASIN or /gp/product/ASIN) URL to its
    shortest native form:
      https://www.amazon.in/dp/ASIN?tag=OUR_TAG
    All noise params (psc/smid/th/linkCode/tag ...) are dropped - a stranger's
    tag goes, ours is set - so product links in a list are short WITHOUT
    spending Bitly quota. Amazon SEARCH / category links (/s?...) have no
    single ASIN and are returned untouched so the final shorten pass can Bitly
    them. Preserves the Amazon TLD."""
    try:
        raw = clean_url(link)
        m = re.search(r"(?:/dp/|/gp/(?:product|aw/d)/)([A-Z0-9]{10})(?:[/?#]|$)", raw, re.I)
        if not m:
            return raw
        asin = m.group(1).upper()
        parsed = urlparse(raw)
        host = (parsed.hostname or "").lower()
        if not in_domains(host, AMAZON_DOMAINS):
            return raw
        netloc = host if host.startswith("www.") else "www." + host
        # Tag era: our Associates tag rides on the compact form; a source's tag
        # never survives the rebuild.
        if OUR_TAG:
            ref = None
            for key, value in parse_qsl(parsed.query, keep_blank_values=True):
                if key.lower() == "ref" and value:
                    ref = value
            query = urlencode([("tag", OUR_TAG)] + ([("ref", ref)] if ref else []))
            return f"https://{netloc}/dp/{asin}?{query}"
        # Tagless clean form – no tag, no ref
        return f"https://{netloc}/dp/{asin}"
    except Exception:
        return clean_url(link)


def is_amazon_search_or_browse_link(link: str) -> bool:
    """True for an Amazon SEARCH / category / browse URL, which has no single ASIN.

    The three shapes the user named: /s?k= (search), /s?hidden-keywords= (a
    search list) and /b?node= (a browse node). Product pages (/dp/, /gp/product/)
    are handled by compact_amazon_product_link() and are NOT search links.
    """
    try:
        parsed = urlparse(clean_url(link))
        host = (parsed.hostname or "").lower()
        if not in_domains(host, AMAZON_DOMAINS):
            return False
        path = (parsed.path or "").rstrip("/")
        if path in ("/s", "/gp/search", "/gp/aw/s"):
            return True
        if path == "/b":
            query = {str(k).lower() for k in parse_qs(parsed.query).keys()}
            return "node" in query
        return False
    except Exception:
        return False


async def repair_links_if_possible(client, text: str, **kwargs) -> tuple[str, list[dict]]:
    """`client.repair_unowned_links()` when the client has it, else the text as-is.

    The repair pass lives on AffiliateClient. A few tests (and any external
    caller) drive the render path with a duck-typed client that only implements
    convert/resolve; those must keep working unchanged instead of dying on an
    AttributeError in the middle of a live post.
    """
    repair = getattr(client, "repair_unowned_links", None)
    if repair is None:
        return text, []
    return await repair(text, **kwargs)


def replace_url_everywhere(text: str, raw: str, replacement: str) -> str:
    """Replace `raw` - and its &amp;-escaped twin - with `replacement` in ONE pass.

    The chained `text.replace(raw, x).replace(raw.replace("&", "&amp;"), x)`
    this used to be was a live corruption bug: str.replace rescans its own
    output, and when raw carries no '&' the two calls are identical, so the
    second call matched the bare URL as the PREFIX of the URL the first call
    had just written and appended the query a second time - producing links
    like ?tag=mama086-21?tag=mama086-21. A doubled tag is not our tag, so the
    provenance gate rightly refused the post and a perfectly good deal was
    silently dropped. A single regex pass can never re-match its own output.
    """
    variants = [v for v in (raw, raw.replace("&", "&amp;")) if v]
    ordered = sorted(dict.fromkeys(variants), key=len, reverse=True)
    # A URL is also a PREFIX of every longer URL built on it, so the match must
    # stop at a URL boundary. Without the lookahead, replacing a bare
    # `.../dp/ASIN` in a list that also carries `.../dp/ASIN?tag=ours` rewrote the
    # prefix of the tagged one and produced `?tag=ours?tag=ours` - a doubled tag,
    # which is not our tag, so the gate refused a perfectly good deal
    # (found 2026-10-22 by test_link_commission.py, list case).
    pattern = re.compile("|".join(re.escape(v) for v in ordered) + r"(?![\w&?=/%#+-])")
    return pattern.sub(lambda _match: replacement, text)


# A Flipkart product URL is "slug + /p/ + item id + pid": lid, marketplace, srno,
# ssid, otracker and the rest are session/tracking noise that triples the length.
# USER RULE (2026-09-05, "shortga ravali"): a link of ours must never go out 177
# characters long just because the shortener was busy, so a product link is first
# compacted natively (free, no quota) and only then handed to the shortener.
# The leading "/dl" of a dl.flipkart.com app link is part of the wrapper, not of
# the product path: www.flipkart.com/<slug>/p/<item id> is the canonical page.
# USER REPORT (2026-09-06): a Flipkart link went out at 130 characters,
# unshortened - "flipkart earnkaro tho change cheyatledu shortenga". Its path was
#   /flipkart/p/item?lid=...&pid=...
# i.e. the literal word "item", not the usual "itm<id>" slug, so this regex did
# not match and the link was handed back untouched. Both spellings are real
# Flipkart product pages; the identity lives in the pid either way.
FLIPKART_ITEM_RE = re.compile(r"(?i)^(?:/dl)?(?P<path>/.*?/p/(?:itm[a-z0-9]+|item))")
FLIPKART_HOSTS = {"flipkart.com", "www.flipkart.com", "dl.flipkart.com", "m.flipkart.com"}


def compact_flipkart_product_link(link: str) -> str:
    """Collapse a Flipkart product URL to slug + item id + pid.

    Only a PRODUCT page (/p/itm...) is touched. `pid` and recognized affiliate
    attribution parameters are retained; only session/filter noise is dropped,
    so the link still opens the same item and still pays its publisher. A
    search/category/offer URL has no item id and is returned untouched for the
    shortener to handle.
    """
    try:
        raw = clean_url(link)
        parsed = urlparse(raw)
        host = (parsed.hostname or "").lower()
        if host not in FLIPKART_HOSTS:
            return raw
        match = FLIPKART_ITEM_RE.match(parsed.path or "")
        if not match:
            return raw
        pairs = parse_qsl(parsed.query, keep_blank_values=True)
        pid = next((value for key, value in pairs if key.lower() == "pid" and value), "")
        # Keep the affiliate attribution while removing session/filter noise.
        # Dropping affExtParam2 here made a compact-looking Flipkart URL pay the
        # source or nobody at all, even though the API had converted it correctly.
        attribution_keys = {
            "affid", "aff_id", "affid1", "affid2", "affextparam1",
            "affextparam2", "affiliate", "affiliate_id", "affiliateid",
            "subid", "sub_id", "tag",
        }
        compact_query = ([ ("pid", pid) ] if pid else []) + [
            (key, value) for key, value in pairs
            if key.lower() in attribution_keys
        ]
        # A dl.* link is Flipkart's own app-redirect wrapper for the same page.
        netloc = "www.flipkart.com"
        return parsed._replace(
            scheme="https", netloc=netloc, path=match.group("path"),
            query=urlencode(compact_query), fragment="", params="",
        ).geturl()
    except Exception:
        return clean_url(link)


def clean_url(value: str) -> str:
    # Telegram/Markdown copies can contain HTML-escaped query separators (`&amp;`).
    # Decode before parsing so foreign affiliate wrappers are always unwrapped.
    return html.unescape(value or "").strip().rstrip(".,;:!?\"')*]>}\n\r\t ")


def canonical_url(value: str) -> str:
    try:
        p = urlparse(clean_url(value))
        query = parse_qs(p.query)
        keep = {}
        for key in ("pid", "productid", "productId", "asin", "node"):
            if key in query:
                keep[key] = query[key]
        q = urlencode(keep, doseq=True)
        path = re.sub(r"/+", "/", p.path).rstrip("/")
        return p._replace(scheme="https", netloc=(p.hostname or "").lower(), path=path,
                          query=q, fragment="").geturl()
    except Exception:
        return clean_url(value).lower()


def merchant_url(value: str) -> str:
    """Remove attribution noise but preserve merchant filters such as Men/Women."""
    try:
        p = urlparse(clean_url(value))
        kept = []
        host = (p.hostname or "").lower()
        is_amazon = in_domains(host, AMAZON_DOMAINS)
        for key, item in parse_qsl(p.query, keep_blank_values=True):
            lower = key.lower()
            if lower.startswith("utm_") or lower in TRACKING_QUERY_KEYS:
                continue
            # Amazon search/session junk (btn_ref=srctok, ds=, qid=, sprefix=)
            # is stripped so category-filter links shrink to their real filters.
            if is_amazon and lower in AMAZON_JUNK_QUERY_KEYS:
                continue
            kept.append((key, item))
        kept.sort(key=lambda pair: (pair[0].lower(), pair[1]))
        path = re.sub(r"/+", "/", p.path).rstrip("/")
        return p._replace(
            scheme="https", netloc=(p.hostname or "").lower(), path=path,
            query=urlencode(kept, doseq=True), fragment="",
        ).geturl()
    except Exception:
        return clean_url(value)


def parse_intent(value: str) -> str | None:
    if not value.startswith("intent://"):
        return None
    match = re.search(r"S\.browser_fallback_url=([^;]+)", value)
    if match:
        target = unquote(match.group(1))
        return target if target.startswith("http") else None
    match = re.search(r"intent://([^#;]+)", value)
    return "https://" + match.group(1).lstrip("/") if match else None


def extract_product_id(value: str) -> str | None:
    url = clean_url(value)
    match = ASIN_RE.search(url)
    if match:
        return "ASIN:" + match.group(1).upper()
    try:
        parsed = urlparse(url)
        query = parse_qs(parsed.query)
        if query.get("asin"):
            return "ASIN:" + query["asin"][0].upper()
        if query.get("pid"):
            return "PID:" + query["pid"][0].upper()
        host = (parsed.hostname or "").lower()
        if host_matches(host, "myntra.com"):
            match = re.search(r"/(\d{6,})(?:[/?#]|$)", parsed.path + "?")
            if match:
                return "MYNTRA:" + match.group(1)
        if host_matches(host, "ajio.com"):
            match = re.search(r"/p/([A-Z0-9]+)", parsed.path, re.I)
            if match:
                return "AJIO:" + match.group(1).upper()
        # v17.8: the SAME product reaches us from several sources, each with its
        # own link shape (a slug link, a variant link, an extra ?size= parameter).
        # Keying those on the URL hash made them look like different deals, so the
        # channel posted the same product three times. Every merchant below has a
        # stable product id in its path - take that instead of the whole URL.
        for pattern, label in (
            (r"/p/([A-Za-z0-9]{6,})", "PID"),                  # flipkart /p/ITM..
            (r"/product(?:s)?/[A-Za-z0-9_-]*?-?([A-Za-z0-9]{6,})(?:[/?#]|$)", "PROD"),
            (r"/it/([A-Za-z0-9_-]{4,})", "IT"),                 # croma / reliancetrend
            (r"/([A-Za-z0-9_-]{3,})-([A-Za-z0-9]{6,})\.html", "SKU"),
            (r"/products?/([A-Za-z0-9_-]{6,})", "PROD"),
        ):
            match = re.search(pattern, parsed.path, re.I)
            if match:
                return f"{label}:{host}:{'/'.join(g.lower() for g in match.groups())}"
    except Exception:
        pass
    return None


def verified_product_id(*urls: str | None) -> str | None:
    """A merchant product id proven by a verified URL - never a guess.

    POST-DEPLOY RULE (2026-10-11): dedup keys on VERIFIED identity only. The
    merchant id is read from the resolved merchant page (or, failing that, from
    the verified affiliate destination our own converter produced for it) with
    extract_product_id(). A URL-hash fallback ("URL:...") is opaque - two
    spellings of one product hash apart, two products behind one shortener hash
    together - so it is NOT identity and is never returned here. No product
    name is invented, no merchant page is fetched or inspected: the URL the
    converter already verified is the whole evidence.
    """
    for url in urls:
        if not url:
            continue
        product_id = extract_product_id(url)
        if product_id:
            return product_id
    return None


# Pure hype/banner lines ("TOP DEAL OF THE DAY", "🔥🔥 FLASH SALE ⚡⚡") that a
# source repeats above every single post. They say nothing about the product, so
# they must never be used as a campaign identity on their own.
GENERIC_HEADLINE_RE = re.compile(
    r"(?i)^(?:[\W_]+|top|best|hot|mega|super|dhamaka|dhamal|amazing|awesome|superb|daily|"
    r"latest|new|today|deal|deals|offer|offers|loot|loots|sale|steal|alert|alerts|save|savings|"
    r"price|prices|drop|drops|crash|shocker|shocking|free|gift|bonus|grab|hurry|limited|time|"
    r"of|the|a|an|for|you|your|only|off|in|india|amazon|flipkart|myntra)]+$"
)


def content_deal_key(text: str) -> str | None:
    """Cross-source fingerprint to block the same deal even when short URLs differ.

    The prices/discounts are part of the identity on purpose. Keying on the
    banner line alone (the old behaviour) made EVERY post from a source that
    reuses a hype prefix collapse onto one fingerprint, so after the first post
    the whole source looked "already posted" for ten hours and silently
    disappeared - the exact "source has the posts, our channels do not" gap.
    """
    cleaned = clean_source_text(text)
    cleaned = URL_RE.sub(" ", cleaned)
    cleaned = re.sub(r"(?i)\b(?:buy\s*now|shop\s*now|grab\s*fast)\b", " ", cleaned)
    signals = sorted({re.sub(r"\s+", "", s).lower() for s in re.findall(
        r"₹\s*\d[\d,]*|\d{1,3}\s*%|\d+(?:\.\d+)?\s*off", cleaned)})
    cleaned = re.sub(r"[^\w₹%\n]+", " ", cleaned, flags=re.UNICODE)
    lines = [re.sub(r"\s+", " ", line).strip().lower()
             for line in cleaned.splitlines() if line.strip()]
    if not lines:
        return None
    headline = lines[0]
    # A product-specific headline blocks reposted campaigns even when a later
    # source carries fewer/more variant links. Generic or short banners fall
    # back to the body lines so different products never share a fingerprint.
    specific = (len(headline) >= 18 and len(headline.split()) >= 3
                and not GENERIC_HEADLINE_RE.fullmatch(headline))
    basis = headline if specific else " ".join(lines[:10])
    basis = " ".join(basis.split())
    if signals:
        basis = f"{basis} || {' '.join(signals)}"
    if len(basis) < 18 or len(basis.split()) < 3:
        return None
    return "CONTENT:" + hashlib.sha256(basis.encode()).hexdigest()
# ---------------------------------------------------------------------------
# v17.6 "best copy" selection + numeric fidelity gate
# ---------------------------------------------------------------------------
# Many sources post the SAME product within minutes at different prices. The
# intake order used to decide which copy reached our channels, so a 78%-off
# post could be replaced in the queue by a weaker 65% copy from another channel
# (or the better copy silently dropped by the ledger). Now the queue keeps the
# BEST copy of an exactly-matching product id - never a second row, so nothing
# is duplicated, and the copy it displaced is remembered so the deal is still
# posted if the better copy turns out to be unrenderable.
PRODUCT_ID_RE = re.compile(
    r"(?:/dp/|/gp/product/|/gp/aw/d/|/product[iI]d/|[?&]pid=|/ip/)([A-Za-z0-9]{6,20})")


RUPEE = "\u20b9"  # the only currency symbol these sources publish


def product_identities(text: str) -> list[str]:
    """Merchant product ids a post names, readable WITHOUT the network.

    Only exact ids (/dp/ASIN, flipkart pid, ...) count: a shortener-only post
    yields nothing and is therefore never re-pointed, so a fuzzy match can never
    drop a deal.
    """
    found = []
    for raw in dict.fromkeys(URL_RE.findall(text or "")):
        match = PRODUCT_ID_RE.search(raw)
        if match:
            found.append(match.group(1).upper())
    return list(dict.fromkeys(found))


def comparable_product_ids(items) -> set[str]:
    """Normalise intake ids and rendered deal keys onto the same bare id."""
    out: set[str] = set()
    for item in items or []:
        value = str(item).strip()
        match = re.fullmatch(r"(?:pid|asin|amazon|flipkart):([A-Za-z0-9]{6,20})", value, re.I)
        if match:
            out.add(match.group(1).upper())
        elif re.fullmatch(r"[A-Za-z0-9]{6,20}", value) and re.search(r"\d", value):
            out.add(value.upper())
    return out


def deal_quality_score(text: str) -> int:
    """How good this copy of the deal is (discount-led, price aware)."""
    price = parse_price(text)
    return premium_score(text, price, parse_discount(text, price))


def numeric_tokens(text: str) -> set[str]:
    """Every number a post states, with URLs masked out.

    URL masking matters: our own affiliate tag ("mama086-21"), an ASIN and a
    shortener slug are digits the source text never claimed, and they must not
    be confused with prices or discounts.
    """
    without_urls = URL_RE.sub(" ", text or "")
    return {token.replace(",", "") for token in re.findall(r"\d[\d,]*", without_urls)}


def enforce_numeric_fidelity(source_text: str, rendered: str) -> tuple[str, list[str]]:
    """Gate: a published post may not contain a price/discount figure the source
    never printed. Legitimate text is never touched - only a number that appears
    NOWHERE in the source (URL digits excluded on both sides) is removed, because
    every such number so far has been corruption (a glued shortener token, a
    half-stripped "MRP", a mangled percent). The post itself is kept: dropping a
    live deal to protect formatting is the worse bug.
    """
    allowed = numeric_tokens(source_text)
    notes: list[str] = []
    lines = (rendered or "").split("\n")
    for index, line in enumerate(lines):
        if not line.strip():
            continue
        # Spans are measured on the ORIGINAL line and URL ranges are excluded, so a
        # figure can never be cut out of the middle of a link (`/50%-sale`) while
        # the same digits in the deal text are judged normally.
        spans = [(m.start(), m.end()) for m in URL_RE.finditer(line)]
        cuts: list[tuple[int, int]] = []
        for pattern in (rf"{RUPEE}\s*\d[\d,]*", r"\b\d{1,3}\s*%"):
            for match in re.finditer(pattern, line):
                if any(match.start() < end and match.end() > start for start, end in spans):
                    continue
                digits = re.sub(r"\D", "", match.group(0))
                if not digits or digits in allowed:
                    continue
                cuts.append(match.span())
                notes.append(f"line {index + 1}: {match.group(0).strip()!r}")
        if cuts:
            scrubbed = line
            for start, end in sorted(cuts, reverse=True):
                scrubbed = scrubbed[:start] + " " + scrubbed[end:]
            lines[index] = re.sub(r"[ \t]{2,}", " ", scrubbed).strip(" ,:;|")
    return "\n".join(lines), notes


# Words that name the PRODUCT, not the campaign. A signature is only trusted
# when the headline survives this filter with substance left over, so a shared
# "TOP DEAL OF THE DAY" can never make two different products look identical.
# >>> IDENTITY-START (ops/quality_audit.py mirrors this block; run
#     python3 ops/sync_identity.py after editing it, and test_line_fidelity.py
#     fails if the two copies ever differ)
_SIG_STOP_WORDS = frozenset("""
deal deals dealz offer offers dhamaka dhamal sale salez loot loots price mrp discount off
save savings grab hurry now today daily best top hot new buy shop link links here below click
free shipping delivery cod return warranty genuine flash super mega amazing awesome alert
in india official telegram whatsapp channel group join follow subscribe share forward for
the a an and or of to on in at by with your our this that it is are be get got have has
""".split())
# A number in a product name is either the thing that MAKES it that product
# (1.5 Ton, 5 Star, 128GB, 55-inch, 5 Burner) or a spec a channel may or may not
# bother to type (42H playtime, 5000mAh, 1080p, 4K, 5G). The first group is the
# identity; the second is dropped - demanding that two captions of one product spell
# their battery life alike is exactly how the same deal gets posted twice.
_SIG_VARIANT_UNITS = (
    "gb tb mb kb l ltr liter liters litre litres ml kg ton tons star stars inch "
    "inches in ft hp kva burner burners slice slices tray trays door doors person "
    "persons blade blades"
).split()
_SIG_SPEC_UNITS = (
    "h hr hrs hour hours min mins sec secs mah wh w kw a v p k g fps hz px mm cm m "
    "db rpm mp nit nits lumen lumens mbps gbps byte bytes watt watts"
).split()
_SIG_VARIANT_RE = re.compile(
    r"\b(\d{1,4}(?:\.\d+)?)[\s_-]*("
    + "|".join(map(re.escape, sorted(_SIG_VARIANT_UNITS, key=len, reverse=True))) + r")\b", re.I)
# Words that name a real variant of a model line. "Galaxy S23" and "Galaxy S23 FE"
# share every number and are two different phones, so these belong to the identity.
# Only words that name a genuinely different product line. "smart"/"air"/"elite" are
# marketing adjectives here and there, and a copy that drops one must not turn the
# same watch into a different product - so the list stays short and factual.
# The gender/audience words are here for the same reason as "pro"/"fe": a
# "Nivea MEN Face Wash" and a "Nivea WOMEN Face Wash" are two different products
# at the same price, and with no model number to separate them they used to sign
# identically - so the second one was skipped as a duplicate and that deal never
# reached the channel.
_SIG_VARIANTS = frozenset("""
pro plus max ultra lite neo fe se mini prime classic edge fold flip turbo
men mens women womens kids boys girls unisex
""".split())
# Words that put a number in front of them into a model name: "Pro 4" and "Model
# 2600" are the product, "2023" at the end of a headline is the launch year.
_SIG_QUALIFIERS = _SIG_VARIANTS | frozenset("model series gen generation version".split())
# "by <word>" names the brand ("Airdopes 141 by boAt") EXCEPT when the word in
# front says otherwise: "powered by Helio" names a chipset, not the maker.
_SIG_BY_NON_BRAND = frozenset(
    "powered brought inspired sponsored posted shared sent curated verified".split())
_SIG_AMOUNT_RE = re.compile(
    r"(?i)[\u20b9$]\s*[\d,]+(?:\.\d+)?|\b\d+(?:\.\d+)?\s*(?:%|percent|off)\b|"
    # "70%" followed by a space failed the trailing \b (a percent sign is not a
    # word char), so the discount stayed in the identity and two copies of one
    # deal signed differently whenever the channels typed the discount apart.
    r"\b\d{1,3}\s*%|"
    # A bare number sitting immediately in front of the discount IS the price
    # ("Collagen powder 299 (70% off)"), whatever marker the channel omitted.
    r"\b[\d,]{2,}(?=\s*\(?\s*\d{1,3}\s*(?:%|percent))|"
    # A price written WITHOUT the rupee sign is still a price, not a model
    # number: "@298", "at 167", "Rs 180", "220/-". Leaving these in made the
    # SAME product signed differently depending on how the channel typed its
    # price, so the duplicate slipped through. (A number that is genuinely part
    # of the product - "10KG", "2000ml" - carries a unit and is keyed elsewhere.)
    r"(?:@|\bat\b|\brs\.?|\binr)\s*[\d,]{2,}(?:\.\d+)?\b|\b[\d,]{2,}\s*/-|"
    r"\b(?:mrp|mrp\.?|regular\s+price|list\s+price|strike\s+price)\b\s*[:\-]?[^,|;\n]*")


# The price this LINE quotes, however the channel typed it. Deliberately a small
# self-contained reader rather than a call to parse_price(): this block is mirrored
# verbatim into ops/quality_audit.py by ops/sync_identity.py, so it must not depend
# on anything outside itself or the auditor stops importing.
_SIG_PRICE_RE = re.compile(
    r"(?i)(?:[\u20b9$]|\brs\.?|\binr|@|\bat\b)\s*([\d,]{2,})(?:\.\d+)?\b"
    r"|\b([\d,]{2,})\s*/-"
    r"|\b([\d,]{2,})(?=\s*\(?\s*\d{1,3}\s*(?:%|percent))")


# "₹60k" / "60 K" / "1.5 lakh": the identity rule must read the same money the
# caption wrote. Self-contained on purpose (the block is mirrored into
# ops/quality_audit.py), so the expansion is inline rather than a call to
# deal_facts.expand_money_suffixes.
_SIG_MULTIPLIER_RE = re.compile(
    r"(?<![\dA-Za-z.,])(\d[\d,]*(?:\.\d+)?)\s*(k|K|lakhs?|lacs?|crores?|cr)\b")


def _sig_expand_money(text: str) -> str:
    def expand(match: re.Match) -> str:
        unit = match.group(2).lower()
        factor = 1_000 if unit == "k" else 100_000 if unit.startswith(("lakh", "lac")) else 10_000_000
        try:
            value = float(match.group(1).replace(",", "")) * factor
        except ValueError:
            return match.group(0)
        return str(int(value)) if value == int(value) else match.group(0)

    return _SIG_MULTIPLIER_RE.sub(expand, text or "")


def _sig_line_price(line: str) -> int | None:
    match = _SIG_PRICE_RE.search(_sig_expand_money(line))
    if not match:
        return None
    raw = next((g for g in match.groups() if g), "")
    try:
        value = int(str(raw).replace(",", ""))
    except ValueError:
        return None
    return value if 1 <= value <= 1_000_000 else None


def _sig_tokens(line: str) -> list[str]:
    """Lower-case tokens with punctuation trimmed off the ENDS only.

    Trimming ends instead of deleting every symbol keeps a model number whole:
    "WH-CH720N" stays one token and "1.5 Ton" stays one number, instead of
    splitting into a stray "1" and "5" that read as two different products.
    """
    named = _SIG_AMOUNT_RE.sub(" ", line or "")
    named = re.sub(r"(?i)\b(?:%|percent|off)\b", " ", named)
    out = []
    for token in named.split():
        token = re.sub(r"^[^\w.]+", "", token)
        token = re.sub(r"[^\w.]+$", "", token).strip(".")
        if token and re.search(r"[A-Za-z0-9]", token):
            out.append(token.lower())
    return out


# Ordinary descriptive words. A phrase built ONLY from these ("Men Cotton
# Shirt", "hair oil set") describes a category, not a product, so it needs the
# longer floor before it may be used to skip a repeat.
_SIG_GENERIC_WORDS = frozenset("""
men mens women womens kids boys girls baby unisex adult
hair face body skin lip eye nail hand foot head neck
phone mobile laptop tablet tv led smart wireless bluetooth usb
lunch dinner tea coffee water milk rice

cotton silk leather steel plastic glass wooden metal rubber silicone
shirt tshirt pant jeans saree kurti dress top jacket shoes sandals slippers
oil soap cream powder shampoo lotion gel wash paste
bottle box case cover bag pouch set combo pack piece pieces
watch band strap cable charger adapter holder stand mat mop broom
kitchen home office travel sports gaming
small medium large xl xxl free size regular fit slim
new best top premium quality original genuine
""".split())


# Ordinary product nouns and descriptive adjectives. A phrase built only from
# these plus _SIG_GENERIC_WORDS names a CATEGORY ("Running Shoes", "Shirt A"),
# never one product, so it must clear the length floor before it may be used
# to skip a repeat.
_SIG_PRODUCT_NOUNS = frozenset("""
shoes sneakers boots sandal sandals slipper slippers flipflop
shirt tshirt shirts pant pants trouser trousers jeans short shorts
kurta kurti saree dress top tops jacket coat sweater hoodie
bottle flask jar container tiffin lunchbox casserole
mixer grinder kettle cooker pan pot tawa knife spoon plate bowl
headphone headphones earphone earphones earbuds neckband speaker
watch smartwatch band tracker
bag backpack luggage trolley wallet purse belt
running walking sports casual formal party daily regular
trimmer shaver dryer straightener iron fan heater cooler lamp bulb
sheet curtain pillow blanket mattress towel mat rug carpet
""".split())


def _product_identity(line: str) -> tuple[str, ...] | None:
    """The few tokens that decide WHICH product a headline names, as a SET.

    Not a slice of the phrase: "boAt Airdopes 141 TWS Earbuds" and "boAt Airdopes
    141 True Wireless Earbuds, 42H Playtime" are one product wearing different
    adjectives, while "Airdopes 141" and "Airdopes 131" are two products differing
    by nothing but the model number. Hashing the first eight words gets BOTH wrong -
    the duplicate survives and two long-named products collapse into a lost deal.

    So the identity is: the brand word, the model numbers (with the word in front of
    them when they are short, "Pro 4" and "Pro4" being one product), the variant
    qualifiers (pro / fe / max) and the numbers that change the product (capacity,
    tonnage, star rating, size, burner count). Extra marketing words then cost
    nothing, and a different model number can never be skipped as "already posted".
    With no number to hold on to (a shirt, a handbag) every product word has to
    agree instead - the conservative answer that loses a duplicate rather than a deal.
    """
    # A bare number that is simply the line's PRICE is not a model number.
    # "Nutriburst Collagen powder 299" and "Nutriburst Collagen powder @ 299"
    # are one product; only the second spelling was recognised as money, so the
    # first signed "299" as a model and the duplicate got published twice.
    line_price = _sig_line_price(line or "")
    raw = [re.sub(r"[-_]", "", tok) for tok in _sig_tokens(line)]
    # A URL is not part of the product's NAME. When the source writes the link
    # on the same line ("Shirt A 599 https://a.com/x") the host used to become
    # an identity word, which both invented an identity for a generic phrase
    # and made the same product hash differently once its link changed.
    raw = [w for w in raw
           if not w.startswith(("http", "www")) and "/" not in w and "." not in w]
    words = [w for w in raw if not w.isdigit() and w not in _SIG_STOP_WORDS]
    if len(words) < 2:
        return None
    spec_units = frozenset(_SIG_SPEC_UNITS)
    variant_units = frozenset(_SIG_VARIANT_UNITS)
    ids = {f"{number}{unit}".lower().replace(" ", "").replace("-", "")
           for number, unit in _SIG_VARIANT_RE.findall(line or "")}
    digit_cores = {re.sub(r"\D", "", value) for value in ids}
    models = set()
    for index, token in enumerate(raw):
        if token in _SIG_STOP_WORDS:
            continue
        digits = re.sub(r"\D", "", token)
        if not digits or len(digits) < 1 or len(digits) > 6:
            continue                       # a phone number or a year is not a model
        glued = re.match(r"^(\d{1,6})([a-z]{1,6})$", token)
        if glued:                          # 42h, 1080p, 55inch, 5g
            unit = glued.group(2)
            if unit in spec_units or unit in variant_units:
                continue                   # already handled as a spec or a size id
        if re.match(r"^[a-z]{1,7}\d{1,6}[a-z]{0,3}$", token):
            models.add(token)              # s23, ch720n, pro4, m14
            continue
        if token.isdigit():
            following = raw[index + 1] if index + 1 < len(raw) else ""
            if following in spec_units or following in variant_units:
                continue                   # "128 GB" and "42 H" are keyed above
            previous = raw[index - 1] if index > 0 else ""
            if previous in _SIG_QUALIFIERS:
                models.add(previous + digits)   # "Pro 4" / "Model 2600" is the model
                continue
            if len(digits) < 2 or (len(digits) == 4 and 1900 <= int(digits) <= 2099):
                continue                   # a quantity, or a launch year - not an id
            if line_price is not None and int(digits) == line_price:
                continue                   # that is the price, however it was typed
            if digits in digit_cores:
                continue                   # the number is already inside a size id
            models.add(token)
    variants = {t for t in raw if t in _SIG_VARIANTS}
    if not ids and not models:
        # No number to hold on to, so every product word has to agree. THREE
        # words is enough when they are long enough to be a real product name
        # ("Nutriburst Collagen powder"): demanding four made a named product
        # with no model number un-dedupable, which is how the same collagen
        # powder went out twice under two different banner words. A short
        # category phrase ("hair oil set") still fails the length test below.
        # USER REPORT (2026-09-06): "Ergonomic Dustpan @ 55" went out TWICE in
        # the same channel. Two long, specific words ARE a product name; the
        # three-word floor left every such post with no identity at all, so the
        # per-channel repeat guard never ran on them. Two words are accepted
        # when they are long and specific enough not to be a category phrase
        # ("hair oil", "phone case" stay un-keyed via the length test below).
        if len(words) < 2:
            return None                    # a category phrase is not an identity
        # REGRESSION GUARD (2026-09-06): "Cello Lunch Box" is three real product
        # words but only 15 characters, so an 18-char floor gave it no identity
        # and the same lunch box could post twice. THREE words are already
        # specific enough - the floor exists to reject two-word category phrases
        # ("hair oil"), not to reject short real names. Four+ words are always
        # specific. Only the two-word case still needs the length test.
        # The floor exists to reject GENERIC phrases ("Men Cotton Shirt",
        # "hair oil") that many different products share - keying on those
        # would suppress real deals. It must not reject a short but SPECIFIC
        # name: "Cello Lunch Box" is 15 characters and names one product, and
        # an 18-char floor left it un-dedupable, which is how the same lunch
        # box could post twice.
        # A brand-like word - one that is not an ordinary descriptive word -
        # makes the phrase specific regardless of its length.
        # The floor rejects GENERIC phrases ("Men Cotton Shirt", "hair oil")
        # that many products share; keying on those would suppress real deals.
        # It must not reject a SHORT but specific name. "Cello Box" is nine
        # characters, yet "cello" is a brand - one product, and without an
        # identity it could post twice, which is the defect the user reported.
        # So a phrase that pairs a brand-like word with a descriptive one is
        # specific enough at two words; only all-generic phrases need length.
        # The floor rejects GENERIC phrases ("Men Cotton Shirt", "Running
        # Shoes") that many products share; keying on those would suppress
        # real deals. It must not reject a SHORT but specific name: "Cello
        # Box" is nine characters, yet "cello" is a BRAND - one product - and
        # with no identity it could post twice.
        #
        # A brand is recognised as a word that is neither descriptive nor a
        # known product noun: "cello", "milton", "dabur", "nike". "Running
        # Shoes" and "Shirt A" have no such word, so they keep the floor.
        basis = " ".join(sorted(set(words)))
        # A URL is never a brand. When a source writes the link on the same
        # line as the name ("Shirt A 599 https://a.com/x"), "https" and the
        # host would otherwise read as brand words and give a generic
        # category phrase an identity it must not have.
        # A single letter is a list marker or a size ("Shirt A", "Shirt B"),
        # never a brand: treating it as one gave every row of a three-shirt
        # roundup its own identity and broke the multi-product rule.
        brandish = [w for w in words
                    if len(w) > 1
                    and w not in _SIG_GENERIC_WORDS and w not in _SIG_PRODUCT_NOUNS]
        if brandish and len(words) >= 2:
            return ("W", basis)
        floor = 15 if brandish else 18
        return None if len(basis) < floor else ("W", basis)
    # The brand is normally the first product word, but "Airdopes 141 by boAt"
    # and "boAt Airdopes 141" are ONE product: an explicit "by <maker>" names
    # the brand outright and wins over word order, so the reordered copy can
    # never slip past dedup as a second post. "powered by Helio" and friends
    # name a component, not the maker, and are ignored.
    brand = words[0]
    for index, token in enumerate(raw[:-1]):
        if token == "by" and (index == 0 or raw[index - 1] not in _SIG_BY_NON_BRAND):
            candidate = raw[index + 1]
            if candidate in words:
                brand = candidate
                break
    parts = ["M", brand, " ".join(sorted(models | ids))]
    if variants:
        parts.append(" ".join(sorted(variants)))
    return tuple(parts)


# <<< IDENTITY-END

def product_signature(text: str) -> str | None:
    """A conservative "which product is this?" key, used ONLY to skip a repeat.

    Why not the link: two sources paste the same product through two different
    shorteners, and until each one is resolved the merchant ids simply look
    different - which is how a channel carried the same earphones twice. So the
    identity here is the product's OWN words - brand, model number, variant,
    capacity - and nothing else: identical for an /dp/ASIN post and a bitli post
    of the same item, different for 128GB vs 256GB and for 141 vs 131.

    Deliberately narrow so a real deal is never lost on a false match:
      * a single-product post only (3+ merchant links is a roundup, and roundups
        legitimately share items with each other);
      * a headline naming a brand plus a model number (or four product words);
      * a merchant link must be present at all (a pure text blurb gets no key).
    The key never swaps, reorders or rewrites anything: its whole job is to skip
    a product this channel has already shown - which is what the user asked for.
    """
    if not text:
        return None
    urls = [clean_url(u) for u in dict.fromkeys(URL_RE.findall(text))]
    merchant_links = 0
    for url in urls:
        host = (urlparse(url).hostname or "").lower()
        if host and not in_domains(host, NON_STORE_DOMAINS):
            merchant_links += 1
    if merchant_links == 0:
        return None
    if merchant_links >= 3:
        # A ROUNDUP. Until now these got no key at all, so the same list
        # arriving again from a second source - different shortener, different
        # banner - was invisible to the per-channel repeat guard and the channel
        # carried it twice. That is the "multiple times" the user reported.
        # A roundup's identity is the SET of products it lists: order-independent
        # (sources shuffle the order), link-independent (shorteners differ),
        # banner-independent. Two roundups that list the same items ARE the same
        # post; a roundup that adds or drops an item is a different one and still
        # goes out.
        return _roundup_signature(text)
    headline = None
    for line in clean_source_text(text).splitlines():
        line = line.strip()
        if not line or URL_RE.search(line):
            continue
        if TIME_OF_DAY_RE.search(line) or GENERIC_HEADLINE_RE.fullmatch(line.lower()):
            continue                       # a hype banner is not a product name
        if not re.search(r"[A-Za-z]", line):
            continue                       # a bare price / separator line
        # USER RULE (2026-09-05): "Loot : X" and "Grab : X" are the SAME product
        # wearing two different banner words, and the banner used to be read as
        # the brand - so the identity differed and the same deal was published
        # twice. The banner prefix is source decoration; strip it before the
        # product's own words are read. (_SAFE_PREFIX_RE is the same list the
        # programme-safe rewrite uses, so the two can never drift apart.)
        line = _SAFE_PREFIX_RE.sub("", line).strip() or line
        identity = _product_identity(line)
        if identity:
            headline = identity
            break
    if not headline:
        return None
    basis = "|".join(headline)
    return "SIG:" + hashlib.sha256(basis.encode()).hexdigest()[:32]


def _roundup_signature(text: str) -> str | None:
    """Identity of a multi-product list: the set of products it names.

    Built from the same _product_identity() the single-product path uses, so a
    roundup and its repeat agree even when the two sources write different
    banners, different prices formats and different short links.
    """
    items: set[str] = set()
    for line in clean_source_text(text or "").splitlines():
        line = line.strip()
        if not line or URL_RE.fullmatch(line):
            continue
        line = URL_RE.sub(" ", line).strip()
        if not line or TIME_OF_DAY_RE.search(line) or GENERIC_HEADLINE_RE.fullmatch(line.lower()):
            continue
        if not re.search(r"[A-Za-z]", line):
            continue
        line = _SAFE_PREFIX_RE.sub("", line).strip() or line
        identity = _product_identity(line)
        if identity:
            items.add("|".join(identity))
    # Two items is the floor: below that this is not a list, and a one-item
    # match is too thin to justify dropping a live deal.
    if len(items) < 2:
        return None
    basis = "\n".join(sorted(items))
    return "LIST:" + hashlib.sha256(basis.encode()).hexdigest()[:32]


def product_key(value: str) -> str:
    return extract_product_id(value) or "URL:" + hashlib.sha256(merchant_url(value).encode()).hexdigest()


def classify_priority(text: str, has_media: bool = False) -> int:
    """Priority for the Telegram delivery queue.

    Order (highest first):
      5  = best-list / mega product list (>=4 distinct merchant links)
      4  = credit card / bank offer, OR super deal >=80% off
      3  = strong deal, 75%+ off
      2  = photo/video post
      1  = ordinary deal
    """
    value = text or ""
    link_count = len(set(clean_url(u) for u in URL_RE.findall(value)))
    if link_count >= 4:
        return 5
    if has_card_offer(value):
        return 4
    # Zomato/Swiggy/Zepto/movie/card-app offers are best-tier for subscribers.
    if has_service_offer(value):
        return 4
    discount = parse_discount(value)
    if discount is not None and discount >= 80:
        return 4
    if discount is not None and discount >= 75:
        return 3
    if has_media:
        return 2
    return 1


def has_card_offer(text: str) -> bool:
    value = text or ""
    return bool(re.search(
        r"\b(?:credit\s*card|debit\s*card|bank\s*offer|card\s*offer|"
        r"(?:pnb|hdfc|icici|sbi|axis|kotak|idfc|au\s*bank).{0,60}"
        r"(?:off|discount|cashback|card))\b",
        value, re.I | re.S,
    ))


# Service / lifestyle offers: food delivery, movies, quick commerce, payment
# apps and bank/card promo pages. They are NOT EarnKaro-monetizable store
# products. Strict-all refuses these link-bearing posts; the legacy formatting
# path keeps the classifier isolated so service URLs never enter store conversion.
SERVICE_OFFER_DOMAINS = {
    "zomato.com", "zomato.in", "zom.to", "swiggy.com", "swiggy.in",
    "zepto.com", "dominos.in", "pizzahut.co.in", "pizzahut.com",
    "bookmyshow.com", "pvr.in", "inoxmovies.com", "amctheatres.in",
    "bigcinema.com", "phonepe.com", "amazonpay.in", "paytm.com",
    "magicpin.in",
}
SERVICE_OFFER_RE = re.compile(
    r"\b(?:zomato|swiggy|zepto|bookmyshow|domino(?:s)?|pizza\s*hut|"
    r"movie\s*(?:tickets?|shows?|offers?|booking)|cinema\s*(?:offers?|tickets?)|"
    r"pvr|inox|amc\s*theatres?|bigcinema|phonepe|amazon\s*pay|paytm|magicpin)\b",
    re.I,
)


def has_service_offer(text: str) -> bool:
    return bool(SERVICE_OFFER_RE.search(text or ""))


def automatic_price_targets(price: int | None) -> list[str]:
    targets = []
    if price is not None and price <= 99:
        targets.extend([UNDER99_TARGET, UNDER499_TARGET])
    elif price is not None and price <= 499:
        targets.append(UNDER499_TARGET)
    return targets


def eligible_for_under499_best(text: str, price: int | None, discount: int | None,
                               card_offer: bool) -> bool:
    """under499loots is the main feed: best deals from every configured source.

    Price routing already covers everything at or below ₹499. This adds the
    strong deals whose price the source never printed in a parseable form, so a
    genuine loot is not skipped merely because no "₹" appeared in the text. A
    post with a visible price above ₹499 is still excluded, keeping the channel
    name honest.
    """
    if price is not None:
        return price <= 499
    if discount is not None and discount >= 80:
        return True
    if has_lowest_price_claim(text) and (discount or 0) >= 60:
        return True
    return bool(card_offer and discount is not None and discount >= 70)


def eligible_for_power_loots(price: int | None, discount: int | None,
                             card_offer: bool = False) -> bool:
    """PowerLoots1 gets <=₹499, >=70%-off, or explicit bank/card offers."""
    return (
        (price is not None and price <= 499)
        or (discount is not None and discount >= 70)
        or card_offer
    )


def append_folder_link(text: str) -> str:
    """Clean, source-derived tail: the Loots Family folder link only."""
    return f"{text.rstrip()}\n\n📂 All Loot Channels — One Tap\n👉 {OUR_FOLDER_LINK}"


def eligible_for_secret(text: str, price: int | None, discount: int | None,
                        multi_product_list: bool, card_offer: bool) -> bool:
    """High-value Secret channel: fewer, stronger deals instead of every post."""
    if multi_product_list:
        return True
    if discount is not None and discount >= 80:
        return True
    if price is not None and price <= 99 and discount is not None and discount >= 60:
        return True
    if price is not None and price <= 499 and has_lowest_price_claim(text):
        return True
    return bool(card_offer and discount is not None and discount >= 70)


def tricks_footer() -> str:
    return (
        "🔥 JOIN OUR COMPLETE LOOT FAMILY\n\n"
        f"📂 All Loot Channels — One Tap\n👉 {OUR_FOLDER_LINK}\n\n"
        f"🔒 Secret Loot India\n👉 {OUR_MAIN_CHANNEL_LINKS[0]}\n\n"
        f"⚡ Loot Zone India\n👉 {OUR_MAIN_CHANNEL_LINKS[1]}"
    )


def extract_deal_prices(text: str) -> list[int]:
    values = []
    for line in (text or "").splitlines():
        if re.search(r"\b(?:mrp|regular\s*price|coupon|cashback|bank)\b", line, re.I):
            continue
        for raw in re.findall(r"₹\s*([\d,]+)", line):
            value = int(raw.replace(",", ""))
            if 1 <= value <= 1_000_000:
                values.append(value)
    return values


def extract_urls(msg) -> list[str]:
    values: list[str] = []
    # msg.message is the raw text the entity offsets are measured on; msg.text
    # may carry parse-mode markdown ("**") that shifts every offset after it.
    text = msg.message or msg.text or ""
    surrogate_text = add_surrogate(text)
    values.extend(URL_RE.findall(text))
    for intent in INTENT_RE.findall(text):
        parsed = parse_intent(intent)
        if parsed:
            values.append(parsed)
    for entity in getattr(msg, "entities", None) or []:
        if isinstance(entity, MessageEntityTextUrl) and entity.url:
            values.append(entity.url)
        elif isinstance(entity, MessageEntityUrl):
            # Telegram offsets are UTF-16 code units. Python indexes Unicode
            # code points, so emoji before a URL otherwise shifts/slices it.
            values.append(del_surrogate(
                surrogate_text[entity.offset:entity.offset + entity.length]
            ))
    markup = getattr(msg, "reply_markup", None)
    if isinstance(markup, ReplyInlineMarkup):
        for row in markup.rows:
            for button in row.buttons:
                url = button_url(button)
                if url:
                    values.append(url)
    seen, result = set(), []
    for value in values:
        value = clean_url(value)
        if value.startswith("http") and value not in seen:
            seen.add(value)
            result.append(value)
    return result

# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------
CK_FOOTER_RE = re.compile(
    r"\n?#Flipkart\s*\n[-—_ ]*\n💰\s*Want Real Cash Back Too\?.*?"
    r"Forward to\s*@cashkarolink_?bot\s*\n[-—_ ]*",
    re.I | re.S,
)
SOURCE_NOISE_LINE_RE = re.compile(
    r"(?im)^\s*(?:"
    r".*deal\s*time\s*:.*(?:IST)?|"
    r".*\bloot\s+fa+s+\s*t+\b.*|"
    r".*(?:@GrabOnIndiaOfficial|50\+\s*loots\s*daily).*|"
    r"\s*(?:h|ht|htt|https?|ttp|ttps|tps?://|s://|://|uy)\s*|"
    r"👉.*(?:https\s*:\s*are)|"
    r"💰?\s*want\s+real\s+cash\s*back\s+too\??|"
    r"forward\s+to\s+@cashkarolink_?bot|"
    r"#(?:myntra|flipkart|amazon|ajio)"
    r")\s*$"
)
# Source-channel promo / navigation boilerplate (join/follow/share/notify CTAs,
# t.me self-promo, deal-time, @handles, emoji-only lines) that is NOT part of a
# deal. Stripped only when the line has no real deal content (no link, price,
# discount % or 3+ product words), mirroring the WhatsApp bridge cleanup.
PROMO_PATTERNS_PY = [
    re.compile(r"t\.me/|telegram\.(?:me|dog)/", re.I),
    re.compile(r"whatsapp\.com/(?:channel|invite)|wa\.me/", re.I),
    re.compile(r"\bjoin\b", re.I),
    re.compile(r"\bsubscribe\b|\bfollow\s+(?:us|our)\b", re.I),
    re.compile(r"\bshare\b[^.\n]{0,40}\b(with|your|everyone|friends?|groups?|channel|family)\b", re.I),
    re.compile(r"\bforward\b[^.\n]{0,30}\b(to|our|everyone|friends?|groups?)\b", re.I),
    re.compile(r"\b(click|tap)\s+(?:here|link|below|on\s+the\s+link)\b", re.I),
    re.compile(r"\b(turn\s+on|enable|activate)\b[^.\n]{0,25}\bnotifications?\b", re.I),
    re.compile(r"\b(?:don'?t|do\s+not|never)\s+miss\b|\bmiss\s+(?:it|this|out)\b", re.I),
    re.compile(r"\bdeal\s*time\s*[:\-]", re.I),
    re.compile(r"\bgrab\s+(?:it|fast|now|your|this)\b", re.I),
    re.compile(r"\bhurry?\s*up\b", re.I),
    re.compile(r"\bstay\s+(?:tuned|connected|updated)\b", re.I),
    re.compile(r"📢|🔔|📣|⏰"),
    # Referral / app-install spam that carries no deal content (user rule: no
    # unwanted words in our posts).
    re.compile(r"\brefer\s+(?:a\s+)?(?:friend|mate|user)s?\b", re.I),
    re.compile(r"\b(?:earn|win|get)\s+(?:₹|rs\.?|inr\s?)\s*\d+\s*(?:on|for|by|each)?\s*"
               r"\b(?:referral|refer|sign\s*-?\s*up|signup|invite)\b", re.I),
    re.compile(r"\binstall\s+(?:the\s+|our\s+|this\s+)?(?:app|apk)\b", re.I),
    re.compile(r"\b(?:sent|posted|powered)\s+via\s+\S+|\bvia\s+\w+\s+admin\b", re.I),
]
_PROMO_WORD_RE = re.compile(
    r"t\.me|telegram|whatsapp|join|subscribe|follow|share|forward|click|tap|"
    r"notification|notifications|hurry|grab|miss|deal|deals|offer|offers|loot|loots|"
    r"channel|group|friends?|everyone|family|buy|shop|order|now|here|link|below|"
    r"this|that|your|our|us|out|on|off|and|the|for|get|more|new|daily|fast|time|"
    r"turn|enable|activate|don'?t|do|not|never", re.I)


def is_promo_only_url(url: str) -> bool:
    """True for social/channel/navigation links — never merchant deal content."""
    try:
        host = (urlparse(clean_url(url)).hostname or "").lower()
    except Exception:
        return True
    if not host:
        return True
    return in_domains(host, NON_STORE_DOMAINS)


# Channel invite/forward links: a line that carries one of these is boilerplate
# by definition (we always replace source self-promo with OUR folder/channel).
CHANNEL_INVITE_URL_RE = re.compile(
    r"(?i)t\.me/(?:addlist/|joinchat/|\+)|telegram\.me/(?:\+|joinchat/)"
    r"|whatsapp\.com/(?:channel|group)/"
)
# Wording that marks a line as channel navigation rather than deal content.
PROMO_INTENT_RE = re.compile(
    r"(?i)\b(?:join|subscribe|follow|unfollow|share|forward|visit|open|check|"
    r"notify|notifications?|turn\s+on|enable|activate)\b"
    r"|\bfor\s+more\b|\bmore\s+(?:loot|deal|update)s?\b"
    r"|\bour\s+(?:channel|group|whatsapp|telegram)\b|\b(?:our|the)\s+official\s+channel\b"
)


# Referral/invite farming is never deal content, even when a ₹ amount appears
# in the sentence — dropped ahead of the price guard on purpose.
REFERRAL_SPAM_RE = re.compile(
    r"(?i)\b(?:refer|invite)\s+(?:a\s+)?(?:friend|mate|user|family|one)\b"
    r"|\b(?:earn|win|get)\s+(?:₹|rs\.?|inr\s?)?\s*\d+\s*(?:each|per\s+user)?\s*"
    r"(?:on|for|by|after|in)?\s*(?:referral|referrals|refer|invite|signup|sign\s*-?\s*up)\b"
    r"|\b(?:referral|invite)\s+code\b"
    # Loot channels staple an app-install / refer-N-friends block under the real
    # deal ("Get Flipkart App - Refer 3 friends and \u20b9100 referral bonus"). Such
    # a line carries a \u20b9 amount, so the price guard alone used to keep it alive.
    r"|\b(?:refer|invite)\b[^.\n]{0,40}\b(?:friends?|mates?|budd(?:y|ies)|users?)\b"
    r"|\b(?:referral|invite|sign\s*-?\s*up|joining)\s*(?:bonus|reward|cashback|incentive)\b"
    r"|\binstall\s+(?:the\s+|our\s+|this\s+)?(?:app|apk)\b"
)


def is_promo_noise_line(line: str) -> bool:
    """True only for pure promo/navigation boilerplate (no deal content)."""
    t = (line or "").strip()
    if not t:
        return False
    if REFERRAL_SPAM_RE.search(t):
        return True
    urls = URL_RE.findall(t)
    if urls:
        # A real merchant link is always deal content. But a line whose ONLY
        # links are social/channel links is boilerplate: dropping the whole line
        # is also what stops half-stripped residue (`.com/channel/0029`,
        # `.me/someotherchannel`) from leaking into our posts.
        if any(not is_promo_only_url(url) for url in urls):
            return False
        if CHANNEL_INVITE_URL_RE.search(t) or PROMO_INTENT_RE.search(t):
            return True
        return any(rx.search(t) for rx in PROMO_PATTERNS_PY)
    if re.search(r"[₹$]|\b(?:rs\.?|inr|mrp)\b", t, re.I):
        return False
    if re.search(r"\d+\s*%", t):
        return False
    if re.match(r"^[@#][\w]+$", t):
        return True
    if not re.search(r"[A-Za-z0-9\u0900-\u097F\u0C00-\u0C7F]", t):
        return True
    content_words = [w for w in _PROMO_WORD_RE.sub(" ", t).split() if re.search(r"[A-Za-z0-9]", w)]
    if len(content_words) >= 3:
        return False
    return any(rx.search(t) for rx in PROMO_PATTERNS_PY)


# STRICT global CTA/promo phrases removed ANYWHERE on a source line (not just
# the end). Only unambiguous channel boilerplate is listed; genuine deal words
# ("use code X", "free shipping", coupon/cashback/product terms) are untouched.
# Runs only on SOURCE text (our own headers/footers are added afterwards, so our
# branding is never affected).
# v17.8 A CTA clause may only ever swallow PLAIN WORDS. The tails used to be
# `[^.\n|]*$` - "everything up to the end of the line" - so a source line like
# "More offers: Apply coupon PEOPLE200" lost its coupon code and "…(78% off) buy
# now ₹199" lost the deal. A price, a digit, a percentage, a code-looking token
# or a link now ends the clause, and the rest of the line is published verbatim.
CTA_TAIL_PY = (
    r"(?:[ \t]+(?![₹$%])(?![A-Za-z0-9+/.*\-]*\d)(?![A-Za-z0-9+/.\-]*%)"
    r"(?![A-Za-z]*://)[^\s₹$%|]+)*"
)

GLOBAL_CTA_PATTERNS_PY = (
    r"\b(?:buy|shop|order|grab|get)\s+(?:it\s+)?now\b[!^0-9]*",
    r"\bgrab\s+(?:it|this|your|yours|fast)\s*(?:now|fast|soon)?\b[!^0-9]*",
    r"\bget\s+yours?\b[!^0-9]*",
    r"\bbuy\s+(?:it\s+)?here\b", r"\bshop\s+here\b", r"\border\s+here\b",
    rf"\b(?:click|tap)\s+(?:here|the\s+link|on\s+(?:the\s+)?link|below|to\s+(?:buy|order|shop))\b{CTA_TAIL_PY}",
    rf"\b(?:don'?t|do\s+not|never)\s+miss\s+(?:it|this|out|the\s+deal|this\s+deal)\b{CTA_TAIL_PY}",
    # "Hurry up guys 🏃 limited stock" — the hype words AFTER the CTA are the
    # same boilerplate and go with it; the tail stops at any price/digit/link,
    # and the fidelity guard restores the line if real deal payload was taken.
    # A standalone "Limited stock" (availability info on a coupon/deal line)
    # is deal CONTENT and stays — only the hurry-up clause takes it along.
    # "up" is optional: "Hurry!!", "Hurry limited period deal!!!" and
    # "Hurry, grab fast" are the same channel hype as "Hurry up guys".
    rf"\bhurry(?:\s*up)?\b[!,.]*{CTA_TAIL_PY}",
    rf"\bloot\s+(?:it\s+)?fa+s*t+\b!*{CTA_TAIL_PY}",
    rf"\bturn\s+on\s+notifications?\b{CTA_TAIL_PY}",
    rf"\bstay\s+tuned\b{CTA_TAIL_PY}",
    rf"\blink\s+(?:in\s+(?:bio|comments?|description)|below)\b{CTA_TAIL_PY}",
    rf"\bcheck\s+(?:link|bio|description|comments?|pinned|our\s+channel)\b{CTA_TAIL_PY}",
    rf"\bshare\s+(?:it\s+)?(?:with|to)\s+[^.\n|]*\b(?:friends?|family|groups?|everyone)\b{CTA_TAIL_PY}",
    r"\bforward\s+to\s+@?\w+[^.\n|]*",
    rf"\b(?:visit|open)\s+(?:our\s+)?(?:channel|t\.me/\S+|whatsapp\s+channel)\b{CTA_TAIL_PY}",
    # "... from our telegram channel" style attribution glued inside a deal
    # line: the phrase goes, the price next to it stays.
    r"\b(?:from|on|via|in|at)\s+our\s+(?:official\s+)?(?:telegram|whatsapp|t\.me)\s*(?:channel|group|bot|link)?\b",
    rf"\b(?:join|subscribe|follow)\s+(?:our\s+)?(?:us\s+)?(?:channel|telegram|whatsapp\s+channel|group|now)\b{CTA_TAIL_PY}",
    r"\b(?:join|subscribe|follow)\s+(?:our\s+)?(?:us\s+)?(?:on|via)?\s*t\.me/\S+",
    rf"\b(?:for\s+more|more\s+)(?:loot|deal|update|offer)s?\b{CTA_TAIL_PY}",
    r"\bt\.me/\S+", r"\bwhatsapp\.com/(?:channel|invite)/\S+", r"\bwa\.me/\S+",
)


def deal_payload_signature(text: str) -> tuple[set[str], set[str], set[str]]:
    """(prices, discounts, code-like tokens) a line carries - what cleaning must
    never take away from a source post."""
    t = text or ""
    prices = {re.sub(r"[^\d]", "", p) for p in re.findall(r"₹\s*\d[\d,.]*", t)}
    percents = {m for m in re.findall(r"(\d{1,3})\s*(?:%|percent)", t, re.I)}
    codes = {c.upper() for c in re.findall(
        r"\b(?:[A-Z]{2,}\d[\dA-Z]*|\d+[A-Z]{2,}[\dA-Z]*)\b", t) if len(c) >= 5}
    return prices, percents, codes


def strip_inline_cta(line: str) -> str:
    """Remove CTA/promo from a deal line so channel boilerplate never appears
    next to the price. Global phrases are stripped anywhere on the line; a
    trailing CTA is trimmed to the sentence boundary. Product name, price, MRP,
    coupon ("use code X") and specs are left intact."""
    out = (line or "").replace("*", " ")
    for pattern in GLOBAL_CTA_PATTERNS_PY:
        out = re.sub(pattern, " ", out, flags=re.I)
    patterns = (
        rf"\b(?:buy|shop|order|grab|get|check|add\s+to\s+cart)\s+"
        rf"(?:it|now|fast|soon|today|yours?|this|the\s+deal|deal|fast\s+guys?|guys?)\b{CTA_TAIL_PY}",
        rf"\b(?:click|tap)\s+(?:here|link|below|on\s+(?:the\s+)?link|to\s+(?:buy|order|shop))\b{CTA_TAIL_PY}",
        rf"\b(?:don'?t|do\s+not|never)\s+miss\b{CTA_TAIL_PY}",
        rf"\bmiss\s+(?:it|this|out|the\s+deal)\b{CTA_TAIL_PY}",
        r"\b(?:hurry(?:\s*up)?|grab\s+(?:it|fast|now|your|this)|loot\s+fast|"
        r"deal\s+time[^\n]*|limited(?:\s*time)?\s+offer)\b[^.|\n]*$",
        # Social/channel CTAs (join/follow/share/notifications/t.me) are handled
        # by the bounded global patterns above so a following price is never eaten.
        rf"\b(?:link\s+in\s+bio|link\s+below|check\s+(?:link|bio|description|comments?|pinned))\b{CTA_TAIL_PY}",
    )
    for pattern in patterns:
        out = re.sub(pattern, " ", out, flags=re.I)
    out = re.sub(r"\s{2,}", " ", out)
    # A removed clause must not leave its own punctuation behind: stripping
    # "More offers" out of "More offers: Apply coupon X" used to publish a line
    # that OPENED with a colon, which reads exactly like bot damage.
    # Leading and trailing sweeps are split on purpose: the trailing one must
    # not eat the "-" of the Indian "/-" price suffix (USER REPORT 2026-10-18) -
    # "Price: ₹18,999/-" posted as "₹18,999/". The payload signature below
    # cannot catch this: the digits survive, only the suffix dash goes.
    out = re.sub(r"^[\s|*•:,;\-\u2013\u2014~]+", "", out)
    out = re.sub(r"(?<!/)[\s|*•:,;\-\u2013\u2014~]+$", "", out).strip()
    # Fidelity rule (user, round 10): a lost line is as bad as an added one. If a
    # CTA clause took the price, the discount or the coupon code with it, the
    # clause removal is undone for that line - the source wrote those words.
    before = deal_payload_signature(line)
    after = deal_payload_signature(out)
    if before != after and (before[0] - after[0] or before[1] - after[1] or before[2] - after[2]):
        return re.sub(r"\s{2,}", " ", (line or "").replace("*", " ")).strip()
    return out


# Loot channels open with a pure campaign banner ("🔥🔥 TOP DEAL OF THE DAY 🔥🔥",
# "⚡️ 11 PM FLASH SALE ⚡️") that is not about any product. Those lines are decoration
# and must not reach our channels - but the ONLY thing that makes them droppable is
# that the post also contains a real product line. A list post whose headline is the
# product must never lose it, so the vocabulary below is deliberately limited to
# generic hype words: one product/spec word in the line keeps the line.
BANNER_NOISE_WORDS = frozenset("""
top tops best hot mega super ultra dhamaka dhamal amazing awesome superb mind
blowing daily latest new today yesterday deal deals dealz offer offers loot loots
sale sales steal stealer alert alerts save savings price prices drop drops shocker
shocking free gift gifts bonus grab hurry limited time slot hours day nights night
of the a an for you your ours only off on in india indian
weekend special weekday flash live now just don miss
""".split())
TIME_OF_DAY_RE = re.compile(r"\d{1,2}(?::\d{2})?\s*(?:am|pm|a\.m\.|p\.m\.)", re.I)


def is_campaign_banner_line(line: str) -> bool:
    """True for a pure hype/banner line with no product, price or link in it.

    Brand/store names are deliberately NOT in the vocabulary: "Myntra Mega Sale" is
    a real store header (content), "TOP DEAL OF THE DAY" is hype (noise).
    """
    t = line or ""
    if not t.strip() or URL_RE.search(t):
        return False
    if re.search(r"[\u20b9$%]|\b(?:rs\.?|inr|mrp|discount|cod|off\s*[:=])", t, re.I):
        return False
    stripped = TIME_OF_DAY_RE.sub(" ", t)
    stripped = re.sub(r"\b(?:\d{1,2}(?:st|nd|rd|th)?|\d{1,2}\s*(?:am|pm))\b", " ", stripped, flags=re.I)
    words = [w for w in re.sub(r"[^\w\s]", " ", stripped, flags=re.U).split() if w]
    if not words:
        return True  # pure decoration (emoji / rules) - noise by any definition
    return all(w.lower() in BANNER_NOISE_WORDS for w in words)


# Another channel's BRANDING (name/signature/watermark) is not deal content and
# the user wants it gone, while everything the posting channel wrote ABOUT the
# deal (including its own hype header) must stay verbatim. Two safe signals:
#   * a promo verb / handle on the line ("Join ... for more loot", "@xyz",
#     "Edited by Admin", "Subscribe"), or
#   * an ALL-CAPS title line carrying a brand-suffix noun ("ZONE", "HUB",
#     "INDIA", "OFFICIAL", "TELEGRAM"...), which is how these signatures read.
# Both require that no word of the line describes a product/price/spec, so a
# real deal sentence can never be mistaken for branding. Generic hype words are
# deliberately NOT enough on their own: "🔥🔥 TOP DEAL OF THE DAY 🔥🔥" is fidelity.
BRANDING_LINE_RE = re.compile(
    r"(?i)\b(?:join|follow|subscribe|share|forward|turn\s+on)\b"
    r"|\b(?:telegram|whatsapp)\s*(?:channel|group)?\b|\b(?:channel|group)\s*(?:name|link)?\b"
    r"|@[A-Za-z][A-Za-z0-9_]{3,}|\b(?:edited|posted|powered|made|managed)\s+by\b"
    r"|\bfor\s+more\b|\bmore\s+(?:loots?|deals?|offers?|updates?|dhamaka)\b"
    r"|\b(?:stay|keep)\s+(?:tuned|updated|connected)\b")
# Only these count as "this line names a channel/brand" - plain hype words
# (deal/deals/offer/loot/sale/day) are deliberately absent, because a channel's
# own "🔥🔥 TOP DEAL OF THE DAY 🔥🔥" header is fidelity, not branding.
BRANDING_NOUNS = frozenset("""
zone hub india official world point adda team squad daily store shop mart bazaar
channel group telegram whatsapp admin edit edits powered managed updates update
""".split())
# Words that prove the line talks about a real product/price -> never branding.
# A line that OPENS with a signature marker names whoever made the post, which is
# the point of the line - the brand word itself is expected, so the vocabulary
# check does not apply to it.
SIGNATURE_PREFIX_RE = re.compile(
    r"(?i)^[^\w\n]*(?:powered|edited|posted|made|managed|written|curated|created|shared|sent)"
    r"\s+by\b")

BRANDING_DEAL_EVIDENCE_RE = re.compile(
    r"(?i)[\u20b9$]|\b(?:mrp|rs\.?|inr|cod|discount|size|color|colour|pack|pcs|pair)\b"
    r"|\d+\s*%|\b\d+\s*(?:off|days?|years?|months?|gb|tb|mah)\b")


BRANDING_WORDS = BRANDING_NOUNS | BANNER_NOISE_WORDS | frozenset(
    "more for with and our us on in the a an by at to of also join follow subscribe "
    "share forward turn notifications notification stay tuned connected edited "
    "posted powered made managed only now here this that new best".split())
HANDLE_RE = re.compile(r"@(?![A-Za-z]{1,3}\b)[A-Za-z][A-Za-z0-9_]{3,}")


def is_branding_line(line: str) -> bool:
    """True for another channel's name/signature/promo line, never for deal text."""
    t = (line or "").strip()
    if not t or URL_RE.search(t):
        return False
    if BRANDING_DEAL_EVIDENCE_RE.search(t):
        return False
    words = [w for w in re.sub(r"[^\w\s]", " ", t, flags=re.U).split() if w]
    if not words:
        return False
    lowered = [w.lower() for w in words]
    brand_nouns = [w for w in lowered if w in BRANDING_NOUNS]
    # One product/spec word anywhere means this is a deal line, not a signature.
    if not brand_nouns and not HANDLE_RE.search(t):
        return False
    if HANDLE_RE.search(t) or SIGNATURE_PREFIX_RE.match(t):
        return True                       # a bare "@handle" / "Powered by X" credit line
    if all(w in BRANDING_WORDS for w in lowered):
        return bool(BRANDING_LINE_RE.search(t)) or len(brand_nouns) >= 2
    return False                          # real content with a stray CTA


def strip_promo_lines(text: str) -> str:
    """Drop source promo/navigation lines from a Telegram/WhatsApp body, and
    strip a CTA fragment glued to the end of a real deal line (price/discount
    lines are kept as lines, only the channel junk on them is removed).

    Fidelity first: a channel's own campaign banner ("🔥🔥 TOP DEAL OF THE DAY 🔥🔥")
    is part of the source post and is KEPT by default. Only with
    STRIP_CAMPAIGN_BANNERS=true is it treated as decoration, and even then a
    banner that is the post's only text line stays, so cleaning can never leave a
    wall of bare links behind.
    """
    lines = (text or "").splitlines()
    banners = [is_campaign_banner_line(ln) for ln in lines] if STRIP_CAMPAIGN_BANNERS else []
    # A post is NOT allowed to become a wall of bare links: if every text line is
    # a banner (some channels put the product name nowhere else), the first one is
    # kept as the headline and only the extra banner lines go away.
    if banners:
        has_real_headline = any(ln.strip() and not URL_RE.search(ln) and not flag
                                for ln, flag in zip(lines, banners))
        first_banner = None if has_real_headline else next(
            (i for i, ln in enumerate(lines) if ln.strip() and banners[i]), None)
    else:
        first_banner = None
    branding = [is_branding_line(ln) for ln in lines]
    # Same guard as the banner rule: if the ONLY text lines of the post are
    # branding, the first one stays - a wall of bare links is never an
    # improvement, and the product/price line is what fidelity is about.
    if any(branding) and not any(ln.strip() and not URL_RE.search(ln) and not flag
                                for ln, flag in zip(lines, branding)):
        branding[next(i for i, flag in enumerate(branding) if flag)] = False
    kept = []
    for index, ln in enumerate(lines):
        if is_promo_noise_line(ln):
            continue
        # Branding of another channel always goes (fidelity is about the DEAL,
        # not about whoever wants a subscriber for it).
        if branding[index]:
            continue
        if banners and banners[index] and index != first_banner:
            continue
        kept.append(strip_inline_cta(ln))
    return "\n".join(kept)


BUTTON_CHROME_RE = re.compile(r"(?i)\b(?:buy\s+(?:now|here)|shop\s+now)\b|🛒|>>+")
# Broken Telegram/Markdown entity remnants occasionally appear as standalone
# lines such as `B]()` / `]()` / `Buy]()` after a hidden Buy Now URL is rebuilt.
ORPHAN_MARKDOWN_LINE_RE = re.compile(
    r"(?im)^\s*(?:(?:b|bu|buy|buy\s+now)\s*)?\]?\s*\(\s*\)\s*$"
)


ORPHAN_URL_FRAGMENTS = {
    "h", "hh", "ht", "hht", "htt", "httt", "hhtt", "http", "https", "https",
    "htps", "ttp", "ttps", "tps",
    "tps://", "tp://", "s://", "://", "uy",
}

# USER RULE (2026-09-03): "h", "ht", "hht" price pakkana kuda add avvakudadu.
# A stand-alone half-URL token ANYWHERE on a line ("Deal Price: ₹499 h",
# "₹1,299 hht", "₹350 👉h") is the residue of a stripped link, never content.
# The token must be a whole word on its own: "42H playtime", "H&M", "hot" and a
# real "https://..." link are untouched (the lookarounds refuse letters, digits,
# ':' '/' '.' '&' on either side).
_INLINE_ORPHAN_FRAGMENT_RE = re.compile(
    r"(?<![\w:/.&-])(?:h{1,2}t{1,3}p{0,2}s{0,2}|tt?ps?|h{1,2})(?![\w:/.&-])", re.I)


def strip_inline_orphan_fragments(text: str) -> str:
    """Remove bare half-URL tokens (h/ht/htt/hht/https…) glued near prices or
    dangling anywhere, while every real URL stays byte-identical."""
    if not text:
        return text
    real = list(dict.fromkeys(URL_RE.findall(text)))
    masked = text
    for index, url in enumerate(real):
        masked = masked.replace(url, f"\x01R{index}\x02")
    masked = _INLINE_ORPHAN_FRAGMENT_RE.sub(" ", masked)
    # Emptied wrappers/arrows the token was sitting in: "(h)" -> "()", "👉h" -> "👉".
    masked = re.sub(r"[(\[{]\s*[)\]}]", " ", masked)
    masked = re.sub(r"[ \t]{2,}", " ", masked)
    masked = re.sub(r"[ \t]+$", "", masked, flags=re.M)
    for index, url in enumerate(real):
        masked = masked.replace(f"\x01R{index}\x02", url)
    return masked


def remove_orphan_url_fragment_lines(text: str) -> str:
    kept = []
    for line in (text or "").splitlines():
        # Ignore emojis/arrows/zero-width/formatting around tiny broken pieces,
        # e.g. `👉h`, `htt`, or `tps://` left by malformed Telegram entities.
        core = re.sub(r"[^A-Za-z:/]", "", line).lower()
        if core in ORPHAN_URL_FRAGMENTS:
            # A line whose letters are ONLY the fragment but that still carries
            # a price/number ("₹799 ttp") must keep the price: strip the token,
            # never the line (dropping the price was worse than the residue).
            if re.search(r"[\d\u20b9]", line):
                kept.append(strip_inline_orphan_fragments(line))
            continue
        kept.append(line)
    return "\n".join(kept)


# Labels that are a call to action, not a product: dropping these keeps the
# post clean, while any other label is the product name and must survive.
_CTA_LABEL_RE = re.compile(
    r"(?i)\s*(?:buy(?:\s*it)?(?:\s*now)?|shop(?:\s*now)?|order(?:\s*now)?|grab(?:\s*it)?(?:\s*now)?"
    r"|click(?:\s*here)?|here|link|links|deal\s*link|buy\s*link|product\s*link"
    r"|get\s*it(?:\s*now)?|check(?:\s*it)?(?:\s*out)?|view|see\s*more|more"
    r"|amazon|flipkart|meesho|myntra|ajio|loot|offer|deal)\s*[\u2b07\U0001f447\U0001f449\u27a1\ufe0f\s:*-]*")


def normalize_nested_link_markup(text: str) -> str:
    """Normalise a FORWARDED/malformed source whose links are wrapped in nested
    markdown and double HTML-escaping, e.g.
      [[https://..&amp;amp;psc=1...](https://..&amp;psc=1...)](https://..&psc=1...)
    Leaves ONE clean URL per bracket group and decodes &amp;amp; -> & fully."""
    if not text:
        return text
    out = text
    # Fully decode double/triple HTML escapes (&amp;amp; -> &amp; -> &).
    for _ in range(4):
        decoded = html.unescape(out)
        if decoded == out:
            break
        out = decoded
    # Markdown link: [LABEL](URL). Collapse "[URL](URL)" (label is itself a URL)
    # and "[junk](URL)" down to the single URL, repeatedly (nested wrappers).
    for _ in range(4):
        prev = out
        out = re.sub(r"\[\s*(https?://[^\s\]\[]+?)\s*\]\s*\(\s*https?://[^\s)]+?\s*\)",
                     r"\1", out, flags=re.I)
        # "[LABEL](URL)": the label is thrown away only when it is DEBRIS -
        # a call to action ("Buy Now", "Click here", "Link"). When it is the
        # PRODUCT NAME the post loses its product entirely and the reader is
        # left with a bare URL, which is the "just names / no product" defect
        # in reverse. So a substantial label is kept above its link.
        def _unwrap_markdown_link(match: "re.Match[str]") -> str:
            label = (match.group(1) or "").strip()
            url = match.group(2)
            # Emphasis debris around a nested wrapper ("++**[[url](url)++**]")
            # is not a product name; strip it before judging the label, or the
            # SAME url is emitted twice - once as its own "name" and once as
            # the link, which is the duplicate the user forbids.
            # Only RUNS of markers are debris. A single trailing "+" is part of
            # the product ("boAt Rockerz 255 Pro+", "Redmi Note 13 Pro+").
            label = re.sub(r"^[*_+~\s]{2,}|[*_+~\s]{2,}$", "", label)
            label = re.sub(r"^[*_~]+|[*_~]+$", "", label).strip()
            words = re.findall(r"[A-Za-z][A-Za-z'&.-]+", label)
            # A label that merely CONTAINS a url (or a url fragment left by an
            # inner wrapper) is markup, never a product name.
            if (not label
                    or URL_RE.search(label)
                    or "amazon." in label.lower() or "flipkart." in label.lower()
                    or _CTA_LABEL_RE.fullmatch(label)
                    or len(label) < 6
                    or not words):
                return url
            # Anything the source wrote AFTER the link on that line (usually the
            # price: "[Name](url) @ 899") belongs with the NAME, not stranded
            # under the URL. The caller re-splits on newlines, so emit the
            # label, then a placeholder the tail is folded into below.
            return f"{label}\x00{url}"

        out = re.sub(r"\[([^\]\[]*?)\]\s*\(\s*(https?://[^\s)]+?)\s*\)",
                     _unwrap_markdown_link, out, flags=re.I)
        if out == prev:
            break
    # Fold each unwrapped "LABEL \x00 URL rest-of-line" back into two tidy
    # lines: "LABEL rest-of-line" then the URL underneath it. Repeat until the
    # line holds no placeholder: a line can carry SEVERAL markdown links
    # ("[A](u1) @99 [B](u2) @199"), and folding only the first one left the
    # rest of the placeholders visible as NUL characters in the post.
    for _ in range(8):
        if "\x00" not in out:
            break
        folded: list[str] = []
        for line in out.split("\n"):
            if "\x00" not in line:
                folded.append(line)
                continue
            head, _, remainder = line.partition("\x00")
            url_match = URL_RE.match(remainder)
            if not url_match:
                folded.append(line.replace("\x00", " "))
                continue
            url = url_match.group(0)
            tail = remainder[url_match.end():].strip()
            label = head.strip()
            folded.append(f"{label} {tail}".strip() if tail else label)
            folded.append(url)
        out = "\n".join(folded)
    # Belt and braces: a placeholder must never reach a reader.
    out = out.replace("\x00", " ")
    # Leftover stray square brackets are noise.
    out = re.sub(r"[\[\]]+", "", out)
    # Markdown emphasis debris (++, **, __ and lone */_) left around the
    # collapsed links is source formatting, never deal content. Strip it in
    # the TEXT parts only (URLs are masked) so legitimate '+' query chars
    # inside Amazon URLs survive untouched.
    def _drop_emphasis_part(part: str) -> str:
        # A real URL is only ever trimmed at its edges: "https://t.me/addlist/"
        # links and merchant paths legitimately contain underscores, and an
        # interior "_" used to be deleted (it silently corrupted our own folder
        # link into a dead join URL). Trailing emphasis glued to a URL is debris.
        if re.match(r"(?i)https?://", part):
            return re.sub(r"^[*_+~]+|[*_+~]+$", "", part)
        # Text parts: runs of 2+ markers (** __ ++ ~~) plus lone emphasis
        # markers are markdown debris. "*" never carries meaning in a plain-text
        # deal post (and Telegram does not render it), so every one of them
        # goes. "_" inside a word is kept: coupon codes ("SAVE_200") and SKUs
        # are real content.
        part = re.sub(r"[*_+~]{2,}", "", part)
        part = part.replace("*", "")
        part = re.sub(r"(?<![\w])_(?=\w)", "", part)
        return re.sub(r"(?<=\w)_(?![\w])", "", part)
    out = "\n".join(
        re.sub(r"[ \t]{2,}", " ", " ".join(
            _drop_emphasis_part(p) for p in URL_KEEP_RE.split(line)
        )).strip()
        for line in out.splitlines()
    )
    # Collapse the SAME product link stacked several times in one line (nested
    # copies) down to one, keeping a short text prefix if there is one.
    # A URL wrapped in parentheses is cleaner as the bare link (the emphasis
    # pass above splits on the brackets, leaving "( url )" spacing behind).
    # The spaces are REQUIRED: a broken forward can glue "url1(url2(url3" together
    # and those inner parens are the only thing separating the duplicates - the
    # per-line dedup below needs them, so they must not be touched here.
    out = re.sub(r"\(\s+(https?://[^\s()]+)\s+\)", r"\1", out, flags=re.I)
    lines = []
    for line in out.splitlines():
        # Parentheses are real deal text - "Price ₹260 (75% OFF)" must survive
        # untouched. Only a line that is itself a URL wrapped in parens (an
        # artefact of forwarded/bot-posted entities) gets its wrapper removed.
        bare = line.strip()
        if URL_RE.search(bare):
            # Only the outer wrapper comes off a URL line: the inner parentheses
            # of a glued forward fragment ("url1(url2(url3))") are the separators
            # the dedup below counts on, so they must survive untouched.
            bare = bare.strip("()").strip()
        else:
            bare = fix_unbalanced_parens(bare)
        stripped = bare
        urls = URL_RE.findall(stripped)
        if len(urls) > 1:
            canon, seen = [], set()
            for u in urls:
                key = extract_product_id(u) or canonical_url(u)
                if key not in seen:
                    seen.add(key)
                    canon.append(clean_url(u).rstrip("()"))
            if canon:
                prefix = re.sub(r"https?://\S+", "", stripped)
                prefix = re.sub(r"[()]{2,}", " ", prefix).strip(" \t|()")
                prefix = fix_unbalanced_parens(prefix)
                stripped = (((prefix + "\n") if prefix else "") + "\n".join(canon)).strip()
        lines.append(stripped)
    return "\n".join(lines)


# Half-stripped promo links and broken entity fragments are the main source of
# "unwanted words" in a post: removing a `t.me/...` CTA used to leave
# `.com/channel/0029`, `.me/someotherchannel` or `ps://broken` behind. These
# patterns only ever match URL *residue* (real links are masked out first), so a
# generated affiliate URL can never be damaged by this pass.
URL_RESIDUE_RES = (
    r"(?i)\b(?:https?|httpsx|ht|htt|httpx|ftp|tps|ttp|tp|ps|hs|sp)[:/ ]{0,2}[/\\]{2,}\S*",
    r"(?i)[A-Za-z0-9_-]*\.(?:me|com|in|net|org|io|co|html?)\b[/\\]\S*",
    r"(?i)\b(?:t|telegram|whatsapp|wa)\s*[:.]\s*(?:me|com|dog)\b\S*",
)


def strip_url_residue(text: str) -> str:
    """Drop broken/half-stripped URL fragments while leaving real links intact."""
    if not text:
        return text
    real = list(dict.fromkeys(clean_url(u) for u in URL_RE.findall(text)))
    masked = text
    for index, url in enumerate(real):
        masked = masked.replace(url, f"\x01R{index}\x02")
    for pattern in URL_RESIDUE_RES:
        masked = re.sub(pattern, " ", masked)
    masked = re.sub(r"[ \t]{2,}", " ", masked)
    # A line that lost everything except bullets/emoji/arrows is a dead slot.
    lines = [
        line for line in masked.splitlines()
        if re.search(r"[A-Za-z0-9\u0900-\u097F\u0C00-\u0C7F]", line)
        or URL_RE.search(line)
        or not re.fullmatch(r"[\s🔗👉➡️🔎🔍•▪️\-–—_|:*+]+", line or "")
    ]
    masked = "\n".join(lines)
    for index, url in enumerate(real):
        masked = masked.replace(f"\x01R{index}\x02", url)
    return re.sub(r"\n{3,}", "\n\n", masked).strip()


# ---------------------------------------------------------------------------
# Junk-token killers. Sources are forwarded bot output: masked shortener tails
# (".../tG7oChgiQuTgS25b") get glued to the price or left on a line of their
# own, and broken Telegram entities leave "[url](url)" markdown debris. The
# previous rules were length-capped at 12-14 characters, so a 17-character
# fragment sailed straight into the published post. These three helpers are the
# single source of truth: clean_source_text, tidy_post and the final outbound
# guard all share them, so a token cannot survive by dodging one of the passes.

# An Amazon/Flipkart coupon code: all caps, letters plus optional digits, 3-20 chars.
_COUPON_CODE_RE = re.compile(r"[A-Z][A-Z0-9_-]{2,19}")   # SAVE_200 is as spendable as SAVE200
# The gap is [ \t]* and never \s*: a token on the NEXT line is not glued to this
# price, and rewriting the pair must not swallow the newline that keeps the source's
# layout (an earlier draft joined "MRP: ₹ 270" and "Discount: 26%" into one line).
# "@2764" and "Rs.449" are prices exactly like "\u20b9449" - the live channels
# write all three - so link debris glued to ANY of them is cut the same way
# ("LG 24 Inches @2764ldkf" was published with the "ldkf" scrap attached).
_PRICE_WITH_TAIL = re.compile(r"((?:\u20b9\s*|@\s*|\bRs\.?\s*)[\d,]+)([ \t]*)(\S+)", re.I)


def _keep_code_as_is(price: str, gap: str, tail: str) -> str:
    """Rebuild one "<price><token>" pair, judging the token by its SHAPE.

    The three shapes a source post actually contains, in order of how much they
    matter: an all-caps code (PEOPLE200, HFJF) is money the reader can spend, so it
    is UN-GLUED with a space and kept - deleting it was losing the best part of the
    deal; a real unit ("500ml", "2pcs") spaced after the price is legitimate text and
    stays; a mixed-case run ("tG7oChgiQuTgS25b") is what a broken shortener leaves
    behind and must go, because "\u20b9260://bitli.in/x" is a dead link, not a discount.
    A glued token with a letter in it is never real text - the price ended and the
    paste ran on - so it is cut, exactly as before this code existed.
    """
    if not tail or tail[0] in "\u279c\u27a1\u2192\u2022\u00b7#":
        return f"{price}{gap}{tail}"
    core = tail.rstrip(").,;:!?\u2026")
    trail = tail[len(core):]
    if not core:
        return f"{price}{gap}{tail}"
    # "@2pm" / "@11am" is a TIME the source wrote (sale start), not a price with
    # junk on it - the glued cut below must never turn "Sale @2pm" into "Sale @2".
    if price.lstrip().startswith("@") and core.lower() in ("am", "pm", "a.m", "p.m", "a.m.", "p.m."):
        return f"{price}{gap}{tail}"
    if not gap:
        # USER RULE (round 13): a token glued straight onto a price is UNWANTED text,
        # whatever it looks like - the live channel's price line arrives as
        # "₹85h" / "₹ 199HFJF" / "₹85jsjd" and the reader needs the PRICE, not the
        # scrap. It is cut, and nothing of ours is written in its place. A code the
        # source really wants the reader to use is written separately ("Use code
        # PEOPLE200", "₹1,099 SAVE200"), and that spacing is what keeps it: this walk
        # only ever touches what is fused to the digits.
        if re.fullmatch(r"[A-Za-z0-9_-]{1,64}", core) and re.search(r"[A-Za-z]", core):
            return f"{price}{trail}".rstrip()
        return f"{price}{gap}{tail}"
    if core.lower() in _PRICE_UNITS or not re.search(r"\d", core):
        return f"{price} {core}{trail}"                  # words and units stay put
    if _COUPON_CODE_RE.fullmatch(core) and re.search(r"\d", core):
        return f"{price} {core}{trail}"                    # spaced code: keep verbatim
    # A SPACED token is deleted only when it is machine-shaped - mixed case, long, and
    # holding a digit, which is what a torn shortener looks like when the paste broke
    # ("₹260 tG7oChgiQuTgS25b"). No human writes a coupon or a quantity that way, so
    # nothing of the source's own words is ever lost here.
    if (len(core) >= 8 and re.fullmatch(r"[A-Za-z0-9_-]{8,64}", core)
            and re.search(r"[a-z]", core) and re.search(r"[A-Z]", core)
            and re.search(r"\d", core)):
        return f"{price}{trail}".rstrip()
    return f"{price}{gap}{tail}"


_PRICE_UNITS = frozenset(
    "pcs pack packs pair pairs kg gm g ml ltr ltrs l litre litres cm mm mah gb tb "
    "w v inch inches ft in".split())


def strip_price_junk(text: str) -> str:
    """Un-glue a coupon code from a \u20b9 price and cut real link debris off it.

    Two different things look the same in a source post: "\u20b91,099PEOPLE200" is a
    price plus the code that saves the reader \u20b9200, while "\u20b9260tG7oChgiQuTgS25b"
    is a half-torn shortener URL. The first must survive (deleting it was losing the
    deal's best part), the second must go. The shape tells them apart, so this walks
    every "<price><glued token>" pair once and decides per token - never per regex,
    which is how the old three-pass version ate codes along with the debris.

    Real links are masked first so a glued link keeps its protocol: cutting "https"
    out of "\u20b9260https://bitli.in/x" used to leave "\u20b9260://bitli.in/x".
    """
    if not text:
        return text
    urls = list(dict.fromkeys(URL_RE.findall(text)))
    for index, url in enumerate(urls):
        text = text.replace(url, f"\x02P{index}\x03")
    text = _PRICE_WITH_TAIL.sub(lambda m: _keep_code_as_is(m.group(1), m.group(2), m.group(3)), text)
    for index, url in enumerate(urls):
        text = text.replace(f"\x02P{index}\x03", url)
    # Keep a glued link apart from the word/price in front of it.
    out = re.sub(r'([\w\u20b9)\]>"\'])(?=https?://)', r"\1 ", text)
    return re.sub(r"[ \t]{2,}", " ", out)


def strip_link_fragment_tokens(text: str) -> str:
    """Drop masked-shortener fragments that stand alone inside a line.

    A 12+ character run that mixes lower case, upper case and digits is link
    residue (a coupon is never random-case like that, and coupon/referral lines
    are skipped entirely), so this kills the "edo edo random" words no source
    actually wrote.
    """
    if not text:
        return text
    urls = list(dict.fromkeys(URL_RE.findall(text)))
    masked = text
    for index, url in enumerate(urls):
        masked = masked.replace(url, f"\x01K{index}\x02")
    lines = []
    for line in masked.splitlines():
        if not re.search(r"(?i)code|coupon|kupon|voucher|referral|refer\b|promo|pin\b|deal\s*id", line):
            line = re.sub(
                r"(?<![A-Za-z0-9_-])"
                r"(?=[A-Za-z0-9_-]{12,64}(?![A-Za-z0-9_-]))"
                r"(?=[A-Za-z0-9_-]*[a-z])(?=[A-Za-z0-9_-]*[A-Z])(?=[A-Za-z0-9_-]*\d)"
                r"[A-Za-z0-9_-]{12,64}(?![A-Za-z0-9_-])",
                "", line)
            line = re.sub(r"[ \t]{2,}", " ", line).strip()
            # Only an orphan bullet left behind by the sweep (":" is preserved so
            # "Use code:" labels survive, and no bracket can be eaten). A trailing
            # variation selector is emoji, not residue: "\u26a1\ufe0f\u26a1\ufe0f 11 PM FLASH SALE
            # \u26a1\ufe0f\u26a1\ufe0f" must come out exactly as the source wrote it, so only an
            # ORPHAN \ufe0f (nothing in front of it but space/start) is dropped.
            # (?<!/) keeps the "-" of the Indian "/-" price suffix: this sweep
            # posted "Price: ₹18,999/-" as "₹18,999/" (USER REPORT 2026-10-18).
            line = re.sub(r"(?<!/)[\s\u279c\u27a1\u2192\U0001f517\U0001f449\u2022\u2013\u2014-]+$", "", line).strip()
            line = re.sub(r"(?<=\s)\ufe0f+(?=\s*$)", "", line)
            line = re.sub(r"^\ufe0f+", "", line)
        lines.append(line)
    for index, url in enumerate(urls):
        lines = [line.replace(f"\x01K{index}\x02", url) for line in lines]
    return "\n".join(lines)


def fix_unbalanced_parens(line: str) -> str:
    """Drop empty/unmatched parentheses, never a real "(75% OFF)" pair."""
    if not line:
        return line
    # Stripping a promo URL out of "Price ₹21,999 (from our channel ...)" can
    # leave an empty bracket pair: that is cleanup residue, not deal content.
    stripped = re.sub(r"\(\s*\)", " ", line)
    stripped = re.sub(r"[ \t]{2,}", " ", stripped).strip(" \t|")
    if stripped != line:
        line = stripped
    if line.count("(") == line.count(")"):
        return line
    # v17.8: only a bracket that STANDS ALONE is cleanup residue. The old loop
    # deleted characters until the counts matched, which ate the ")" of a
    # numbered list ("1) boAt Airdopes …") and the closing bracket of
    # "(78% off)" - real source text destroyed on every list post. When the
    # leftovers are not standalone the line is published as the source wrote it.
    opens, closes = line.count("("), line.count(")")
    char = "(" if opens > closes else ")"
    excess = abs(opens - closes)
    out: list[str] = []
    removed = 0
    for index, char_here in enumerate(line):
        if char_here == char and removed < excess:
            alone_before = index == 0 or line[index - 1].isspace()
            alone_after = index == len(line) - 1 or line[index + 1].isspace()
            if alone_before and alone_after:
                removed += 1
                continue
        out.append(char_here)
    return re.sub(r"[ \t]{2,}", " ", "".join(out)).strip()


def _collapse_markdown_link(match: re.Match) -> str:
    """`[label](url)` printed as plain text is debris; keep what is content.

    Posts go out with no parse_mode, so brackets are shown literally. When the
    label is itself the URL (or just punctuation/empty) the whole group is one
    duplicated link and the bare URL is all that must remain. A label carrying
    real words is deal content, so it is kept and the link follows it.
    """
    label = (match.group(1) or "").strip()
    url = (match.group(2) or "").strip()
    if not label or URL_RE.fullmatch(label) or not re.search(r"[A-Za-z0-9]", label):
        return url
    return f"{label} {url}"


def sanitize_outbound_text(text: str) -> str:
    """Final gate for the exact string handed to Telegram.

    Everything above cleans the SOURCE text; the affiliate substitution and the
    shortener pass run afterwards and can still leave "[url](url)" markup, a
    glued token or an empty bullet line. This guard is idempotent, touches only
    formatting, and never rewrites a verified link or a price the source had.
    """
    if not text:
        return text
    out = text
    for _ in range(4):
        previous = out
        out = re.sub(r"\[\s*([^\]\[]*?)\s*\]\s*\(\s*(https?://[^\s)]+?)\s*\)",
                     _collapse_markdown_link, out, flags=re.I)
        if out == previous:
            break
    out = strip_price_junk(out)
    out = strip_link_fragment_tokens(out)
    # USER RULE: "h"/"ht"/"hht" pieces next to a price must never leave the bot.
    out = strip_inline_orphan_fragments(out)
    out = re.sub(r"\(\s*\)", " ", out)
    # Any bracket left after the collapse is a fragment of broken entity markup.
    out = re.sub(r"[\[\]]", "", out)
    out = "\n".join(
        # A line carrying a link is left exactly as it is: "( )" may be part of a
        # real merchant path and the parentheses of a URL must never be edited.
        line if URL_RE.search(line) else fix_unbalanced_parens(line)
        for line in out.splitlines()
    )
    out = re.sub(r"[ \t]+\n", "\n", out)
    out = re.sub(r"\n{3,}", "\n\n", out)
    return out.strip()


# USER RULE (2026-09-06): the Flipkart app's own share sheet titles a product
#   "Buy <long name> Online at Low Prices In India | Flipkart.com"
# and forwards paste that title line into source posts verbatim. Those words are
# the app's wrapper, not the deal: the post's headline must be the product's
# real name, and the Flipkart link (already on its own line, or right after the
# title) is kept untouched. Matched as a WHOLE line only - a line that merely
# mentions Flipkart is never touched - and case-insensitive, because sources
# paste both "...Low Prices In India | Flipkart.com" and "...in india...".
FLIPKART_SHARE_TITLE_RE = re.compile(
    r"(?i)^\s*(?:[*_~]+\s*)?buy\s+(?P<name>.+?)\s+online\s+at\s+low\s+prices?\s+"
    r"in\s+india\s*\|\s*flipkart\.com\s*(?:[*_~]+\s*)?$"
)
# The same wrapper glued to the link on ONE line ("... | Flipkart.com
# https://dl.flipkart.com/..."). split_inline_product_links only splits a line
# with TWO or more links, so this single-link shape must be handled here.
FLIPKART_SHARE_TITLE_GLUED_RE = re.compile(
    r"(?i)^\s*(?:[*_~]+\s*)?buy\s+(?P<name>.+?)\s+online\s+at\s+low\s+prices?\s+"
    r"in\s+india\s*\|\s*flipkart\.com\s*(?:[*_~]+\s*)?(?P<url>https?://\S+)\s*$"
)


def strip_flipkart_share_title(text: str) -> str:
    """Rewrite every Flipkart share-sheet title line to the bare product name.

    "Buy boAt Airdopes 141 ... Online at Low Prices In India | Flipkart.com"
    becomes "boAt Airdopes 141 ...". The link is never edited: it lives on its
    own line, or (glued shape) is moved to one whole, so the product name and
    its link both survive. A title line whose name is empty after cleaning is
    dropped entirely - it carried no product.
    """
    if not text or "lipkart" not in text.lower():
        return text
    out: list[str] = []
    for line in text.splitlines():
        m = FLIPKART_SHARE_TITLE_RE.match(line)
        if m:
            name = tidy_post((m.group("name") or "").strip().strip("*_~").strip())
            if name:
                out.append(name)
            continue
        glued = FLIPKART_SHARE_TITLE_GLUED_RE.match(line)
        if glued:
            name = tidy_post((glued.group("name") or "").strip().strip("*_~").strip())
            if name:
                out.append(name)
                out.append(glued.group("url"))
                continue
        out.append(line)
    return "\n".join(out)


def clean_source_text(text: str) -> str:
    text = (text or "").replace("\x00", "")
    # A source that wrote a whole list on ONE line ("name link name link") is
    # split FIRST. Every later pass hoists URLs onto their own lines, which
    # would leave the names bunched in one paragraph above a block of anonymous
    # links - the reader could not tell which link belongs to which product.
    text = split_inline_product_links(text)
    # The Flipkart app's share title ("Buy X Online at Low Prices In India |
    # Flipkart.com") is wrapper words around the product's real name. It is
    # rewritten before the noise passes so the name survives as the headline
    # and no "| Flipkart.com" tail can be mistaken for deal content.
    text = strip_flipkart_share_title(text)
    text = normalize_nested_link_markup(text)
    text = re.sub(r"[\u200b-\u200f\u2060\ufeff]", "", text)
    text = CK_FOOTER_RE.sub("\n", text)
    text = SOURCE_NOISE_LINE_RE.sub("", text)
    text = remove_orphan_url_fragment_lines(text)
    # USER RULE: "h"/"ht"/"hht" residue next to a price is unwanted text.
    text = strip_inline_orphan_fragments(text)
    # Remove URL-tail garbage glued to a price ("₹122oya", "₹260tG7oChgiQuTgS25b")
    # and any stand-alone shortener fragment. Shared with tidy_post and the
    # outbound guard so the same junk can never be missed by one pass only.
    text = strip_price_junk(text)
    text = strip_link_fragment_tokens(text)
    text = ORPHAN_MARKDOWN_LINE_RE.sub("", text)
    text = re.sub(r"(?im)^\s*[^\w\n]*(?:sent\s+via|via\s+\w+\s+admin).*$", "", text)
    text = re.sub(r"(?im)^\s*(?:follow|join|subscribe).*@\w+.*$", "", text)
    # Drop source promo/navigation lines (join/follow/share/notify, t.me
    # self-promo, deal-time, handles, emoji-only) that carry no deal content.
    text = strip_promo_lines(text)
    # Then remove anything the CTA stripping left dangling (`.com/channel/0029`,
    # `ps://`, a bare `https://`) so no URL residue ever reaches a post.
    text = strip_url_residue(text)
    return text.strip()


def rebuild_text(text: str, entities, mapping: dict[str, str]) -> str:
    """Replace URLs using Telegram's UTF-16 entity offsets safely."""
    text = text or ""
    surrogate_text = add_surrogate(text)
    spans: list[tuple[int, int, str, str]] = []
    for entity in entities or []:
        if isinstance(entity, MessageEntityTextUrl) and entity.url:
            spans.append((entity.offset, entity.offset + entity.length, entity.url, "texturl"))
        elif isinstance(entity, MessageEntityUrl):
            source = clean_url(del_surrogate(
                surrogate_text[entity.offset:entity.offset + entity.length]
            ))
            spans.append((entity.offset, entity.offset + entity.length, source, "url"))
    spans.sort()
    # Remove overlapping formatting/entity spans safely.
    filtered: list[tuple[int, int, str, str]] = []
    for span in spans:
        if not filtered or span[0] >= filtered[-1][1]:
            filtered.append(span)

    def replace_literal(segment: str) -> str:
        def repl(match) -> str:
            raw = match.group(0)
            return mapping.get(clean_url(raw), "")
        return URL_RE.sub(repl, segment)

    out, pos = [], 0
    for start, end, source_url, kind in filtered:
        out.append(replace_literal(surrogate_text[pos:start]))
        aff = mapping.get(clean_url(source_url), "")
        label = del_surrogate(surrogate_text[start:end])
        if aff:
            out.append(aff if kind == "url" or BUTTON_CHROME_RE.search(label) else f"{label}: {aff}")
        elif kind == "texturl" and not BUTTON_CHROME_RE.search(label):
            out.append(label)
        pos = end
    out.append(replace_literal(surrogate_text[pos:]))
    result = del_surrogate("".join(out))
    # SELF-HEALING GUARD (user bug, 2026-09-03): when entity offsets do not line
    # up with this text (a parse-mode copy inserted "**" marks and shifted every
    # offset), the slice cuts THROUGH a URL and publishes scrap like "BUJYEi"
    # while the affiliate link is lost. If any monetized link went missing even
    # though its source URL is literally present in the text, the entity path
    # cannot be trusted - rebuild by literal replacement, which needs no offsets.
    for source_url, aff in mapping.items():
        if aff and aff not in result and source_url in clean_url(text):
            literal = replace_literal(surrogate_text)
            return del_surrogate(literal)
    return result


def tidy_post(text: str) -> str:
    """Remove source chrome without ever mutating a generated affiliate URL."""
    text = ORPHAN_MARKDOWN_LINE_RE.sub("", text or "")
    protected: list[str] = []

    def mask(match) -> str:
        protected.append(clean_url(match.group(0)))
        return f"\x01URL{len(protected)-1}\x02"

    # Protect links first: underscores, parentheses and tracking query values are valid URL data.
    masked = URL_RE.sub(mask, text)
    masked = BUTTON_CHROME_RE.sub(" ", masked)
    # Remove malformed source-link text glued into labels/prices while genuine
    # generated URLs are safely masked above.
    masked = re.sub(r"(?i)\bhtt[A-Za-z0-9/:._-]*", "", masked)
    # A protocol-less link stump ("://bitli.in/x" glued to a price after its
    # scheme was torn off) is dead residue - the working link was already
    # masked above, so anything still shaped like this cannot be real.
    masked = re.sub(r":?//[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)+(?:/[A-Za-z0-9._~%/-]*)?", " ", masked)
    masked = re.sub(r"\bh(?=[A-Z][a-z])", "", masked)
    masked = strip_price_junk(masked)
    # Markdown emphasis debris only. A '_' BETWEEN word characters is content -
    # a coupon code ("Use code SAVE_200") or an SKU - and the blanket removal
    # used to silently rewrite it into a code that does not work.
    masked = masked.replace("*", "")
    masked = re.sub(r"__([^_\n]+?)__", r"\1", masked)
    masked = re.sub(r"(?<![\w])_+(?=\w)|(?<=\w)_+(?![\w])", "", masked)
    # Square brackets are markdown debris in a plain-text channel; parentheses
    # around "(75% OFF)", "(Pack of 2)" or "(Code: X)" are the source's own
    # deal text and must be printed exactly as written. Only an unmatched paren
    # left behind by another cleanup pass is removed.
    masked = re.sub(r"[\[\]]", " ", masked)
    masked = re.sub(r"[ \t]+", " ", masked)
    masked = re.sub(r"(?m)^\s*[:>-]+\s*$", "", masked)
    for index, url in enumerate(protected):
        masked = masked.replace(f"\x01URL{index}\x02", url)
    # Final anti-residue sweep on our own output too: any fragment that is not a
    # complete link is dropped, every generated URL is masked inside the helper.
    masked = strip_url_residue(masked)
    # A link glued to the word/price in front of it ("₹260https://…") prints as
    # one unreadable token, and the fragment then looks like junk next to the
    # price. Keep the words apart. Query-nested links stay intact because the
    # separator has to be a word char, never "=", "&", "?" or "/".
    masked = re.sub(r'([\w\u20b9)\]>"\'])(?=https?://)', r"\1 ", masked)

    # Remove orphan link bullets with no actual URL after them, e.g. a leftover
    # `🔗` or `🔗 ` line whose source URL was collapsed/deduped away. A bullet
    # alone is not a link and should never appear in the final post.
    masked = re.sub(r"(?m)^\s*(?:🔗|👉|➡️|🔎|🔍|•|▪️|-|–|—|\*)?\s*(?:https?://\s*)?\s*$", "", masked)

    # Dedupe all URLs globally while preserving the first occurrence and line layout.
    seen: set[str] = set()
    lines: list[str] = []
    for original_line in masked.splitlines():
        line = original_line.strip()
        if not line:
            if lines and lines[-1] != "":
                lines.append("")
            continue
        for raw in URL_RE.findall(line):
            url = clean_url(raw)
            if url in seen:
                line = line.replace(raw, "", 1)
            else:
                seen.add(url)
                line = line.replace(raw, url, 1)
        line = re.sub(r"\s{2,}", " ", line)
        line = re.sub(r"\s+(?:\+|\||->|--+)\s*$", "", line).strip(" :")
        if line:
            lines.append(line)

    while lines and lines[-1] == "":
        lines.pop()
    result: list[str] = []
    for line in lines:
        if line == "" and (not result or result[-1] == ""):
            continue
        result.append(line)
    return "\n".join(result).strip()


def remove_source_url_residue(text: str, source_urls: Iterable[str],
                              protected_urls: Iterable[str]) -> str:
    """Remove malformed source-shortlink tails while protecting generated links."""
    protected = list(dict.fromkeys(clean_url(url) for url in protected_urls))
    masked = text or ""
    for index, url in enumerate(protected):
        masked = masked.replace(url, f"\x01AFF{index}\x02")

    identifiers: set[str] = set()
    for source in source_urls:
        try:
            parsed = urlparse(clean_url(source))
            material = parsed.path + "&" + parsed.query
            for token in re.findall(r"[A-Za-z0-9_-]{4,}", material):
                if token.lower() not in {"product", "search", "visitretailer", "source", "default"}:
                    identifiers.add(token.lower())
        except Exception:
            pass

    output = []
    for line in masked.splitlines():
        words = line.split()
        rebuilt = []
        for word in words:
            lower = word.lower()
            malformed_domain = re.search(
                r"(?:bitl+i|myntr|fkrt|fktr|aji+o)\.in/", lower
            )
            contains_id = any(identifier in lower for identifier in identifiers)
            if malformed_domain or contains_id:
                price = re.search(r"₹\s*[\d,]+", word)
                if price:
                    rebuilt.append(price.group(0))
                continue
            rebuilt.append(word)
        cleaned_line = " ".join(rebuilt).strip()
        if re.fullmatch(r"(?i)(?:use\s*code|link|p\.c)\s*:?\s*", cleaned_line):
            continue
        output.append(cleaned_line)
    masked = "\n".join(output)
    for index, url in enumerate(protected):
        masked = masked.replace(f"\x01AFF{index}\x02", url)
    return masked


MEANINGFUL_SINGLE_LABELS = {
    "men", "mens", "women", "womens", "unisex", "blue", "black", "white",
    "red", "green", "yellow", "brown", "orange", "pink", "purple", "grey",
    "gray", "beige", "gold", "silver", "small", "medium", "large",
}


def remove_trailing_url_tokens(text: str) -> str:
    """Drop random short IDs glued after an otherwise complete generated URL."""
    output = []
    for line in (text or "").splitlines():
        # Source entity corruption commonly leaves an ASIN/short-code tail after
        # the replaced URL, e.g. `https://...tag=ours 0GLY3Q2X`.
        line = re.sub(
            r"(https?://[^\s]+)(?:\s+[A-Za-z0-9_-]{2,16})+\s*$",
            r"\1",
            line,
        )
        output.append(line)
    return "\n".join(output)


# A label line that carried a link which later collapsed (two source links
# converting to the SAME product) or was stripped as promo is a dangling slot:
# `Link ` / `Buy Now` with nothing after it. Those are the most visible form of
# "unwanted words" in a finished post, so they are removed explicitly.
DANGLING_CTA_WORDS = {
    "", "link", "links", "buy", "shop", "click", "tap", "order", "grab", "here",
    "buylink", "buyhere", "clickhere", "shopnow", "buynow", "getit", "checkout",
    "orderhere", "view", "viewdeal", "deal", "offer", "purchase", "product", "url",
    "affiliate", "affiliatepartner", "ad", "ads", "promo", "sponsored",
}
_SHORT_LIST_NON_PRODUCT_WORDS = frozenset("""
    a an the and or of to in on at by with from for deal deals offer offers sale sales
    loot loots price mrp discount off coupon coupons code buy shop order grab click tap
    now here below join follow subscribe share forward hurry today daily new top hot free
    max quantity qty more link links
""".split())


def remove_dangling_cta_lines(text: str) -> str:
    """Drop pure CTA/link-label lines that ended up with no link and no price."""
    kept = []
    for line in (text or "").splitlines():
        if URL_RE.search(line) or re.search(r"[\u20b9$]|%\s*(?:off|discount)|\d", line, re.I):
            kept.append(line)
            continue
        core = (line or "").strip()
        if core and len(core) <= 28:
            probe = re.sub(r"[^A-Za-z]", "", core).lower()
            if probe in DANGLING_CTA_WORDS:
                continue
        kept.append(line)
    return "\n".join(kept)


def strict_orphan_token_cleanup(text: str, *, list_context: bool = False) -> str:
    """Remove random short tokens without deleting short product names in lists.

    One-word labels such as "Dove" or "Mivi" were mistaken for URL debris when
    they were separated from their price/link by other list items. Preserve a
    plausible short label when the post contains multiple links or its neighbour
    carries a price/discount; known CTA, promo and URL-fragment tokens still go.
    """
    text = remove_trailing_url_tokens(text)
    # A source post can carry a dangling protocol fragment right next to a real
    # link on the same line, e.g. `https://ajio.in/XXX https://`. Mask the real
    # URLs, drop the orphan protocol/domain fragment, then restore the links so
    # a genuine generated URL is never mutated.
    real_urls = list(dict.fromkeys(clean_url(u) for u in URL_RE.findall(text or "")))
    list_context = list_context or len(real_urls) >= 2
    masked = text
    for i, url in enumerate(real_urls):
        masked = masked.replace(url, f"\x01U{i}\x02")
    masked = re.sub(r"\bhttps?://[^\s\x01]*", "", masked)
    masked = re.sub(r"\s*\b(?:https?|htt|ftp)\b", "", masked)
    for i, url in enumerate(real_urls):
        masked = masked.replace(f"\x01U{i}\x02", url)

    masked = remove_dangling_cta_lines(masked)
    lines = (masked or "").splitlines()
    kept = []
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            kept.append("")
            continue
        # A line that is only a link-bullet emoji / bullet punctuation with no
        # URL, letters or digits is a dangling link slot and must be removed.
        if not URL_RE.search(stripped) and not re.search(r"[A-Za-z0-9]", stripped):
            if re.fullmatch(r"[\s🔗👉➡️🔎🔍•▪️\-–—_|:*]+", stripped):
                continue
        token_match = re.fullmatch(r"[A-Za-z0-9_-]{1,12}", stripped)
        if token_match:
            lower = stripped.lower()
            # Broken URL fragments (h / htt / uy / ...) are never real labels.
            # Drop them even when adjacent to a URL — the adjacency exception
            # exists for genuine labels (sizes/colors) near links, and keeping
            # junk fragments there leaked raw 'h'/'htt' lines into final posts.
            if lower in ORPHAN_URL_FRAGMENTS:
                continue
            previous = lines[index - 1].strip() if index else ""
            next_line = lines[index + 1].strip() if index + 1 < len(lines) else ""
            adjacent_url = bool(URL_RE.fullmatch(previous) or URL_RE.fullmatch(next_line))
            coupon_context = bool(re.search(r"(?i)use\s*code\s*: ?$", previous))
            adjacent_deal = any(
                candidate and (
                    PRICE_LABEL_RE.search(candidate)
                    or re.search(r"(?i)\b\d{1,3}\s*%\s*(?:off|discount)?\b", candidate)
                )
                for candidate in (previous, next_line)
            )
            short_product_label = bool(
                (list_context or adjacent_deal)
                and re.fullmatch(r"[A-Za-z][A-Za-z0-9+&._'’-]{1,29}", stripped)
                and lower not in _SHORT_LIST_NON_PRODUCT_WORDS
                and lower not in DANGLING_CTA_WORDS
                and not is_promo_noise_line(stripped)
            )
            if (lower not in MEANINGFUL_SINGLE_LABELS and not adjacent_url
                    and not coupon_context and not short_product_label):
                continue
        # Remove malformed protocol-like words wherever they appear outside a
        # real URL (real URLs are normally on their own and fail this pattern).
        if not URL_RE.fullmatch(stripped):
            stripped = re.sub(r"(?i)\b(?:htt|ttp|tps|s)[:/][A-Za-z0-9/:._-]*", "", stripped)
            # Tidy the edges the fragment removal left, but NEVER eat the "-" of
            # the Indian "/-" price suffix (USER REPORT 2026-10-18): a plain
            # strip(" :|+-") posted "Price: ₹18,999/-" as "₹18,999/". The
            # lookbehind keeps a "-" that follows "/", drops every other
            # dangling dash/pipe/colon.
            stripped = re.sub(r"\s{2,}", " ", stripped)
            stripped = re.sub(r"\A[\s:|+-]+", "", stripped)
            stripped = re.sub(r"(?<!/)[\s:|+-]+\Z", "", stripped)
            if not stripped:
                continue
            # Removing a broken fragment can leave a bare CTA label behind
            # ("Link", "Buy Now"); without a link or price it is junk.
            if (len(stripped) <= 28 and not re.search(r"[\u20b9$%\d]", stripped)
                    and re.sub(r"[^A-Za-z]", "", stripped).lower() in DANGLING_CTA_WORDS):
                continue
        kept.append(stripped)
    result = "\n".join(kept)
    result = re.sub(r"\n{3,}", "\n\n", result)
    return result.strip()


def _product_label(line: str) -> str:
    """Return the real product text of a list line, or "" when there is none.

    Decoration only (bullets/arrows/emoji/punctuation) and pure links are not a
    label: a list of variant links under one headline has ONE label, not four,
    and pretending otherwise deletes the headline (product name + price) from
    the published post.
    """
    text = re.sub(r"^[^\w\u20b9]+", "", (line or "").strip())
    text = re.sub(r"[^\w\u20b9%)]+$", "", text).strip(" \t:|-+*~")
    text = re.sub(r"^[\s\u279c\u27a1\u2192\u2193\U0001f449\U0001f517\u2022\u25aa\ufe0f:|*-]+", "", text).strip()
    if len(text) < 4 or not re.search(r"[A-Za-z]{2}", text):
        return ""
    # A line that still carries a link is a link line, not a product label (the
    # label of a same-line pair is passed in already cut before the URL).
    if URL_RE.search(text) or "http" in text.lower():
        return ""
    # A pure campaign banner is source decoration. It stays in the post (see
    # STRIP_CAMPAIGN_BANNERS), but it must never be consumed as a product label,
    # or the real product line below it loses its pairing.
    if is_campaign_banner_line(text):
        return ""
    return text


def format_visible_source_product_pairs(raw_text: str,
                                        mapping: dict[str, str],
                                        drop_urls: frozenset[str] = frozenset()) -> str | None:
    """Rebuild visible product-list posts by source order, not fragile entity spans.

    drop_urls lists the source URLs whose product was ALREADY posted: those
    items drop WHOLE - the link line and the label line that names it leave
    the post together (USER RULE 2026-09-06), instead of the label staying
    above a raw source link no one can buy through.
    """
    lines = clean_source_text(raw_text).splitlines()
    used_label_lines: set[int] = set()
    pairs: list[tuple[str, str]] = []
    used_affiliates: set[str] = set()
    # Lines that belong to an already-posted item (its link line and the label
    # line naming it) - the whole item leaves the post.
    dropped_lines: set[int] = set()

    for index, line in enumerate(lines):
        raw_urls = URL_RE.findall(line)
        if not raw_urls:
            continue
        for raw_url in raw_urls:
            url_key = clean_url(raw_url)
            if url_key in drop_urls:
                # Mark this item's own label line the same way the fresh walk
                # finds one - but never claim a label another item already
                # uses: the neighbour keeps its label, only the link leaves.
                dropped_lines.add(index)
                if not _product_label(line.split(raw_url, 1)[0]):
                    for previous in range(index - 1, -1, -1):
                        if previous in used_label_lines:
                            continue
                        if _product_label(lines[previous]):
                            dropped_lines.add(previous)
                            used_label_lines.add(previous)
                            break
                continue
            affiliate = mapping.get(url_key)
            if not affiliate or affiliate in used_affiliates:
                continue
            prefix = line.split(raw_url, 1)[0]
            # A label has to carry the product's own words. Leading decoration
            # (bullets, arrows, emoji, dashes) is stripped by CLASS, not by an
            # emoji list: "\u279c https://.." used to yield the label "\u279c", which
            # turned a bullet into a "product" and then the real title line
            # vanished from the post (name and price gone, bare links only).
            label = _product_label(prefix)
            label_index = index
            if not label:
                for previous in range(index - 1, -1, -1):
                    if previous in used_label_lines:
                        continue
                    candidate = _product_label(lines[previous])
                    if candidate:
                        label, label_index = candidate, previous
                        break
            if label:
                label = tidy_post(label)
                if label:
                    pairs.append((label, affiliate))
                    used_label_lines.add(label_index)
                    used_affiliates.add(affiliate)

    # Only a genuine multi-product list may be rebuilt this way. (Fewer than 3
    # real labels means one product with several variant links: keep the source
    # layout, which already carries the name, the price and every link.) An
    # already-posted item changes that: rebuilding is exactly what removes it
    # whole, so any list with a drop and at least one fresh, labelled item is
    # rebuilt too.
    if len(pairs) < 3 and not (drop_urls and len(pairs) >= 1):
        return None
    # Rebuild in SOURCE ORDER instead of emitting only the pairs: the old pair
    # dump silently dropped every line that was not a label (a second header
    # line, MRP / shipping notes), which breaks "publish what the source wrote".
    # Every product line and every link stays, each link still sits under its
    # own label, and no link is ever reordered or pooled.
    output: list[str] = []
    emitted: set[str] = set()
    for index, line in enumerate(lines):
        raw_urls = URL_RE.findall(line)
        if not raw_urls:
            if index in dropped_lines:
                # The label line of an already-posted item: dropped whole.
                continue
            # Any text line prints where it stood in the source - a label keeps
            # its place above its link, a second header or an MRP note keeps its
            # own place too.
            kept = tidy_post(line)
            if kept:
                output.append(kept)
            continue
        if index in dropped_lines and all(clean_url(u) in drop_urls for u in raw_urls):
            # Every link on the line belongs to already-posted items: the item
            # drops whole, its head label with it.
            continue
        head = tidy_post(_product_label(line.split(raw_urls[0], 1)[0]))
        if head:
            output.append(head)
        for raw_url in raw_urls:
            url_key = clean_url(raw_url)
            if url_key in drop_urls:
                continue
            affiliate = mapping.get(url_key)
            if affiliate:
                if affiliate in emitted:
                    continue
                emitted.add(affiliate)
                output.append(affiliate)
            else:
                # Never swallow a link here: an unmapped source URL is handled by
                # the provenance / pass-through / repair passes in render_job.
                output.append(raw_url)
    return "\n".join(output).strip()


# A price the way these sources actually type it. "₹258" is only one of the
# spellings: "at 258", "@167", "Rs 180", "220/-" are the same money, and the old
# ₹-only test is why a four-product list ("Methi Dana 500 gms at 180") was
# published as four naked labels followed by four naked links - the "neatga
# ravali" complaint.
PRICE_LABEL_RE = re.compile(
    r"(?:₹|\brs\.?|\binr)\s*[\d,]{2,}"
    r"|(?:\bat|@)\s*[\d,]{2,}"
    r"|\b[\d,]{2,}\s*/-",
    re.I,
)


def _list_product_label(line: str) -> str:
    """A conservative product-name candidate for a bottom-linked roundup."""
    label = _product_label(line)
    if not label or URL_RE.search(label) or PRICE_LABEL_RE.search(label):
        return ""
    if is_campaign_banner_line(label) or is_promo_noise_line(label):
        return ""
    if re.search(r"(?i)\b(?:apply\s+coupon|use\s+code|coupon|code|buy\s+max|"
                 r"max\s+quantity|click\s+here|shop\s+now|buy\s+now)\b", label):
        return ""
    normalized = re.sub(r"[^a-z0-9]+", "", label.lower())
    if (normalized in _SHORT_LIST_NON_PRODUCT_WORDS
            or normalized in {"todaysbestdeals", "todaysoffers", "bestdeals", "bestoffers", "topdeals"}):
        return ""
    return label


def _product_name_from_price_line(line: str) -> str:
    """Return a real name from a line such as "Dove Deal Price ₹99", else empty."""
    candidate = PRICE_LABEL_RE.sub(" ", line or "")
    candidate = re.sub(r"(?i)\b\d[\d,]*\s*%\s*(?:off|discount)?\b", " ", candidate)
    candidate = re.sub(
        r"(?i)\b(?:deal|price|mrp|regular|original|list|only|just|from|now|"
        r"off|discount|flat|save|rs\.?|inr|rupees?)\b", " ", candidate,
    )
    return _list_product_label(candidate)


def split_inline_product_links(text: str) -> str:
    """Put each product on its own line with its link underneath it.

    THE DEFECT (user, 2026-09-06): "list of products text paina and kinda
    links". Some sources write a whole list on ONE line -

        Boat Airdopes 141 @ 899 https://a Samsung M14 @ 9999 https://b

    - which reads as a wall of text and gives no way to tell which link belongs
    to which product. format_clustered_product_list() only handles the other
    shape (all links grouped at the bottom), so this one went out untouched.

    Every link here already ends a product, so the text is cut AFTER each URL
    and the URL moved to its own line:

        Boat Airdopes 141 @ 899
        https://a

        Samsung M14 @ 9999
        https://b

    Nothing is invented, dropped or reordered. A line with a single trailing
    link is already correct and is left exactly as it is, so a neat source
    stays neat.
    """
    if not text:
        return text
    out: list[str] = []
    changed = False
    for line in text.splitlines():
        # A markdown list on one line ("[A](u1) @99 [B](u2) @199") is split on
        # the markdown boundary, so each product keeps its own label and link;
        # the unwrapping in normalize_nested_link_markup() then runs per line.
        md = list(re.finditer(r"\[[^\]\[]*?\]\s*\(\s*https?://[^\s)]+?\s*\)", line))
        if len(md) >= 2:
            pieces, cursor = [], 0
            for m in md:
                lead = line[:m.start()].strip() if not pieces else line[cursor:m.start()].strip()
                if lead and pieces:
                    pieces[-1] = f"{pieces[-1]} {lead}".strip()
                elif lead:
                    pieces.append(lead)
                pieces.append(m.group(0))
                cursor = m.end()
            tail = line[cursor:].strip()
            if tail and pieces:
                pieces[-1] = f"{pieces[-1]} {tail}".strip()
            out.extend(p for p in pieces if p)
            changed = True
            continue
        # A line still carrying markdown/bracket wrapping is NOT a plain inline
        # list: the "links" are the same URL nested inside its own label
        # ("[url](url](url))"), and splitting on them would emit the duplicate
        # copies as separate products. normalize_nested_link_markup() collapses
        # those first; this pass only ever handles already-plain text.
        if "[" in line or "]" in line or "(" in line:
            out.append(line)
            continue
        urls = list(URL_RE.finditer(line))
        # Two or more links on one line, with text between them, is the defect.
        if len(urls) < 2:
            out.append(line)
            continue
        pieces: list[str] = []
        cursor = 0
        for match in urls:
            label = line[cursor:match.start()].strip(" \t|-\u2013\u2014>*")
            if label:
                pieces.append(label)
            pieces.append(match.group(0))
            cursor = match.end()
        tail = line[cursor:].strip(" \t|-\u2013\u2014>*")
        if tail:
            pieces.append(tail)
        # Only rewrite when it actually separates products (a label before a
        # link at least twice); two bare links in a row are left alone.
        labelled = sum(1 for i, piece in enumerate(pieces)
                       if URL_RE.fullmatch(piece) and i and not URL_RE.fullmatch(pieces[i - 1]))
        if labelled < 2:
            out.append(line)
            continue
        changed = True
        for i, piece in enumerate(pieces):
            out.append(piece)
            # blank line after each link, so the products read as separate deals
            if URL_RE.fullmatch(piece) and i != len(pieces) - 1:
                out.append("")
    return "\n".join(out) if changed else text


def format_clustered_product_list(text: str) -> str:
    """Pair 3+ product/price labels with a trailing block of generated URLs.

    Sources may interleave each product name and price, group all names before
    all prices, or write name + price on the same line, then dump links at the
    bottom. Reflow those shapes into source-order item blocks, keeping each
    product's notes and pairing its link by list order. Nothing is invented or
    dropped; only the layout is changed where the source left links detached.
    """
    lines = [line.strip() for line in (text or "").splitlines() if line.strip()]
    url_positions = [i for i, line in enumerate(lines) if URL_RE.fullmatch(line)]
    if len(url_positions) < 3:
        return text
    first_url = url_positions[0]
    # Only fix posts whose generated URLs are all grouped at the bottom.
    if any(not URL_RE.fullmatch(line) for line in lines[first_url:]):
        return text
    head = lines[:first_url]
    item_price_positions = []
    for index, line in enumerate(head):
        if not PRICE_LABEL_RE.search(line):
            continue
        has_inline_name = bool(_product_name_from_price_line(line))
        reference_only = bool(
            re.search(r"(?i)\b(?:mrp|regular\s+price|original\s+price|list\s+price)\b", line)
            and not has_inline_name
            and not re.search(r"(?i)\b(?:deal\s+price|offer\s+price|now|only)\b", line)
        )
        if not reference_only:
            item_price_positions.append(index)
    if len(item_price_positions) < 3:
        return text

    price_names = [_product_name_from_price_line(head[index]) for index in item_price_positions]
    pre_price_labels = [
        index for index in range(item_price_positions[0])
        if _list_product_label(head[index])
    ]
    # Some sources group all names first, then all prices, then all links. Pair
    # those three ordered runs by index rather than attaching every price to the
    # last name seen (which both lost names and mismatched items).
    grouped_names_first = (
        not any(price_names)
        and len(pre_price_labels) >= len(item_price_positions)
    )
    preamble: list[str] = []
    blocks: list[list[str]] = []
    if grouped_names_first:
        selected_labels = pre_price_labels[-len(item_price_positions):]
        first_label = selected_labels[0]
        first_price = item_price_positions[0]
        preamble = head[:first_label]
        for index, label_at in enumerate(selected_labels):
            next_label = (selected_labels[index + 1]
                          if index + 1 < len(selected_labels) else first_price)
            price_at = item_price_positions[index]
            next_price = (item_price_positions[index + 1]
                          if index + 1 < len(item_price_positions) else len(head))
            name_lines = head[label_at:next_label]
            price_lines = head[price_at:next_price]
            blocks.append(name_lines + price_lines)
    else:
        # Interleaved lists may put a short name on one line and its price on
        # the next. Start each block at that nearest unused name; inline name +
        # price lines start their own block. CTA/MRP notes remain with the item.
        starts: list[int] = []
        previous_price = -1
        for price_at, inline_name in zip(item_price_positions, price_names):
            start = price_at
            if not inline_name:
                candidates = [
                    index for index in range(previous_price + 1, price_at)
                    if _list_product_label(head[index])
                ]
                if candidates:
                    start = candidates[-1]
            starts.append(start)
            previous_price = price_at
        if len(starts) < 3:
            return text
        preamble = head[:starts[0]]
        for index, start in enumerate(starts):
            end = starts[index + 1] if index + 1 < len(starts) else len(head)
            blocks.append(head[start:end])

    urls = [lines[i] for i in url_positions]
    pair_count = min(len(blocks), len(urls))
    output = list(preamble)
    for index in range(pair_count):
        if output:
            output.append("")
        output.extend(blocks[index])
        output.append(urls[index])
    # A list with more links than labels (variant links) keeps the extras rather
    # than losing them: a dropped link is a dropped deal.
    for extra in urls[pair_count:]:
        output.append(extra)
    for leftover in blocks[pair_count:]:
        output.append("")
        output.extend(leftover)
    return "\n".join(output).strip()


# ---------------------------------------------------------------------------
# Affiliate-programme safe copy (the shopping channel)
# ---------------------------------------------------------------------------
# USER RULE (2026-09-05): t.me/smartbuyhub11 is the channel submitted for Amazon
# Associates approval. Amazon's review rejects "loot", urgency, buy-max-quantity
# instructions and discount claims it cannot verify, so that channel receives the
# SAME deal with a plain body: product name, price, link. Nothing is invented -
# every word and every number still comes from the source post.
_SAFE_DROP_LINE_RE = re.compile(
    r"(?i)^\s*(?:\**\s*)?(?:"
    r"buy\s+max(?:imum)?\s+quantity|max\s+quantity|buy\s+max|order\s+fast|"
    # A banner line that is nothing BUT hype words ("MEGA LOOT", "🔥 SUPER LOOT 🔥",
    # "DEAL OF THE DAY"). It carries no product and no price, so dropping the whole
    # line loses nothing - and leaving it in is the single word most likely to fail
    # the review. Emoji/punctuation around it are stripped by the caller.
    r"(?:mega|super|big|huge|best|top|hot)?\s*loot\s*(?:zone|deal|alert|offer)?s?|"
    r"hurry(?:\s*up)?|limited\s+stock|stock\s+limited|fast\s+selling|"
    r"grab\s+(?:it\s+)?(?:now|fast)|buy\s+(?:it\s+)?now|shop\s+now|"
    r"deal\s+of\s+the\s+day|price\s+may\s+change|#\w+"
    r")\s*[!.:]*\s*$"
)
# A banner word in front of the product name ("Loot : X", "GRAB : X", and just
# as often "Grab ₹298 (X)" with no colon at all). It is source decoration in
# both the programme-safe rewrite and the duplicate signature, so the separator
# is optional - otherwise the SAME deal signs differently depending on whether
# that channel typed a colon.
_SAFE_PREFIX_RE = re.compile(
    r"(?i)^\s*(?:🔥|⚡|🚨|💥|🏃|👑|💰|🔔|✅|❗|‼️|👉|➡️|•|\*|-|~)*\s*"
    r"(?:super\s*loot|mega\s*loot|price\s*drop|lowest\s*price|big\s*deal|"
    r"hot\s*deal|best\s*deal|loot|grab|deal|steal|offer|alert)"
    r"(?:\s*[:\-–]\s*|\s+(?=[₹@]|\d))"
)
_SAFE_CLAIM_RE = re.compile(
    r"(?i)\b(?:#?\s*(?:uk|india|world)?\s*no\.?\s*1\s+brand|cheapest\s+ever|"
    r"lowest\s+ever|all\s+time\s+low|biggest\s+sale|loot\s+price|"
    r"steal\s+deal|must\s+buy)\b"
)
# Our own promo, in every shape it can reach a rendered post: the folder link,
# the main-channel links, and the "All Loot Channels" caption that sits with them.
_SAFE_OWN_PROMO_LINKS = (OUR_FOLDER_LINK, *OUR_MAIN_CHANNEL_LINKS, "t.me/")
_SAFE_OWN_PROMO_TEXT_RE = re.compile(
    r"(?i)\ball\s+loot\s+channels\b|\bloot\s+zone\b|\bsecret\s+loot\b|"
    r"\bjoin\b.*\bchannel\b|\bone\s+tap\b")
_EMOJI_RE = re.compile(
    "[" "\U0001f300-\U0001faff" "\U00002190-\U000021ff" "\U00002600-\U000027bf"
    "\U00002b00-\U00002bff" "\U0000fe0f" "\U00002122" "\U000024c2" "]+"
)


def affiliate_safe_text(text: str) -> str:
    """The compliance-safe copy of a rendered deal: name, price, our link.

    Used ONLY for the channel that is under Amazon Associates review. It removes
    the promotional scaffolding a marketplace programme objects to (loot/hurry
    banners, "buy max quantity", unverifiable superlatives, emoji shouting) and
    keeps the product line, the price the source printed and the link.
    """
    out_lines: list[str] = []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            if out_lines and out_lines[-1] != "":
                out_lines.append("")
            continue
        # Our own family/channel promo must never reach the reviewer: a card
        # offer has the folder link appended into the stored copy, and a
        # reviewer who taps it lands in "Loot Zone"/"Secret Loot" - exactly the
        # wording this channel exists to avoid. It is OUR line, not the
        # source's, so removing it loses no deal content.
        if any(promo in line for promo in _SAFE_OWN_PROMO_LINKS):
            continue
        if _SAFE_OWN_PROMO_TEXT_RE.search(line):
            continue
        if URL_RE.fullmatch(line):
            out_lines.append(line)
            continue
        # Emoji come off BEFORE the banner test: "🔥 MEGA LOOT 🔥" is the same
        # pure-hype line as "MEGA LOOT", and testing the raw line let the
        # decorated version straight through.
        line = _EMOJI_RE.sub(" ", line).strip()
        if not line:
            continue
        if _SAFE_DROP_LINE_RE.match(line):
            continue
        line = _SAFE_PREFIX_RE.sub("", line)
        line = _SAFE_CLAIM_RE.sub(" ", line)
        line = _EMOJI_RE.sub(" ", line)
        line = re.sub(r"(?i)\b(?:buy\s+max(?:imum)?\s+quantity|hurry(?:\s*up)?|"
                      r"limited\s+stock|grab\s+fast|buy\s+now|shop\s+now)\b[!.,]*", " ", line)
        # USER RULE: "just name petti price pettu anthe". A discount percentage
        # and a struck-through MRP are exactly the claims a marketplace reviewer
        # asks us to prove, and the source's own price is enough on its own.
        line = re.sub(r"(?i)\(?\s*(?:flat\s*|upto\s*|up\s*to\s*|save\s*)?\d{1,3}\s*%\s*"
                      r"(?:off|discount)?\s*\)?", " ", line)
        line = re.sub(r"(?i)^\s*(?:reg(?:ular)?|mrp|m\.r\.p\.?|list\s*price|was)\b\s*"
                      r"[:.\-]?\s*(?:rs\.?|₹|inr)?\s*[\d,]+\s*/?-?\s*$", " ", line)
        line = re.sub(r"[ \t]{2,}", " ", line).strip(" \t|-–—:•*~")
        if not line:
            continue
        # A line with no product words left (a lone "!!!" or a bare hash tag) is
        # scaffolding, not content.
        if not re.search(r"[A-Za-z0-9₹]", line):
            continue
        out_lines.append(line)
    body = "\n".join(out_lines)
    body = re.sub(r"\n{3,}", "\n\n", body).strip()
    if SAFE_STRICT_REBUILD:
        body = _strict_review_copy(body)
    return body


# ---------------------------------------------------------------------------
# STRICT review copy (EarnKaro / Amazon channel under review)
# ---------------------------------------------------------------------------
# USER RULE (2026-09-05): the new channel is submitted for review, so it must
# follow the programme rules 100% - the other channels stay exactly as they are.
# A blocklist ("remove the words we thought of") is the wrong tool for that: the
# ONE hype word nobody listed is the one the reviewer sees. So the review copy is
# REBUILT from an allowlist instead - only two kinds of line survive:
#     1. a product line   -> the product's own words + the price the source printed
#     2. the link
# Anything else is dropped. Nothing is ever invented: every word and every digit
# still comes from the source post.
SAFE_STRICT_REBUILD = os.getenv(
    "SAFE_STRICT_REBUILD", "true").strip().lower() not in ("0", "false", "no", "off")
# Words that must never survive into the review copy, whatever shape the line has.
# This is the LAST net, not the first: the allowlist above has already run.
_STRICT_BANNED_RE = re.compile(
    r"(?i)\b(?:loot|steal|jackpot|bumper|dhamaka|blast|crazy|insane|cheapest|"
    r"lowest|biggest|hurry|fast|urgent|limited|stock|grab|max\s*quantity|"
    r"free\s*money|guaranteed|must\s*buy|don'?t\s*miss|last\s*chance|"
    r"hot|mega|super\s*deal|price\s*error|glitch|trick|cashback\s*trick)\b")


# Lines that must never survive into the review copy, whatever else they say.
# The 2026-09-06 rejection named "reviews" explicitly alongside trademarked
# words and screenshots, and RATINGS/REVIEW COUNTS are Amazon-owned content we
# are not licensed to republish. Everything else here is either an unverifiable
# claim, a condition the reviewer reads as a catch, or pure decoration.
_STRICT_DROP_LINE_RE = re.compile(
    r"(?i)("
    r"\b\d(?:\.\d)?\s*(?:\u2b50|stars?|/\s*5)\b"          # 4.2 stars, 4.2/5
    r"|\brating[s]?\b|\breview[s]?\b|\bratings?\s*&\s*reviews?\b"
    r"|\b\d[\d,]*\s*(?:reviews?|ratings?)\b"                 # 12,453 reviews
    r"|\bbest\s*sell(?:er|ing)\b|\b#\d+\s*in\b"            # bestseller badges
    r"|\bm\.?r\.?p\.?\b|\blist\s*price\b"                  # MRP anchor pricing
    r"|\b\d{1,3}\s*%\s*(?:off|discount)?\b"                  # 70% OFF
    r"|\bsave\s*(?:rs\.?|\u20b9|inr)?\s*[\d,]+\b"
    r"|\bcoupon\b|\bapply\b|\bclip\b|\bpromo\s*code\b|\bcode\s*[:\-]"
    r"|\bcashback\b|\bbank\s*offer\b|\bemi\b|\bexchange\b"
    r"|\bbuy\s*now\b|\bshop\s*now\b|\border\s*now\b|\bclick\b|\btap\b"
    r"|\bjoin\b|\bshare\b|\bsubscribe\b|\bfollow\b"
    r"|\bsold\s*out\b|\bout\s*of\s*stock\b|\bstock\s*(?:left|over)\b"
    r"|\bqty\b|\bquantity\b|\bpieces?\s*left\b"
    r"|\bstore\b\s*$"                                          # "Under 99 Store"
    r")")


def _salvage_price_only(line: str) -> str:
    """Return "Price: <amount>" when a dropped line still carried the DEAL price.

    The amount is copied verbatim from the source - never recomputed - and any
    MRP/list-price anchor is masked out first so the higher number can never be
    mistaken for the price we publish.
    """
    masked = re.sub(
        r"(?i)\b(?:mrp|m\.r\.p\.?|list\s*price|regular\s*price)\s*[:@-]?\s*"
        r"(?:rs\.?|\u20b9|inr)?\s*[\d,]+", " ", line or "")
    # Only an explicitly-marked amount counts; a bare number is a model code.
    match = re.search(r"(?:rs\.?|\u20b9|inr)\s*\.?\s*([\d,]+)|([\d,]+)\s*/-", masked, re.I)
    if not match:
        return ""
    amount = (match.group(1) or match.group(2) or "").strip()
    if not amount or not amount.replace(",", "").isdigit():
        return ""
    return f"Price: \u20b9{amount}"


def _strict_review_copy(body: str) -> str:
    """Rebuild a post from an allowlist: product line(s) + link. Nothing else.

    The price is kept EXACTLY as the source printed it (₹298 / at 258 / @167),
    because a price we re-format is a price we could get wrong, and a wrong price
    is the one thing a marketplace programme will not forgive.
    """
    kept: list[str] = []
    for line in (body or "").splitlines():
        line = line.strip()
        if not line:
            continue
        if URL_RE.fullmatch(line):
            kept.append(line)
            continue
        if _STRICT_BANNED_RE.search(line):
            continue
        # Amazon marks and Telegram pointers are the two things the 2026-09-06
        # rejection actually named. Drop the line rather than try to reword it.
        if has_amazon_trademark(line) or has_telegram_pointer(line):
            continue
        # Ratings/review counts are Amazon-owned content ("or reviews" in the
        # rejection); MRP/percent-off/coupons are conditions and anchor claims a
        # reviewer reads as a catch. None of it is needed to sell the product.
        if _STRICT_DROP_LINE_RE.search(line):
            # "Price - Rs.899 (MRP Rs.2990)" is dropped for the MRP anchor, but
            # the DEAL price on it is the one fact the post cannot lose. Keep the
            # price alone, exactly as the source printed it, and drop the rest.
            salvaged = _salvage_price_only(line)
            if salvaged:
                kept.append(salvaged)
            continue
        # A product line has to read like a product: real words, and not a bare
        # number or a lone symbol. Two letter-words is the floor ("Methi Dana").
        words = re.findall(r"[A-Za-z][A-Za-z'&.-]+", line)
        if len(words) < 2:
            # "Dustpan @ 55" is a real product line: ONE specific noun plus the
            # price. Requiring two words threw the product name away and left the
            # reviewer a post that was nothing but "Price: 55" - no product at
            # all. A single word counts when it is specific enough (>=5 letters)
            # and the line states a price; a bare "@ 299/-" still becomes a price
            # line, and a lone short word is still dropped as decoration.
            # A brand plus a model number ("boAt 141", "Redmi 13C") is one word
            # by this count but is unmistakably a product; losing it left the
            # reviewer a price with no product name at all.
            # "Redmi 13C" / "WH-1000XM4" / "boAt 141": a word next to a number,
            # with an optional letter suffix on the number.
            has_model = bool(re.search(
                r"[A-Za-z][A-Za-z'&.-]*\s*[-]?\s*\d{2,}[A-Za-z]{0,3}\b", line))
            if (len(words) == 1 and (len(words[0]) >= 5 or has_model)
                    and not _STRICT_DROP_LINE_RE.search(line)
                    and (parse_price(line) is not None or has_model)):
                cleaned = re.sub(r"\s{2,}", " ", line).strip(" \t|-–—:•*~,")
                if cleaned:
                    kept.append(cleaned)
                    continue
            salvaged = _salvage_price_only(line)
            if salvaged:
                kept.append(salvaged)
            continue
        # Trailing junk the earlier passes may have left on an otherwise good line.
        line = re.sub(r"\s{2,}", " ", line).strip(" \t|-–—:•*~,")
        if line:
            kept.append(line)
    # A shopper needs the price. If none of the surviving lines carries one, take
    # it from the ORIGINAL post rather than publish a product with no price.
    body_text = URL_RE.sub(" ", "\n".join(kept))
    # "Pigeon Kettle 1.5L at 549" already states the price; adding "Price: 549"
    # under it is the duplicate the user keeps reporting. So the check accepts
    # ANY amount already visible - with a currency mark, the Indian "/-" suffix,
    # or an "at/only/@" price phrase - not just a currency-marked one.
    has_price = re.search(
        r"(?i)(?:rs\.?|\u20b9|inr)\s*\.?\s*[\d,]+"
        r"|[\d,]+\s*/-"
        # "\b@" can never match after a space (@ is not a word character), so
        # "Dustpan @ 55" looked price-less and gained a duplicate "Price: 55"
        # line underneath. The word forms keep their boundary; @ does not need one.
        r"|(?:\b(?:at|only|for)|@)\s*(?:rs\.?|\u20b9|inr)?\s*[\d,]{2,}\b",
        body_text)
    if kept and not has_price:
        price = parse_price(body or "")
        if price:
            link_at = next((i for i, ln in enumerate(kept) if URL_RE.fullmatch(ln)), len(kept))
            kept.insert(link_at, f"Price: \u20b9{price:,}")
    # Never repeat the same line twice (two sources, one merged post).
    deduped = list(dict.fromkeys(kept))
    return "\n".join(deduped).strip()


def _premium_windows(around: datetime) -> list[tuple[datetime, datetime, str]]:
    windows = []
    for day_offset in (-1, 0, 1, 2):
        day = (around + timedelta(days=day_offset)).date()
        base = datetime.combine(day, datetime.min.time(), tzinfo=IST)
        windows.extend([
            (base.replace(hour=6), base.replace(hour=8), f"{day.isoformat()}-AM"),
            (base.replace(hour=13), base.replace(hour=14), f"{day.isoformat()}-PM"),
            (base.replace(hour=18), (base + timedelta(days=1)).replace(hour=1), f"{day.isoformat()}-EVE"),
        ])
    return sorted(windows, key=lambda item: item[0])


def premium_time_status(now_ts: float | None = None) -> tuple[bool, str, float]:
    """Premium windows: 06–08, 13–14, and 18–01 IST."""
    now = datetime.fromtimestamp(now_ts or time.time(), IST)
    windows = _premium_windows(now)
    for index, (start, end, key) in enumerate(windows):
        if start <= now < end:
            next_start = next((item[0] for item in windows[index + 1:] if item[0] >= end), end)
            return True, key, next_start.timestamp()
    for start, _end, key in windows:
        if start > now:
            return False, key, start.timestamp()
    fallback = now + timedelta(days=1)
    return False, fallback.date().isoformat() + "-AM", fallback.replace(
        hour=6, minute=0, second=0, microsecond=0
    ).timestamp()


def chunks(text: str, limit: int) -> list[str]:
    """Split at line boundaries; never silently truncate Telegram content.

    A line longer than one message is packed word by word, and a link is NEVER cut
    in half: a URL split across two messages is a dead link and an unpaid sale,
    which is a worse post than one with an awkward line break. (Until v17.8 this
    function bisected over-long lines by character index, so a long list line whose
    4200th character happened to be inside an affiliate link printed
    "https://www.amazon.in/dp/B0AB" in one message and "CDEF?tag=..." in the next.)
    """
    if len(text) <= limit:
        return [text]
    result: list[str] = []
    current = ""

    def flush() -> None:
        nonlocal current
        if current.strip():
            result.append(current.rstrip())
        current = ""

    for line in text.splitlines(True):
        if len(line) <= limit:
            if current and len(current) + len(line) > limit:
                flush()
            current += line
            continue
        flush()
        piece = ""
        for token in re.split(r"(\s+)", line):     # whitespace kept, so nothing is lost
            if not token:
                continue
            if len(token) > limit:                 # a single monster token: no link is that long
                if piece.strip():
                    result.append(piece.rstrip())
                    piece = ""
                result.extend(token[i:i + limit] for i in range(0, len(token), limit))
                continue
            if piece and len(piece) + len(token) > limit:
                result.append(piece.rstrip())
                piece = ""
            piece += token
        current = piece
    flush()
    return result


MARKED_CHANNEL_PREFIX = 1_000_000_000_000  # Telegram's "-100" channel marker


def raw_chat_id(value: Any) -> int:
    """Canonical numeric chat id for dedup, independent of ID convention.

    Telethon reports a channel as `-100<id>` (Bot API "marked" form), a resolved
    entity exposes the raw positive id, and a legacy basic chat is `-<id>`. All
    three must collapse to ONE key, otherwise the same source message can be
    queued twice (once by the live event stream, once by the rescan safety net)
    and then posted twice to every target.
    """
    try:
        if hasattr(value, "id"):
            value = value.id
        v = int(value)
    except (TypeError, ValueError):
        return 0
    if v > 0:
        return v
    v = -v
    text = str(v)
    if text.startswith("100") and len(text) > 3:
        with contextlib.suppress(ValueError):
            return int(text[3:])
    if v > MARKED_CHANNEL_PREFIX:
        return v - MARKED_CHANNEL_PREFIX
    return v


def marked_chat_id(value: Any) -> int:
    """The id Telethon needs in order to FETCH messages (marked channel form)."""
    raw = raw_chat_id(value)
    if not raw:
        return 0
    try:
        entity_id = int(getattr(value, "id", raw) or raw)
    except (TypeError, ValueError):
        entity_id = raw
    # Legacy basic chats are negated without the -100 marker.
    if entity_id < 0 and not str(-entity_id).startswith("100"):
        return entity_id
    return int(f"-100{raw}")


# ---------------------------------------------------------------------------
# SQLite durable state
# ---------------------------------------------------------------------------
class Store:
    def __init__(self, path: Path):
        # timeout=30: a writer blocked behind another connection (a VACUUM in
        # maintenance, a wal_checkpoint, or an overlapping process during a
        # deploy) waits instead of raising "database is locked" into the send
        # path - where a raised ledger write used to retry the TELEGRAM send
        # and post one queue up to three times (POST_RETRIES) to the same
        # targets (post-deploy repeats, 2026-10-11).
        self.conn = sqlite3.connect(path, check_same_thread=False, timeout=30.0)
        self.conn.row_factory = sqlite3.Row
        self.lock = asyncio.Lock()
        self._schema()

    def _schema(self) -> None:
        self.conn.executescript("""
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        CREATE TABLE IF NOT EXISTS queue (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          chat_id INTEGER NOT NULL,
          msg_id INTEGER NOT NULL,
          source TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending',
          attempts INTEGER NOT NULL DEFAULT 0,
          next_at REAL NOT NULL DEFAULT 0,
          rendered_text TEXT,
          targets_json TEXT,
          deal_keys_json TEXT,
          premium_score INTEGER,
          last_error TEXT,
          created_at REAL NOT NULL,
          UNIQUE(chat_id,msg_id)
        );
        CREATE TABLE IF NOT EXISTS posted_deals (
          deal_key TEXT PRIMARY KEY,
          price INTEGER,
          posted_at REAL NOT NULL,
          queue_id INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS deal_claims (
          deal_key TEXT PRIMARY KEY,
          queue_id INTEGER NOT NULL,
          claimed_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS target_product_claims (
          target TEXT NOT NULL, signature TEXT NOT NULL, queue_id INTEGER NOT NULL,
          created_at REAL NOT NULL, PRIMARY KEY(target, signature)
        );
        CREATE INDEX IF NOT EXISTS target_claim_owner ON target_product_claims(queue_id,target);
        CREATE TABLE IF NOT EXISTS send_attempts (
          queue_id INTEGER NOT NULL, target TEXT NOT NULL, chunk_index INTEGER NOT NULL,
          payload_hash TEXT NOT NULL, state TEXT NOT NULL, updated_at REAL NOT NULL,
          PRIMARY KEY(queue_id,target,chunk_index)
        );
        CREATE TABLE IF NOT EXISTS price_posts (
          price INTEGER PRIMARY KEY,
          posted_at REAL NOT NULL,
          queue_id INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS posted_products (
          signature TEXT NOT NULL,
          target TEXT NOT NULL,
          price INTEGER,
          discount INTEGER,
          posted_at REAL NOT NULL,
          PRIMARY KEY(signature,target)
        );
        CREATE TABLE IF NOT EXISTS deliveries (
          queue_id INTEGER NOT NULL,
          target TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending',
          attempts INTEGER NOT NULL DEFAULT 0,
          chunks_sent INTEGER NOT NULL DEFAULT 0,
          last_error TEXT,
          PRIMARY KEY(queue_id,target)
        );
        CREATE TABLE IF NOT EXISTS link_cache (
          source_url TEXT PRIMARY KEY,
          affiliate_url TEXT NOT NULL,
          resolved_url TEXT,
          deal_key TEXT,
          created_at REAL NOT NULL
        );
        -- Durable proof when our authenticated network URL was shortened through
        -- Bitly/is.gd. The product destination remains in link_cache.resolved_url;
        -- this table records the actual owned URL hidden behind our generated hop.
        CREATE TABLE IF NOT EXISTS owned_link_proofs (
          affiliate_url TEXT PRIMARY KEY,
          destination_url TEXT NOT NULL,
          proof_type TEXT NOT NULL,
          publisher_id TEXT NOT NULL DEFAULT '',
          created_at REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS hypd_links (
            token TEXT PRIMARY KEY,
            store TEXT NOT NULL,
            afflink_url TEXT NOT NULL,
            resolved_url TEXT,
            product_key TEXT,
            created_at REAL NOT NULL
        );
        -- Meesho products skipped because no verified HYPD link has been
        -- curated yet. This is the operator's to-do list:
        -- create the link in the HYPD
        -- app, learn it once with ops/hypd_links.py, and every later post of
        -- that product earns on it.
        CREATE TABLE IF NOT EXISTS hypd_wanted (
            product_url TEXT PRIMARY KEY,
            product_key TEXT,
            times INTEGER NOT NULL DEFAULT 1,
            first_seen REAL NOT NULL,
            last_seen REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS premium_state (
          id INTEGER PRIMARY KEY CHECK(id=1),
          night_key TEXT,
          sent_count INTEGER NOT NULL DEFAULT 0,
          next_at REAL NOT NULL DEFAULT 0,
          claim_queue_id INTEGER,
          claim_at REAL NOT NULL DEFAULT 0
        );
        INSERT OR IGNORE INTO premium_state(id) VALUES(1);
        -- Daily send counter for the review channel (IST day key), so the
        -- 20-30/day pace survives restarts instead of resetting to zero.
        -- Every post refused by the content-safety policy, with the reason.
        -- Read-only history for the dashboard: "why was this not posted?".
        -- `excerpt` masks the matched term so the log stays safe to open.
        CREATE TABLE IF NOT EXISTS blocked_content (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          stage TEXT NOT NULL,
          source TEXT NOT NULL DEFAULT '',
          msg_id INTEGER,
          queue_id INTEGER,
          target TEXT NOT NULL DEFAULT '',
          category TEXT NOT NULL DEFAULT '',
          label TEXT NOT NULL DEFAULT '',
          matched TEXT NOT NULL DEFAULT '',
          reason TEXT NOT NULL DEFAULT '',
          policy_version TEXT NOT NULL DEFAULT '',
          excerpt TEXT NOT NULL DEFAULT '',
          created_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS ix_blocked_created ON blocked_content(created_at);
        CREATE TABLE IF NOT EXISTS shopping_quota (
          day_key TEXT PRIMARY KEY,
          sent_count INTEGER NOT NULL DEFAULT 0,
          last_sent_at REAL NOT NULL DEFAULT 0
        );
        """)
        # Backward-compatible migrations.
        proof_columns = {row[1] for row in self.conn.execute(
            "PRAGMA table_info(owned_link_proofs)")}
        if "publisher_id" not in proof_columns:
            # Network proof is account-specific. Legacy rows without the
            # publisher identity must fail closed until regenerated; Amazon
            # native proof is still checked against its tagged destination.
            self.conn.execute(
                "ALTER TABLE owned_link_proofs ADD COLUMN publisher_id TEXT NOT NULL DEFAULT ''")
        quota_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(shopping_quota)")}
        if "last_sent_at" not in quota_columns:
            self.conn.execute("ALTER TABLE shopping_quota ADD COLUMN last_sent_at REAL NOT NULL DEFAULT 0")
        delivery_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(deliveries)")}
        if "chunks_sent" not in delivery_columns:
            self.conn.execute("ALTER TABLE deliveries ADD COLUMN chunks_sent INTEGER NOT NULL DEFAULT 0")
        queue_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(queue)")}
        if "premium_score" not in queue_columns:
            self.conn.execute("ALTER TABLE queue ADD COLUMN premium_score INTEGER")
        # v17.6: "best copy" bookkeeping (see product_identities).
        for column, statement in (
            ("quality", "ALTER TABLE queue ADD COLUMN quality INTEGER"),
            ("product_keys", "ALTER TABLE queue ADD COLUMN product_keys TEXT"),
            ("superseded_chat_id", "ALTER TABLE queue ADD COLUMN superseded_chat_id TEXT"),
            ("superseded_msg_id", "ALTER TABLE queue ADD COLUMN superseded_msg_id INTEGER"),
            # v18.2: the delivery-side repairs (a link cut because it is dead or unverified)
            # have to know whether a blank line is the SOURCE's layout or their own residue.
            # The rendered copy alone cannot answer that, so the raw source text rides along
            # on the row (bounded; it is bookkeeping, not content).
            ("source_text", "ALTER TABLE queue ADD COLUMN source_text TEXT"),
        ):
            if column not in queue_columns:
                self.conn.execute(statement)
        if "priority" not in queue_columns:
            self.conn.execute("ALTER TABLE queue ADD COLUMN priority INTEGER NOT NULL DEFAULT 1")
        if "chat_key" not in queue_columns:
            self.conn.execute("ALTER TABLE queue ADD COLUMN chat_key TEXT")
            # Backfill the canonical key for rows written by older builds so a
            # re-encountered message still hits the unique index instead of
            # creating a second queue row (== a second post).
            legacy_rows = self.conn.execute(
                "SELECT id, chat_id FROM queue WHERE chat_key IS NULL"
            ).fetchall()
            for row in legacy_rows:
                self.conn.execute("UPDATE queue SET chat_key=? WHERE id=?",
                                  (str(raw_chat_id(row[1])), row[0]))
        try:
            self.conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS ux_queue_chat_key ON queue(chat_key, msg_id)"
            )
        except sqlite3.IntegrityError:
            # An older build really did create two rows for one message (the
            # double-post bug). Collapse them, then enforce uniqueness for good.
            self._collapse_duplicate_queue_rows()
            self.conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS ux_queue_chat_key ON queue(chat_key, msg_id)"
            )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS ix_queue_status "
            "ON queue(status, priority, created_at)"
        )
        # HYPD share links: lookups are "which of OUR links is this product"
        # (product_key) and "where does this link go" (resolved_url).
        # Final ownership checks inspect every pairing of an affiliate URL.
        # Index this lookup so large caches do not require a full-table scan.
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_link_cache_affiliate ON link_cache(affiliate_url,created_at DESC)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_hypd_product ON hypd_links(product_key)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_hypd_resolved ON hypd_links(resolved_url)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_hypd_wanted_last ON hypd_wanted(last_seen)"
        )
        # A previous crash must not leave work permanently stuck.
        self.conn.execute("UPDATE queue SET status='pending' WHERE status='processing'")
        self.conn.commit()
        notify_queue()
        self._migrate_legacy_json()

    @staticmethod
    def _legacy_time(value: Any) -> float:
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            with contextlib.suppress(ValueError):
                from datetime import datetime
                return datetime.fromisoformat(value).timestamp()
        return 0.0

    def _collapse_duplicate_queue_rows(self) -> None:
        """Fold pre-existing duplicate (chat_key, msg_id) rows into one row.

        Only ever called from the schema migration: older builds keyed the queue
        on the raw chat id, so one source message could legitimately end up with
        two queue rows and therefore be posted twice.
        """
        duplicates = self.conn.execute(
            "SELECT chat_key, msg_id, GROUP_CONCAT(id) FROM queue "
            "WHERE chat_key IS NOT NULL GROUP BY chat_key, msg_id HAVING COUNT(*) > 1"
        ).fetchall()
        dropped = 0
        for row in duplicates:
            ids = [int(x) for x in (row[2] or "").split(",") if x]
            if len(ids) < 2:
                continue
            keep = min(ids)
            extra = [x for x in ids if x != keep]
            for queue_id in extra:
                self.conn.execute("DELETE FROM deliveries WHERE queue_id=?", (queue_id,))
                self.conn.execute("DELETE FROM deal_claims WHERE queue_id=?", (queue_id,))
                self.conn.execute("DELETE FROM queue WHERE id=?", (queue_id,))
                dropped += 1
        if dropped:
            log.info("DEDUP MIGRATION | collapsed %s duplicate queue row(s)", dropped)

    def _migrate_legacy_json(self) -> None:
        """Import recent v13/v14 JSON history once, preventing night→morning reposts."""
        legacy = BASE_DIR / "dedup_data.json"
        marker = BASE_DIR / ".dedup_json_migrated"
        if marker.exists() or not legacy.exists():
            return
        try:
            data = json.loads(legacy.read_text(encoding="utf-8"))
            cutoff = time.time() - PRODUCT_DEDUP_SECONDS
            pids = data.get("pid") or data.get("asin") or {}
            urls = data.get("url") or {}
            prices = data.get("price") or {}
            for raw_key, raw_time in pids.items():
                posted_at = self._legacy_time(raw_time)
                if posted_at < cutoff:
                    continue
                key = str(raw_key)
                if re.fullmatch(r"B[A-Z0-9]{9}", key, re.I):
                    key = "ASIN:" + key.upper()
                self.conn.execute(
                    "INSERT OR IGNORE INTO posted_deals VALUES(?,?,?,?)",
                    (key, None, posted_at, 0),
                )
            for raw_url, raw_time in urls.items():
                posted_at = self._legacy_time(raw_time)
                if posted_at >= cutoff:
                    key = "URL:" + hashlib.sha256(canonical_url(str(raw_url)).encode()).hexdigest()
                    self.conn.execute(
                        "INSERT OR IGNORE INTO posted_deals VALUES(?,?,?,?)",
                        (key, None, posted_at, 0),
                    )
            for raw_price, raw_time in prices.items():
                posted_at = self._legacy_time(raw_time)
                if posted_at >= time.time() - PRICE_DEDUP_SECONDS:
                    with contextlib.suppress(ValueError):
                        self.conn.execute(
                            "INSERT OR IGNORE INTO price_posts VALUES(?,?,?)",
                            (int(float(raw_price)), posted_at, 0),
                        )
            self.conn.commit()
            marker.write_text(str(time.time()), encoding="utf-8")
            log.info("Migrated recent legacy dedup history into SQLite")
        except Exception as exc:
            log.warning("Legacy dedup migration skipped: %s", exc)

    async def _commit(self, patient: bool = False) -> None:
        """Commit, riding out transient writer contention instead of raising it.

        The send path treats a raised ledger write as "not recorded" and retries
        the TELEGRAM send - which is exactly-once violated. A busy/locked commit
        (VACUUM, checkpoint, deploy overlap) almost always clears within seconds,
        so it is retried here with backoff; only a durable failure raises, and
        the caller then logs it instead of re-sending an already-sent chunk.
        patient=True is for writes that settle an ALREADY-SENT post (delivery
        ok=True, mark_product_posted, premium completion, chunk checkpoint): a
        stalled worker beats a duplicated post, so these wait minutes, not
        seconds, before admitting defeat.
        """
        attempts = 30 if patient else 10
        base, cap = (0.1, 10.0) if patient else (0.05, 2.0)
        for attempt in range(attempts):
            try:
                self.conn.commit()
                return
            except sqlite3.OperationalError as exc:
                message = str(exc).lower()
                if "locked" not in message and "busy" not in message:
                    raise
                if attempt >= attempts - 1:
                    raise
                await asyncio.sleep(min(cap, base * (2 ** attempt)))
        self.conn.commit()

    async def queue_id_for(self, chat_id: int, msg_id: int) -> int | None:
        """The queue id behind a just-queued message - so the immediacy log line
        can be paired with the "JOB N | ... sent=" line by the deploy verifier."""
        key = str(raw_chat_id(chat_id))
        async with self.lock:
            row = self.conn.execute("SELECT id FROM queue WHERE chat_key=? AND msg_id=?",
                                    (key, msg_id)).fetchone()
        return int(row[0]) if row else None

    @staticmethod
    def identity_aliases(keys) -> list[str]:
        """Match legacy www/mobile merchant keys without changing product IDs.

        Only established merchant hosts are aliases; unrelated shops/subdomains
        and different product/variant IDs must never collapse.
        """
        result = set(keys)
        for key in keys:
            match = re.fullmatch(
                r"(PID|PROD|IT|SKU):(?:www\.|m\.)?"
                r"(meesho\.com|flipkart\.com|croma\.com):(.+)", key)
            if match:
                kind, host, product = match.groups()
                result.update(f"{kind}:{prefix}{host}:{product}"
                              for prefix in ("", "www.", "m."))
        return sorted(result)

    async def claim_target_products(self, queue_id: int, target: str, keys: list[str],
                                    resuming: bool = False) -> bool:
        """Durable last-mile exclusion, atomic across workers/connections.

        No time-based expiry: an interrupted send may already be visible. Its
        product stays fenced until the original job settles or is reviewed.
        Recheck the absolute hour here to close check -> send/settle races.
        """
        keys = self.identity_aliases(keys)
        async with self.lock:
            try:
                self.conn.execute("BEGIN IMMEDIATE")
                for key in keys:
                    owner = self.conn.execute(
                        "SELECT queue_id FROM target_product_claims WHERE target=? AND signature=?",
                        (target, key)).fetchone()
                    if owner and owner[0] != queue_id:
                        self.conn.rollback()
                        return False
                    recent = self.conn.execute(
                        "SELECT 1 FROM posted_products WHERE target=? AND signature=? AND posted_at>?",
                        (target, key, time.time() - SAME_PRODUCT_COOLDOWN_SECONDS)).fetchone()
                    if recent and not resuming:
                        self.conn.rollback()
                        return False
                for key in keys:
                    self.conn.execute("INSERT OR IGNORE INTO target_product_claims VALUES(?,?,?,?)",
                                      (target, key, queue_id, time.time()))
                await self._commit(patient=True)
                return True
            except BaseException:
                self.conn.rollback()
                raise

    async def release_target_products(self, queue_id: int, target: str) -> None:
        async with self.lock:
            self.conn.execute("DELETE FROM target_product_claims WHERE queue_id=? AND target=?",
                              (queue_id, target))
            await self._commit(patient=True)

    async def send_attempt(self, queue_id: int, target: str, index: int,
                           payload_hash: str, state: str) -> bool:
        """Write-before-send fence. A crash/timeout is never permission to retry.

        A confirmed rejection is retryable. A confirmed success advances the
        chunk checkpoint in the SAME transaction. Started/uncertain attempts
        need operator review; even a second process cannot send them again.
        """
        async with self.lock:
            try:
                self.conn.execute("BEGIN IMMEDIATE")
                old = self.conn.execute(
                    "SELECT payload_hash,state FROM send_attempts WHERE queue_id=? AND target=? AND chunk_index=?",
                    (queue_id, target, index)).fetchone()
                if state == "plan" and old and old[0] != payload_hash:
                    raise AmbiguousDelivery("delivery layout changed after preparation; manual review required")
                if state == "started" and old:
                    if old[0] != payload_hash or old[1] in {"started", "uncertain"}:
                        raise AmbiguousDelivery("unsettled or changed send attempt; manual review required")
                    if old[1] == "sent":
                        self.conn.rollback()
                        return False
                self.conn.execute("INSERT OR REPLACE INTO send_attempts VALUES(?,?,?,?,?,?)",
                                  (queue_id, target, index, payload_hash, state, time.time()))
                if state == "sent":
                    self.conn.execute(
                        "UPDATE deliveries SET chunks_sent=MAX(chunks_sent,?) WHERE queue_id=? AND target=?",
                        (index + 1, queue_id, target))
                await self._commit(patient=True)
                return True
            except BaseException:
                self.conn.rollback()
                raise

    async def delivery_held(self, queue_id: int, target: str, reason: str) -> None:
        async with self.lock:
            self.conn.execute(
                "UPDATE deliveries SET status='held',last_error=?,attempts=attempts+1 WHERE queue_id=? AND target=?",
                ("manual review: " + reason[:460], queue_id, target))
            await self._commit(patient=True)

    async def product_already_posted(self, target: str, signatures: str | list[str] | tuple[str, ...],
                                     price: int | None, discount: int | None) -> tuple[bool, str]:
        """Has THIS channel already carried this product inside the skip window?

        Returns (skip, why). signatures is the headline key plus the exact link
        keys from text_identity_keys: ANY match means the same product, however
        differently the new caption is worded. Inside the 1-hour cool-down the
        repeat is ALWAYS skipped, even a cheaper copy (user rule 2026-10-12:
        the same deal races across sources within minutes, and most of that
        "better" is caption noise). Past the cool-down a MEANINGFULLY better
        copy - a real price drop, or a deeper discount at a lower price - still
        posts; "better on paper" (a token drop, a bigger claimed percent at the
        same or higher price) is the same deal wearing different numbers.
        """
        keys = [signatures] if isinstance(signatures, str) else list(signatures or [])
        keys = self.identity_aliases([key for key in dict.fromkeys(keys) if key])
        if not keys or SAME_PRODUCT_SKIP_SECONDS <= 0:
            return False, ""
        async with self.lock:
            placeholders = ",".join("?" for _ in keys)
            rows = self.conn.execute(
                "SELECT signature, price, discount, posted_at FROM posted_products "
                f"WHERE signature IN ({placeholders}) AND target=? AND posted_at>=? "
                "ORDER BY posted_at DESC",
                (*keys, target, time.time() - SAME_PRODUCT_SKIP_SECONDS),
            ).fetchall()
        if not rows:
            return False, ""
        last_price, last_discount, posted_at = rows[0]["price"], rows[0]["discount"], rows[0]["posted_at"]
        age_seconds = time.time() - (posted_at or 0)
        if age_seconds < SAME_PRODUCT_COOLDOWN_SECONDS:
            age_mins = max(1, int(age_seconds // 60))
            return True, (f"same product posted to this channel {age_mins}m ago "
                          f"(1h cool-down, {len(rows)} key{'s' if len(rows) != 1 else ''} matched)")
        # "Better" has to be MEANINGFULLY better. The discount is re-derived from
        # the post text, and a source that spells out an MRP can read one point
        # higher than the same deal written without it - a 1-point gap is noise,
        # and letting it through is exactly the repeat the user complained about.
        # Same for the price: a token drop (a rupee, a rounding wobble between two
        # captions of one deal) is not a PRICE DROP a reader would care about.
        if price is not None and last_price is None:
            better_price = True  # the earlier post had no price at all: news
        elif price is not None and last_price:
            drop = (last_price - price) / last_price
            better_price = drop >= SAME_PRODUCT_PRICE_DROP_FRACTION
        else:
            better_price = False
        deeper_discount = (discount or 0) >= (last_discount or 0) + SAME_PRODUCT_DISCOUNT_MARGIN
        if deeper_discount and price is not None and last_price is not None:
            # The SAME price with a bigger claimed percent is two sources doing
            # different MRP math on one deal - not news. A bigger percent only
            # counts when the reader also pays less; paying MORE for a bigger
            # claimed percent is worse, never news.
            better_discount = price < last_price
        else:
            better_discount = deeper_discount
        if better_price or better_discount:
            return False, (f"better copy (₹{price or 0} / {discount or 0}% off vs "
                           f"₹{last_price or 0} / {last_discount or 0}% off)")
        age_hours = max(1, int(age_seconds // 3600))
        return True, f"same product posted to this channel {age_hours}h ago"

    async def mark_product_posted(self, target: str, signature: str,
                                  price: int | None, discount: int | None,
                                  extra_signatures: Iterable[str] = (), queue_id: int | None = None) -> None:
        """Remember a posted product under its headline key plus exact link keys.

        extra_signatures carries the exact link identities behind the post's
        URLs (merchant PIDs, same-link hashes from text_identity_keys): the
        same product wearing a different caption still matches one of them, so
        a reworded repeat cannot slip past the headline key. Every key carries
        the same figures, so the better-copy comparison never depends on which
        key happened to match.
        """
        keys = self.identity_aliases([signature] + [key for key in dict.fromkeys(extra_signatures or ()) if key])
        if not signature or SAME_PRODUCT_SKIP_SECONDS <= 0:
            return
        async with self.lock:
            now = time.time()
            for key in keys:
                self.conn.execute(
                    "INSERT OR REPLACE INTO posted_products VALUES(?,?,?,?,?)",
                    (key, target, price, discount, now),
                )
            self.conn.execute(
                "DELETE FROM posted_products WHERE posted_at<?",
                (now - max(SAME_PRODUCT_SKIP_SECONDS, 3 * 24 * 3600),),
            )
            if queue_id is not None:
                self.conn.execute("DELETE FROM target_product_claims WHERE queue_id=? AND target=?",
                                  (queue_id, target))
            await self._commit(patient=True)

    async def text_identity_keys(self, text: str) -> list[str]:
        """Exact product keys behind the URLs a post carries - no guessing.

        A merchant product id read straight off a URL (ASIN, PID, ...) or off
        the cached resolved page behind an affiliate short link, plus the
        same-link hash for URLs with no readable id. Two captions that share
        one of these ARE the same product, however differently they are
        worded - this is what catches the cross-source repeat whose headline
        the word-identity missed. Share/invite/service hosts (t.me, wa.me,
        social, aggregators) are NEVER keys: the family footer link rides on
        every post, and keying it would "match" the whole channel.
        """
        keys: list[str] = []
        seen: set[str] = set()
        urls = list(dict.fromkeys(clean_url(u) for u in URL_RE.findall(text or "")))
        skip_hosts = NON_STORE_DOMAINS | NON_SHOP_DOMAINS | SERVICE_OFFER_DOMAINS | {
            "wa.me", "telegram.me",
        }
        async with self.lock:
            for url in urls:
                host = (urlparse(url).hostname or "").lower()
                if not host or in_domains(host, skip_hosts):
                    continue
                candidates = [url]
                with contextlib.suppress(sqlite3.OperationalError):
                    row = self.conn.execute(
                        "SELECT resolved_url FROM link_cache WHERE affiliate_url=? LIMIT 1",
                        (url,),
                    ).fetchone()
                    if row and row[0]:
                        candidates.append(clean_url(row[0]))
                for candidate in candidates:
                    key = product_key(candidate)
                    if key and key not in seen:
                        seen.add(key)
                        keys.append(key)
        return keys

    async def seen_message(self, chat_id: int, msg_id: int) -> bool:
        """True when this exact source message is already known to the queue."""
        key = str(raw_chat_id(chat_id))
        async with self.lock:
            row = self.conn.execute(
                "SELECT 1 FROM queue WHERE chat_key=? AND msg_id=? LIMIT 1", (key, msg_id)
            ).fetchone()
        return row is not None

    async def is_duplicate_content(self, text: str, queue_id: int | None = None) -> bool:
        """Cheap intake-stage fingerprint check (no HTTP, no rendering).

        Catches the copy-paste reposts that used to burn a whole render cycle
        before the pre-send gate rejected them, and closes the window where the
        same campaign queued from two sources could both reach the send path.
        """
        if not text:
            return False
        try:
            key = content_deal_key(text)
        except Exception:
            return False
        if not key:
            return False
        now = time.time()
        async with self.lock:
            # Already posted inside the product-dedup window -> definite copy.
            posted = self.conn.execute(
                "SELECT 1 FROM posted_deals WHERE deal_key=? AND posted_at>=?",
                (key, now - PRODUCT_DEDUP_SECONDS)
            ).fetchone()
            # Or a live job from another source is already carrying this exact
            # campaign (the same test the pre-send gate does, applied earlier so
            # the duplicate never burns a render cycle). Only fresh claims of
            # still-active jobs count, so a dead claim can never lose a deal.
            claimed = self.conn.execute(
                "SELECT 1 FROM deal_claims c JOIN queue q ON q.id=c.queue_id "
                "WHERE c.deal_key=? AND c.queue_id<>? "
                "AND q.status IN ('pending','processing') AND c.claimed_at>=?",
                (key, queue_id or 0, now - max(1200.0, SOURCE_RESCAN_SECONDS * 2))
            ).fetchone()
        return bool(posted or claimed)

    async def record_safety_block(self, stage: str, verdict: dict, text: str = "",
                                  source: str = "", msg_id: int | None = None,
                                  queue_id: int | None = None, target: str = "") -> None:
        """Remember a refusal so the dashboard can answer "why was this blocked?".

        Bookkeeping only: a failure here must never block a send or a skip.
        """
        if not verdict:
            return
        try:
            matched = str(verdict.get("matched") or "")
            excerpt = " ".join((text or "").split())[:160]
            if matched:
                # Mask the evaded spelling too: the policy matched "sex" in a post
                # that wrote "S.E.X", so a literal replace would leave it readable.
                evaded = r"[\W_]*".join(re.escape(ch) for ch in matched)
                excerpt = re.sub(evaded, "*" * min(len(matched), 8), excerpt, flags=re.I)
            async with self.lock:
                self.conn.execute(
                    "INSERT INTO blocked_content(stage,source,msg_id,queue_id,target,category,"
                    "label,matched,reason,policy_version,excerpt,created_at) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    (stage, source or "", msg_id, queue_id, target or "",
                     str(verdict.get("category") or ""), str(verdict.get("label") or ""),
                     matched[:80], str(verdict.get("reason") or ""),
                     str(verdict.get("version") or ""), excerpt, time.time()),
                )
                await self._commit()
        except Exception as exc:  # noqa: BLE001 - logging must never break posting
            log.warning("SAFETY RECORD skipped: %s", exc)

    async def enqueue(self, chat_id: int, msg_id: int, source: str,
                      text: str = "", has_media: bool = False) -> bool:
        # HARD GATE, first thing: a post that cannot be published on a public
        # channel never enters the queue, so it can never burn a render cycle,
        # never reach a channel and never be retried. The reason is recorded
        # and logged - a refusal is never silent.
        if text:
            try:
                verdict = safety_scan(text)
            except Exception as exc:  # noqa: BLE001 - never crash intake
                log.warning("SAFETY CHECK unavailable for %s msg=%s: %s "
                            "(posting continues, filter is OFF until fixed)",
                            source, msg_id, exc)
                verdict = None
            if verdict and verdict.get("blocked"):
                log.warning("INTAKE SAFETY BLOCK | source=%s msg=%s category=%s "
                            "matched=%r why=%s", source, msg_id, verdict["category"],
                            verdict.get("matched", "")[:40], verdict.get("reason", "")[:120])
                await self.record_safety_block("intake", verdict, text, source, msg_id)
                return False
        # Best-lists first, then super discounts, then photos - so the highest
        # value Telegram post is rendered/delivered ahead of ordinary ones.
        priority = classify_priority(text, has_media)
        # User rule: first-preference sources (pricehistory, the three channels
        # added 2026-09-24, ...) post ahead of the same content tier from other
        # sources on every non-Tricks channel. Matched through
        # is_priority_source() so an invite-link source is recognised whatever
        # case the queue stored it in.
        if is_priority_source(source):
            priority = min(priority + 1, 5)
        # Layer 1 of the zero-duplicate guarantee: a campaign whose fingerprint
        # was already posted (or is already waiting in the queue) is never even
        # inserted, so it can never reach the send path twice.
        if text and await self.is_duplicate_content(text):
            log.info("INTAKE DEDUP | source=%s msg=%s (already posted or queued)", source, msg_id)
            return False
        # v17.6: same product, better copy -> the pending row is re-pointed at the
        # stronger deal instead of a coin flip deciding what our channels post. An
        # error here must never cost coverage, so it degrades to plain insert.
        if text:
            try:
                swapped = await self.swap_in_better_copy(chat_id, msg_id, source, text, priority)
            except Exception as exc:  # noqa: BLE001 - enhancement, never a blocker
                log.warning("BEST COPY check skipped: %s", exc)
                swapped = False
            if swapped:
                return False
        async with self.lock:
            cur = self.conn.execute(
                "INSERT OR IGNORE INTO queue(chat_id,msg_id,source,created_at,priority,chat_key,"
                "quality,product_keys,source_text) VALUES(?,?,?,?,?,?,?,?,?)",
                (chat_id, msg_id, source, time.time(), priority, str(raw_chat_id(chat_id)),
                 deal_quality_score(text) if text else 0,
                 json.dumps(sorted(product_identities(text))) if text else None,
                 (text or "")[:8000] or None),
            )
            await self._commit()
        inserted = cur.rowcount > 0
        if inserted:
            # Wake the idle workers immediately: a deal must never wait for the
            # next idle poll cycle (that polling gap was a visible posting lag).
            notify_queue()
        return inserted

    async def swap_in_better_copy(self, chat_id: int, msg_id: int, source: str,
                                  text: str, priority: int) -> bool:
        """Re-point a still-undelivered queue row at a better copy of the same product.

        Deliberately narrow, because losing a post is worse than posting the
        weaker copy: only a SINGLE-product post (one link, one price), never a
        Tricks/card/service post, and only when an exact merchant product id
        matches a row that has not been claimed yet. One row in, one row out -
        the duplicate guarantee is untouched - and the displaced copy is
        remembered so `restore_superseded` can queue it if the better one fails.
        """
        keys = product_identities(text)
        if not keys or source in TRICKS_SOURCES or has_card_offer(text):
            return False
        # A single product, by the only signals intake can see without rendering:
        # at most one link, and no list markers (these sources put one link per
        # item, so a roundup with several products is never re-pointed).
        links = list(dict.fromkeys(clean_url(u) for u in URL_RE.findall(text or "")))
        if len(links) > 1:
            return False
        if re.search(r"(?im)^\s*(?:deal\s*\d+|\d+\s*[.)])|(?:MEGA DEAL LIST|DEAL LIST)", text or ""):
            return False
        score = deal_quality_score(text)
        wanted = comparable_product_ids(keys)
        async with self.lock:
            rows = self.conn.execute(
                "SELECT id, chat_key, chat_id, msg_id, source, priority, quality, "
                "product_keys, deal_keys_json FROM queue WHERE status='pending'"
            ).fetchall()
            for row in rows:
                if (row["source"] or "") in TRICKS_SOURCES:
                    continue
                pending_keys = json.loads(row["product_keys"] or "[]")
                if len(pending_keys) > 1:
                    # A list post stands for several products; re-pointing it at one
                    # product would delete the rest of the roundup.
                    continue
                pending_ids = comparable_product_ids(pending_keys)
                if not pending_ids:
                    try:
                        pending_ids |= comparable_product_ids(json.loads(row["deal_keys_json"] or "[]"))
                    except (TypeError, ValueError):
                        pass
                if not (wanted & pending_ids):
                    continue
                if row["quality"] is None:
                    # A row created before this feature (or without text) has no
                    # score to compare against: leave it alone rather than risk a
                    # downgrade.
                    continue
                if score <= (row["quality"] or 0):
                    # The queued copy is at least as good: nothing to gain, and the
                    # render-time product ledger already blocks a duplicate post.
                    return True
                self.conn.execute(
                    "UPDATE queue SET chat_id=?, msg_id=?, source=?, quality=?, product_keys=?, source_text=?, "
                    "priority=?, rendered_text=NULL, targets_json=NULL, deal_keys_json=NULL, "
                    "attempts=0, next_at=0, superseded_chat_id=?, superseded_msg_id=? WHERE id=?",
                    (chat_id, msg_id, source, score, json.dumps(sorted(keys)),
                     (text or "")[:8000] or None,
                     max(int(priority), int(row["priority"] or 1)),
                     str(row["chat_id"]), row["msg_id"], row["id"]),
                )
                await self._commit()
                log.info("BEST COPY | queue=%s re-pointed at %s msg=%s for %s (score %s beats %s)",
                         row["id"], source, msg_id, ",".join(sorted(wanted)),
                         score, row["quality"] or 0)
                notify_queue()
                return True
        return False

    async def restore_superseded(self, row: sqlite3.Row) -> bool:
        """Queue the copy a "best copy" swap displaced, so a failing better post
        can never turn into a missing deal."""
        keys = row.keys()
        old_chat = row["superseded_chat_id"] if "superseded_chat_id" in keys else None
        old_msg = row["superseded_msg_id"] if "superseded_msg_id" in keys else None
        if not old_chat or not old_msg:
            return False
        async with self.lock:
            self.conn.execute(
                "UPDATE queue SET superseded_chat_id=NULL, superseded_msg_id=NULL WHERE id=?",
                (row["id"],),
            )
            cur = self.conn.execute(
                "INSERT OR IGNORE INTO queue(chat_id,msg_id,source,created_at,priority,chat_key,quality) "
                "VALUES(?,?,?,?,?,?,?)",
                (int(old_chat), int(old_msg), row["source"], time.time(), 3,
                 str(raw_chat_id(int(old_chat))), 0),
            )
            await self._commit()
        if cur.rowcount:
            log.info("BEST COPY ROLLBACK | queue=%s restored the original copy (msg=%s)",
                     row["id"], old_msg)
            notify_queue()
            return True
        return False

    async def claim_job(self) -> sqlite3.Row | None:
        async with self.lock:
            now = time.time()
            self.conn.execute("BEGIN IMMEDIATE")
            order = "DESC" if QUEUE_ORDER == "newest" else "ASC"
            # USER RULE (2026-09-07): "t.me/DealsUnder99_com first preference -
            # first diniki next inka vereveru top vi, then list of products".
            # Claim order: posts from the preferred source first, then every
            # other single/top deal by priority, then product LISTS last
            # (priority 5 is classify_priority's list mark). The newest/oldest
            # QUEUE_ORDER knob still decides inside a tier.
            preferred = sorted(PREFERRED_SOURCES)
            if preferred:
                placeholders = ",".join("?" for _ in preferred)
                tier_sql = (f"(CASE WHEN lower(source) IN ({placeholders}) THEN 0 ELSE 1 END) ASC, "
                            "(CASE WHEN priority >= 5 THEN 1 ELSE 0 END) ASC, ")
                # Placeholder order follows the SQL text: the next_at<=? bound
                # comes first, then the IN (...) list values.
                params: tuple = (now, *preferred)
            else:
                tier_sql = "(CASE WHEN priority >= 5 THEN 1 ELSE 0 END) ASC, "
                params = (now,)
            row = self.conn.execute(
                "SELECT * FROM queue WHERE status='pending' AND next_at<=? "
                f"ORDER BY {tier_sql}priority DESC, created_at {order} LIMIT 1",
                params,
            ).fetchone()
            if row:
                # next_at doubles as the claim timestamp while processing, so a
                # job orphaned mid-flight (kill -9, OOM) can be reclaimed later.
                self.conn.execute("UPDATE queue SET status='processing', next_at=? WHERE id=?", (now, row["id"]))
            await self._commit()
            return row

    async def reclaim_stuck_jobs(self, max_age_seconds: float = 1800) -> int:
        """Return orphaned 'processing' rows to 'pending'.

        Startup already resets processing rows, but a job abandoned while the
        process stays up (task killed mid-await, watchdog timeout) would
        otherwise stay 'processing' forever and its deal would never post.
        """
        async with self.lock:
            cur = self.conn.execute(
                "UPDATE queue SET status='pending', next_at=0 WHERE status='processing' AND next_at<?",
                (time.time() - max_age_seconds,),
            )
            await self._commit()
            if cur.rowcount:
                notify_queue()
            return cur.rowcount

    async def drop_stale_jobs(self, max_age_hours: float | None = None) -> int:
        """Drop pending work older than the freshness budget (never post it late).

        A loot price that is six hours old is already dead: posting it late both
        looks wrong and costs subscribers. Newest-first claiming needs this
        sweeper so stale inventory cannot occupy the queue indefinitely.
        """
        hours = MAX_JOB_AGE_HOURS if max_age_hours is None else float(max_age_hours)
        if hours <= 0:
            return 0
        cutoff = time.time() - hours * 3600
        async with self.lock:
            rows = self.conn.execute(
                "SELECT id, source, msg_id FROM queue WHERE status='pending' AND created_at<?",
                (cutoff,),
            ).fetchall()
            for row in rows:
                self.conn.execute(
                    "UPDATE queue SET status='done', last_error=? WHERE id=?",
                    (f"stale job dropped (older than {hours:g}h)", row["id"]),
                )
                self.conn.execute("DELETE FROM deal_claims WHERE queue_id=?", (row["id"],))
            await self._commit()
        if rows:
            log.info("STALE DROP | %s pending job(s) older than %sh skipped instead of posted late",
                     len(rows), hours)
        return len(rows)

    async def remember_products(self, queue_id: int, keys: list[str]) -> None:
        """Persist the product ids a queue row stands for (see swap_in_better_copy)."""
        if not keys:
            return
        async with self.lock:
            self.conn.execute("UPDATE queue SET product_keys=? WHERE id=?",
                              (json.dumps(list(keys)[:12]), queue_id))
            await self._commit()

    async def save_render(self, queue_id: int, text: str, targets: list[str], keys: list[str],
                          premium_rank: int | None = None) -> None:
        async with self.lock:
            self.conn.execute(
                "UPDATE queue SET rendered_text=?,targets_json=?,deal_keys_json=?,premium_score=? WHERE id=?",
                (text, json.dumps(targets), json.dumps(keys), premium_rank, queue_id),
            )
            for target in targets:
                self.conn.execute(
                    "INSERT OR IGNORE INTO deliveries(queue_id,target) VALUES(?,?)", (queue_id, target)
                )
            await self._commit()

    async def cached_link(self, source_url: str) -> sqlite3.Row | None:
        async with self.lock:
            return self.conn.execute(
                "SELECT * FROM link_cache WHERE source_url=?", (canonical_url(source_url),)
            ).fetchone()

    async def remember_hypd_link(self, afflink_url: str, resolved_url: str,
                                 product_key_value: str) -> bool:
        """Record an OUR HYPD link only when its verified destination is Meesho."""
        token = hypd_afflink_token(afflink_url)
        host = (urlparse(clean_url(resolved_url)).hostname or "").lower()
        if (not token or not is_our_hypd_link(afflink_url)
                or not in_domains(host, HYPD_MERCHANT_DOMAINS)):
            return False
        if not mapping_valid(afflink_url, resolved_url, hypd_store_of(afflink_url),
                             product_key_value, OUR_HYPD_STORES):
            return False
        # Store only a single identified Meesho product, not a storefront/search.
        page = clean_url(merchant_url(resolved_url))
        async with self.lock:
            self.conn.execute(
                "INSERT OR REPLACE INTO hypd_links(token, store, afflink_url, resolved_url,"
                " product_key, created_at) VALUES (?,?,?,?,?,?)",
                (token, hypd_store_of(afflink_url), clean_url(afflink_url),
                 page, product_key_value or "", time.time()),
            )
            await self._commit()
        # This product is no longer "missing our link".
        with contextlib.suppress(Exception):
            await self.forget_hypd_wanted(page, product_key_value or "", afflink_url)
        return True

    async def forget_hypd_link(self, afflink_url: str) -> int:
        """Remove a previously learned HYPD link outside the Meesho-only scope."""
        token = hypd_afflink_token(afflink_url)
        if not token:
            return 0
        async with self.lock:
            cur = self.conn.execute("DELETE FROM hypd_links WHERE token=?", (token,))
            await self._commit()
            return max(cur.rowcount or 0, 0)

    async def hypd_link_for(self, *keys: str,
                            include_outside_meesho: bool = False) -> str | None:
        """Find a learned HYPD link; normally return Meesho mappings only.

        `include_outside_meesho` is reserved for cache migration so an old
        Shopsy mapping can be identified and invalidated, never published.
        """
        wanted: list[str] = []
        for key in keys:
            for variant in hypd_product_keys(key):
                if variant not in wanted:
                    wanted.append(variant)
            if key and key not in wanted:
                wanted.append(key)          # an identity key such as "PID:..."
        if not wanted:
            return None
        async with self.lock:
            for key in wanted:
                rows = self.conn.execute(
                    "SELECT afflink_url, resolved_url, store, product_key FROM hypd_links WHERE product_key=? "
                    "OR resolved_url=? OR afflink_url=? ORDER BY created_at DESC",
                    (key, key, key)).fetchall()
                for row in rows:
                    if not row["afflink_url"]:
                        continue
                    host = (urlparse(clean_url(row["resolved_url"] or "")).hostname or "").lower()
                    if include_outside_meesho and not in_domains(host, HYPD_MERCHANT_DOMAINS):
                        return row["afflink_url"]  # invalidation only; never delivery
                    if mapping_valid(row["afflink_url"], row["resolved_url"], row["store"],
                                     row["product_key"], OUR_HYPD_STORES):
                        return row["afflink_url"]
        return None

    async def hypd_product_for(self, afflink: str) -> str:
        """Previously verified product for an exact share, including curated-only rows."""
        async with self.lock:
            if not self._hypd_mapping_is_valid(afflink):
                return ""
            row = self.conn.execute("SELECT resolved_url FROM hypd_links WHERE token=?",
                                    (hypd_afflink_token(afflink),)).fetchone()
            return str(row["resolved_url"] or "") if row else ""

    async def remember_hypd_wanted(self, product_url: str, product_key_value: str) -> bool:
        """A Meesho product we have NO HYPD link for: commission leaking."""
        url = clean_url(product_url)
        host = (urlparse(url).hostname or "").lower()
        if not url or not in_domains(host, HYPD_MERCHANT_DOMAINS) or not meesho_product_id(url):
            return False
        now = time.time()
        async with self.lock:
            existing = self.conn.execute(
                "SELECT times FROM hypd_wanted WHERE product_url=?", (url,)).fetchone()
            self.conn.execute(
                "INSERT INTO hypd_wanted(product_url, product_key, times, first_seen, last_seen)"
                " VALUES (?,?,1,?,?) ON CONFLICT(product_url) DO UPDATE SET"
                " times=times+1, last_seen=excluded.last_seen,"
                " product_key=COALESCE(excluded.product_key, product_key)",
                (url, product_key_value or "", now, now),
            )
            await self._commit()
        return existing is None

    def recent_hypd_wanted(self, limit: int = 200) -> list[dict[str, Any]]:
        """Meesho products still missing OUR HYPD link, most-wanted first."""
        rows = self.conn.execute(
            "SELECT product_url, product_key, times, last_seen FROM hypd_wanted"
            " ORDER BY times DESC, last_seen DESC").fetchall()
        out = []
        for row in rows:
            host = (urlparse(clean_url(row["product_url"] or "")).hostname or "").lower()
            if in_domains(host, HYPD_MERCHANT_DOMAINS):
                out.append(dict(row))
                if len(out) >= max(1, int(limit)):
                    break
        return out

    async def forget_hypd_wanted(self, *keys: str) -> int:
        """Drop a product from the to-do list once OUR HYPD link is learned."""
        wanted = [k for k in keys if k]
        if not wanted:
            return 0
        async with self.lock:
            removed = 0
            for key in wanted:
                for variant in (key, canonical_url(key)):
                    cursor = self.conn.execute(
                        "DELETE FROM hypd_wanted WHERE product_url=? OR product_key=?",
                        (variant, key))
                    removed += max(cursor.rowcount or 0, 0)
            await self._commit()
        return removed

    def recent_hypd_links(self, limit: int = 500) -> list[tuple[str, str]]:
        """Meesho-only (afflink_url, resolved_url) pairs — used by ops/hypd_links.py."""
        rows = self.conn.execute(
            "SELECT afflink_url, resolved_url, store, product_key FROM hypd_links ORDER BY created_at DESC").fetchall()
        out = []
        for row in rows:
            if mapping_valid(row["afflink_url"], row["resolved_url"], row["store"],
                             row["product_key"], OUR_HYPD_STORES):
                out.append((row["afflink_url"], row["resolved_url"] or ""))
                if len(out) >= max(1, int(limit)):
                    break
        return out

    def recent_shortened_amazon_links(self, limit: int = 2000) -> list[tuple[str, str]]:
        """Durable (short link -> amazon URL) pairs for the restart gap.

        AffiliateClient seeds its in-memory short->long map from this at startup
        so a bit.ly/is.gd hop we minted can always be seen behind - by the
        review channel's native-link expansion AND by
        strip_amazon_tag_for_undeclared(). Only the RUNTIME shorteners matter
        here: an ekaro.in/fktr.in link names its network in the domain itself,
        while bit.ly/is.gd can hide a tagged amazon.in URL behind the hop.
        Newest first; a synchronous read because it runs in __init__.
        """
        try:
            rows = self.conn.execute(
                "SELECT affiliate_url, resolved_url FROM link_cache "
                "WHERE created_at>=? ORDER BY created_at DESC LIMIT ?",
                (time.time() - 14 * 24 * 3600, int(limit)),
            ).fetchall()
        except Exception:
            return []
        pairs: list[tuple[str, str]] = []
        for row in rows:
            short, resolved = (row[0] or "").strip(), (row[1] or "").strip()
            if not short or not resolved:
                continue
            short_host = (urlparse(short).hostname or "").lower()
            if short_host not in OUR_RUNTIME_SHORTENER_DOMAINS:
                continue
            resolved_host = (urlparse(resolved).hostname or "").lower()
            if not in_domains(resolved_host, AMAZON_DOMAINS):
                continue
            pairs.append((short, resolved))
        return pairs

    async def affiliate_destination(self, short_url: str) -> str | None:
        """Look up the destination behind one of our generated links.

        Exact lookup matters for direct Flipkart affiliate URLs: canonical_url()
        intentionally drops affExtParam2 for product identity, but that parameter
        is the publisher attribution and the stored URL must be matched intact.
        """
        try:
            raw = clean_url(short_url)
            canonical = canonical_url(raw)
            async with self.lock:
                row = self.conn.execute(
                    "SELECT resolved_url FROM link_cache WHERE affiliate_url=? "
                    "ORDER BY created_at DESC LIMIT 1", (raw,),
                ).fetchone()
                if row is None and canonical != raw:
                    row = self.conn.execute(
                        "SELECT resolved_url FROM link_cache WHERE affiliate_url=? "
                        "ORDER BY created_at DESC LIMIT 1", (canonical,),
                    ).fetchone()
            resolved = (row["resolved_url"] if row else "") or ""
            return resolved or None
        except Exception:
            return None

    async def cache_link(self, source_url: str, affiliate: str, resolved: str, key: str) -> None:
        async with self.lock:
            self.conn.execute(
                "INSERT OR REPLACE INTO link_cache VALUES(?,?,?,?,?)",
                (canonical_url(source_url), affiliate, resolved, key, time.time()),
            )
            await self._commit()

    async def remember_owned_link_proof(self, affiliate_url: str, destination_url: str,
                                        proof_type: str) -> None:
        """Persist provenance for a generated link, including its hidden network hop."""
        affiliate = clean_url(affiliate_url)
        destination = clean_url(destination_url)
        if (not affiliate or not destination
                or proof_type not in {"earnkaro_api", "amazon_native", "hypd"}):
            return
        async with self.lock:
            if proof_type == "hypd" and not self._hypd_mapping_is_valid(destination):
                return
            publisher_id = (hypd_store_of(destination) if proof_type == "hypd"
                            else OUR_EK_ID if proof_type == "earnkaro_api" else "")
            self.conn.execute(
                "INSERT OR REPLACE INTO owned_link_proofs "
                "(affiliate_url,destination_url,proof_type,publisher_id,created_at) "
                "VALUES(?,?,?,?,?)",
                (affiliate, destination, proof_type, publisher_id, time.time()),
            )
            await self._commit()

    @staticmethod
    def is_our_amazon_tag_link(url: str) -> bool:
        """An Amazon URL carrying OUR Associates tag is self-proving.

        The tag can only have been added by us (direct-Associates conversion or
        a direct tag write), so the link monetises to this account regardless
        of how it reached the rendered text. link_cache only stores conversion-
        API output, so our own direct Amazon links may legitimately be absent —
        right after deploy (cache invalidated), after an old-row prune, or
        whenever a post renders a tagged link produced outside the convert()
        path. The tag check (exactly as strict as valid_generated) is therefore
        sufficient provenance; a DB lookup here would only raise false
        "final provenance recheck failed" drops of good deals.
        """
        try:
            parsed = urlparse(url)
            host = (parsed.hostname or "").lower()
            if not OUR_TAG or not in_domains(host, AMAZON_DOMAINS):
                return False
            query = {str(k).lower(): v for k, v in parse_qs(parsed.query).items()}
            tags = query.get("tag", [])
            return bool(tags) and all(str(tag).strip() == OUR_TAG for tag in tags)
        except Exception:
            return False

    @staticmethod
    def has_native_owned_attribution(url: str) -> bool:
        """Proof carried by the native merchant URL itself, not by its hostname."""
        if Store.is_our_amazon_tag_link(url):
            return True
        try:
            parsed = urlparse(clean_url(url))
            host = (parsed.hostname or "").lower()
            if not in_domains(host, EK_ATTRIBUTION_HOSTS) or not OUR_EK_ID:
                return False
            ids = [value for key, values in parse_qs(parsed.query).items()
                   if key.lower() == "affextparam2" for value in values]
            if not (ids and all(str(value).strip() == OUR_EK_ID for value in ids)):
                return False
            # Our number alone is not a conversion (USER RULE 2026-10-19).
            return not conversion_signature_missing(url)
        except Exception:
            return False

    def _hypd_mapping_is_valid(self, afflink: str, expected: str = "") -> bool:
        token = hypd_afflink_token(afflink)
        if not token or not is_our_hypd_link(afflink):
            return False
        row = self.conn.execute(
            "SELECT afflink_url,resolved_url,store,product_key FROM hypd_links WHERE token=?", (token,)
        ).fetchone()
        if not row or hypd_afflink_token(row["afflink_url"]) != token or not mapping_valid(
                row["afflink_url"], row["resolved_url"], row["store"], row["product_key"], OUR_HYPD_STORES):
            return False
        if not expected or hypd_afflink_token(expected) == token:
            return True
        return bool(meesho_product_id(expected) and
                    meesho_product_id(expected) == meesho_product_id(row["resolved_url"]))

    def _strict_cache_pair_is_owned(self, affiliate_url: str, resolved_url: str) -> bool:
        """Reject legacy clean-link rows; accept only verified network/native links."""
        affiliate_url = clean_url(affiliate_url)
        resolved_url = clean_url(resolved_url)
        exact_proof = self.conn.execute(
            "SELECT destination_url,publisher_id FROM owned_link_proofs "
            "WHERE affiliate_url=? AND proof_type='hypd'", (affiliate_url,)).fetchone()
        hypd_context = bool(exact_proof) or any(in_domains((urlparse(url).hostname or "").lower(),
                                     HYPD_DOMAINS | HYPD_MERCHANT_DOMAINS)
                           for url in (affiliate_url, resolved_url))
        if hypd_context:
            if is_our_hypd_link(affiliate_url):
                return self._hypd_mapping_is_valid(affiliate_url, resolved_url)
            return bool(exact_proof
                        and exact_proof["publisher_id"] == hypd_store_of(exact_proof["destination_url"])
                        and self._hypd_mapping_is_valid(exact_proof["destination_url"], resolved_url))
        if self.has_native_owned_attribution(affiliate_url):
            return True
        if self.has_native_owned_attribution(resolved_url):
            return True
        proof = self.conn.execute(
            "SELECT destination_url,proof_type,publisher_id FROM owned_link_proofs "
            "WHERE affiliate_url IN (?,?) ORDER BY created_at DESC LIMIT 1",
            (affiliate_url, resolved_url),
        ).fetchone()
        proof_type = str(proof["proof_type"] or "") if proof else ""
        if proof_type == "amazon_native":
            # A shortened Amazon browse/search URL is only ours while the exact
            # destination still carries the currently configured Associates tag.
            return self.is_our_amazon_tag_link(str(proof["destination_url"] or ""))
        if proof_type == "earnkaro_api":
            # Network short domains are account-specific but may not expose the
            # paid publisher in the URL. Bind the durable proof to the publisher
            # from the authenticated token; stale proofs from another account (or
            # legacy rows without an identity) fail closed.
            proof_publisher = str(proof["publisher_id"] or "") if proof else ""
            return bool(OUR_EK_ID and proof_publisher == OUR_EK_ID)
        if proof_type == "hypd":
            share = str(proof["destination_url"] or "")
            return (str(proof["publisher_id"] or "") == hypd_store_of(share)
                    and self._hypd_mapping_is_valid(share, resolved_url))
        if is_our_hypd_link(affiliate_url):
            return self._hypd_mapping_is_valid(affiliate_url, resolved_url)
        # A generic shortener cache row or a mapping for a similar product is
        # not proof that THIS short URL was minted from our HYPD share link.

        return False

    def _strict_url_is_owned(self, url: str) -> bool:
        """Every recorded pairing must pass, not whichever row SQLite returns first."""
        rows = self.conn.execute(
            "SELECT affiliate_url,resolved_url FROM link_cache WHERE affiliate_url=?", (url,)
        ).fetchall()
        return (all(self._strict_cache_pair_is_owned(row["affiliate_url"], row["resolved_url"] or "")
                    for row in rows) if rows else self._strict_cache_pair_is_owned(url, ""))

    async def cached_link_is_owned(self, affiliate_url: str, resolved_url: str) -> bool:
        """Check cached link provenance under the same lock as the final gate."""
        async with self.lock:
            return self._strict_cache_pair_is_owned(affiliate_url, resolved_url)

    async def verify_generated_text(self, text: str,
                                    allowed_external: Iterable[str] = ()) -> bool:
        """Recheck every URL; strict mode accepts only native or verified affiliate proof."""
        urls = list(dict.fromkeys(clean_url(x) for x in URL_RE.findall(text or "")))
        if not urls:
            return False
        if STRICT_OUR_LINKS:
            # Service offers and family-channel promo links are not monetized.
            if any(in_domains((urlparse(url).hostname or "").lower(), SERVICE_OFFER_DOMAINS)
                   or url in {OUR_FOLDER_LINK, *OUR_MAIN_CHANNEL_LINKS}
                   for url in urls):
                return False
            async with self.lock:
                for url in urls:
                    if self.has_native_owned_attribution(url):
                        continue
                    if not self._strict_url_is_owned(url):
                        return False
            return True

        allowed = {clean_url(x) for x in allowed_external}
        check_urls = [url for url in urls if url not in allowed]
        # Legacy-only behavior: service links are ignored and an exact promo
        # allowlist is honored only when strict-all is explicitly disabled.
        check_urls = [url for url in check_urls
                      if not in_domains((urlparse(url).hostname or "").lower(), SERVICE_OFFER_DOMAINS)
                      and not self.is_our_amazon_tag_link(url)]
        if any(in_domains((urlparse(url).hostname or "").lower(), FOREIGN_ECHO_DOMAINS)
               and not in_domains((urlparse(url).hostname or "").lower(), OUR_RUNTIME_SHORTENER_DOMAINS)
               for url in check_urls):
            return False
        async with self.lock:
            for url in check_urls:
                host = (urlparse(url).hostname or "").lower()
                if in_domains(host, TOKENLESS_SHORTENER_DOMAINS) and not self._strict_url_is_owned(url):
                    return False
                found = self.conn.execute(
                    "SELECT 1 FROM link_cache WHERE affiliate_url=? LIMIT 1", (url,)
                ).fetchone()
                if not found:
                    return False
        return True

    async def presend_links_verified(self, text: str) -> tuple[bool, str]:
        """Last line of defense before a strict post goes out: every URL in the
        FINAL per-target text must be ours (native owned attribution or a
        verified converter/shortener proof) or one of our own family links.
        Returns (True, "") or (False, offending_url). This mirrors the strict
        branch of verify_generated_text exactly - same queries, same proof
        helper - but runs on the text as it will be sent, after the per-target
        rewrites (programme-safe copy, retag, disclosure). A source short
        link, a foreign tag, or a clean merchant page that somehow survived
        rendering is stopped here instead of posted: their links never reach a
        channel and no commission is silently missed (user rule 2026-10-12).
        """
        urls = list(dict.fromkeys(clean_url(x) for x in URL_RE.findall(text or "")))
        if not urls:
            return True, ""
        family = {clean_url(OUR_FOLDER_LINK),
                  *(clean_url(x) for x in OUR_MAIN_CHANNEL_LINKS)}
        async with self.lock:
            for url in urls:
                if url in family:
                    continue
                host = (urlparse(url).hostname or "").lower()
                # A tokenless hop is refused in EVERY mode, strict or legacy: the
                # URL proves nothing about who minted it, so "it is probably ours"
                # is exactly the assumption that put two is.gd links pointing at
                # untagged Amazon pages into a channel (user report 2026-10-21).
                if in_domains(host, TOKENLESS_SHORTENER_DOMAINS) and not self._strict_url_is_owned(url):
                    return False, url
                if self.has_native_owned_attribution(url):
                    continue
                owned = self._strict_url_is_owned(url)
                if not owned:
                    return False, url
        return True, ""

    async def preview_allowed(self, text: str) -> bool:
        """Keep Amazon product previews; suppress Flipkart/Myntra generic cards and wasteful list previews (user rule 2026-09-04)."""
        urls = list(dict.fromkeys(clean_url(x) for x in URL_RE.findall(text or "")))
        # Wasteful list preview: 2+ links in one message already makes it tall — extra card is waste (Myntra extend waste)
        if len(urls) >= 2:
            return False
        async with self.lock:
            for url in urls:
                row = self.conn.execute(
                    "SELECT resolved_url FROM link_cache WHERE affiliate_url=? LIMIT 1", (url,)
                ).fetchone()
                resolved = row[0] if row and row[0] else url
                host = (urlparse(resolved).hostname or "").lower()
                # linkredirect.in is source wrapper never final, Myntra/myntr.it generic shop card is waste — photo okay but extend waste
                if host_matches(host, "flipkart.com") or host_matches(host, "linkredirect.in") or host_matches(host, "myntra.com") or host_matches(host, "myntr.it"):
                    return False
                # USER REPORT (2026-09-06): "shopsy ani kuda exted avuthundi
                # alaga avoddu". A bitli.in link that is not in the cache yet
                # resolved to nothing here, so the host read "bitli.in", passed
                # every test above, and Telegram unfurled whatever the redirect
                # landed on - the generic "Shopsy Store / A trusted network..."
                # card under a pen-stand deal. An affiliate shortener hides its
                # destination BY DESIGN, so it can never be judged safe: no
                # preview unless we can see where it actually goes.
                if resolved == url and in_domains(host, OUR_SHORTENER_DOMAINS | SHORTENER_HOSTS):
                    return False
        return True

    async def reserve(self, queue_id: int, keys: list[str], price: int | None,
                      has_identity: bool, content_key: str | None = None) -> tuple[bool, list[str]]:
        """Atomically reserve new products plus an optional strict content fingerprint."""
        async with self.lock:
            now = time.time()
            cutoff = now - PRODUCT_DEDUP_SECONDS
            claim_cutoff = now - 20 * 60
            self.conn.execute("BEGIN IMMEDIATE")
            self.conn.execute("DELETE FROM posted_deals WHERE posted_at<?", (cutoff,))
            # Expire only claims whose owning job is FINISHED. Purging a claim a
            # live job still holds is how the same product got posted twice from
            # another source: a big backlog or a Premium window can legitimately
            # keep a job pending for far longer than 20 minutes.
            self.conn.execute(
                "DELETE FROM deal_claims WHERE claimed_at<? AND queue_id NOT IN "
                "(SELECT id FROM queue WHERE status IN ('pending','processing'))",
                (claim_cutoff,),
            )
            if content_key:
                content_posted = self.conn.execute(
                    "SELECT 1 FROM posted_deals WHERE deal_key=? AND posted_at>=?", (content_key, cutoff)
                ).fetchone()
                content_claimed = self.conn.execute(
                    "SELECT 1 FROM deal_claims WHERE deal_key=? AND queue_id<>?", (content_key, queue_id)
                ).fetchone()
                if content_posted or content_claimed:
                    self.conn.rollback()
                    return False, []
                self.conn.execute(
                    "INSERT OR REPLACE INTO deal_claims VALUES(?,?,?)", (content_key, queue_id, now)
                )
            new_keys = []
            for key in dict.fromkeys(keys):
                posted = self.conn.execute(
                    "SELECT 1 FROM posted_deals WHERE deal_key=? AND posted_at>=?", (key, cutoff)
                ).fetchone()
                claim = self.conn.execute(
                    "SELECT 1 FROM deal_claims WHERE deal_key=? AND queue_id<>?", (key, queue_id)
                ).fetchone()
                if not posted and not claim:
                    self.conn.execute(
                        "INSERT OR REPLACE INTO deal_claims VALUES(?,?,?)", (key, queue_id, now)
                    )
                    new_keys.append(key)
            # Price gate: the exact same detected price must not be posted again
            # from any source inside the window. By default this only applies when
            # the post has NO product identity (the documented fallback); a real
            # ASIN/PID match is already covered by the key check above, and two
            # different ₹99 products are not duplicates of each other.
            # PRICE_DEDUP_IGNORES_IDENTITY=true restores the strict behaviour.
            if (price is not None and PRICE_DEDUP_SECONDS > 0
                    and (PRICE_DEDUP_IGNORES_IDENTITY or not has_identity)):
                pp = self.conn.execute(
                    "SELECT 1 FROM price_posts WHERE price=? AND posted_at>=?",
                    (price, now - PRICE_DEDUP_SECONDS),
                ).fetchone()
                if pp:
                    self.conn.rollback()
                    return False, []
            if not new_keys:
                # A post with NO identifiable product at all (every link in it was a
                # dead shortener, cut above) has no keys to reserve, and calling that a
                # "duplicate deal" of nothing is how a real post went missing. The
                # content fingerprint above is the honest check for it: same text twice
                # is still refused, this text once is a first.
                if not keys and content_key:
                    await self._commit()
                    return True, []
                self.conn.rollback()
                return False, []
            await self._commit()
            return True, new_keys

    async def claim_content_key(self, queue_id: int, content_key: str | None) -> bool:
        """Backfill strict content dedup for jobs rendered by older deployments."""
        if not content_key:
            return True
        async with self.lock:
            now = time.time()
            cutoff = now - PRODUCT_DEDUP_SECONDS
            self.conn.execute("BEGIN IMMEDIATE")
            posted = self.conn.execute(
                "SELECT queue_id FROM posted_deals WHERE deal_key=? AND posted_at>=?",
                (content_key, cutoff),
            ).fetchone()
            if posted and int(posted[0]) != queue_id:
                self.conn.rollback()
                return False
            claimed = self.conn.execute(
                "SELECT queue_id FROM deal_claims WHERE deal_key=?", (content_key,)
            ).fetchone()
            if claimed and int(claimed[0]) != queue_id:
                self.conn.rollback()
                return False
            self.conn.execute(
                "INSERT OR REPLACE INTO deal_claims VALUES(?,?,?)", (content_key, queue_id, now)
            )
            row = self.conn.execute(
                "SELECT deal_keys_json FROM queue WHERE id=?", (queue_id,)
            ).fetchone()
            keys = json.loads((row[0] if row else None) or "[]")
            if content_key not in keys:
                keys.append(content_key)
                self.conn.execute(
                    "UPDATE queue SET deal_keys_json=? WHERE id=?", (json.dumps(keys), queue_id)
                )
            await self._commit()
            return True

    async def has_pending_work(self) -> bool:
        """True when a claimable job exists (checked after clearing the wake)."""
        async with self.lock:
            row = self.conn.execute(
                "SELECT 1 FROM queue WHERE status='pending' AND next_at<=? LIMIT 1",
                (time.time(),),
            ).fetchone()
        return row is not None

    async def has_partial_delivery(self, queue_id: int) -> bool:
        """True when at least one chunk of this job already reached a target."""
        async with self.lock:
            row = self.conn.execute(
                "SELECT 1 FROM deliveries WHERE queue_id=? AND chunks_sent>0 LIMIT 1", (queue_id,)
            ).fetchone()
        return row is not None

    async def remember_passthrough(self, source_url: str, url: str, deal_key: str) -> None:
        """Record a clean unmonetized destination so it can pass the provenance gate.

        A pass-through link is deliberately NOT an affiliate link: it exists only
        because the network has no campaign for that store. Registering the exact
        pair keeps the "only links we produced may be published" rule intact
        instead of weakening the check itself.
        """
        async with self.lock:
            self.conn.execute(
                "INSERT OR REPLACE INTO link_cache(source_url,affiliate_url,resolved_url,deal_key,created_at)"
                " VALUES(?,?,?,?,?)",
                (source_url, url, url, deal_key, time.time()),
            )
            await self._commit()

    async def revive_edited_job(self, chat_key: str, msg_id: int) -> str | None:
        """Re-open a source post that was edited before it reached any target.

        Deal channels publish the text first and add or repair the link seconds
        later. The first render then failed with "no monetizable URLs"/"no URLs",
        the row was closed, and the deal never appeared in our channels even
        though the edited source post is perfect - a whole class of "source has
        it, we don't". A job that already reached at least one target is left
        alone on purpose: posting the edit again would be a duplicate.
        """
        async with self.lock:
            row = self.conn.execute(
                "SELECT q.id, q.status FROM queue q WHERE q.chat_key=? AND q.msg_id=? "
                "AND NOT EXISTS (SELECT 1 FROM deliveries d "
                "WHERE d.queue_id=q.id AND d.status='sent' AND COALESCE(d.last_error,'')='')",
                (str(chat_key), msg_id),
            ).fetchone()
            if not row:
                return None
            if row["status"] == "pending":
                # Still waiting for a worker: nothing to revive, the render will
                # read the edited text from Telegram anyway.
                return "pending"
            self.conn.execute(
                "UPDATE queue SET status='pending', next_at=0, attempts=0, "
                "rendered_text=NULL, last_error='' WHERE id=?",
                (row["id"],),
            )
            await self._commit()
        notify_queue()
        return "revived"

    async def update_rendered(self, queue_id: int, text: str) -> None:
        """Freeze the canonical rendered text so every target (and every retry
        after a restart) sends byte-identical chunks."""
        async with self.lock:
            self.conn.execute("UPDATE queue SET rendered_text=? WHERE id=?", (text, queue_id))
            await self._commit()

    async def pending_targets(self, queue_id: int) -> list[str]:
        async with self.lock:
            # Terminal states: sent (posted), skipped (policy), held (uncertain;
            # manual review). Anything else ('pending', legacy 'failed')
            # is still actionable.
            rows = self.conn.execute(
                "SELECT target FROM deliveries WHERE queue_id=? AND status NOT IN ('sent','skipped','held')",
                (queue_id,),
            ).fetchall()
            return [r[0] for r in rows]

    async def delivery_progress(self, queue_id: int, target: str) -> int:
        async with self.lock:
            row = self.conn.execute(
                "SELECT chunks_sent FROM deliveries WHERE queue_id=? AND target=?",
                (queue_id, target),
            ).fetchone()
            return int(row[0]) if row else 0

    async def set_delivery_progress(self, queue_id: int, target: str, chunks_sent: int) -> None:
        async with self.lock:
            self.conn.execute(
                "UPDATE deliveries SET chunks_sent=MAX(chunks_sent,?) WHERE queue_id=? AND target=?",
                (chunks_sent, queue_id, target),
            )
            await self._commit(patient=True)

    async def delivery(self, queue_id: int, target: str, ok: bool, error: str = "") -> None:
        async with self.lock:
            self.conn.execute(
                "UPDATE deliveries SET status=?,attempts=attempts+1,last_error=? WHERE queue_id=? AND target=?",
                ("sent" if ok else "pending", error[:500], queue_id, target),
            )
            await self._commit()

    async def delivery_skipped(self, queue_id: int, target: str, reason: str) -> None:
        """Record a target this post was deliberately WITHHELD from.

        POST-DEPLOY FIX (2026-10-11): policy skips (duplicate product,
        review-channel filters, undeclared-tag targets, unreachable extra
        targets) used to be stored as status='sent', so the ledger - and both
        audits - counted a withheld post as a delivered one (Adidas queues
        351498/351502: last_error='duplicate product' on status='sent' rows).
        'skipped' is terminal like 'sent' (never retried) but is never counted
        as a send. Rows written by older builds keep status='sent' with a
        non-empty last_error; the audits treat those as skips too.
        """
        async with self.lock:
            self.conn.execute(
                "UPDATE deliveries SET status=?,attempts=attempts+1,last_error=? WHERE queue_id=? AND target=?",
                ("skipped", reason[:500], queue_id, target),
            )
            await self._commit()

    async def shopping_quota_left(self) -> int:
        """How many more posts the review channel may take today (IST)."""
        if SHOPPING_DAILY_CAP <= 0:
            return 1_000_000
        day_key = datetime.now(IST).strftime("%Y-%m-%d")
        async with self.lock:
            row = self.conn.execute(
                "SELECT sent_count FROM shopping_quota WHERE day_key=?", (day_key,)
            ).fetchone()
        used = int(row["sent_count"]) if row else 0
        return max(0, SHOPPING_DAILY_CAP - used)

    async def shopping_pace_wait(self) -> float:
        """Seconds to wait before this channel may post again, 0 when ready.

        USER RULE (2026-09-06): "oka human laga daily oka 50 posts". A human
        curator does not fire 50 posts in one burst at 3am and then vanish - and
        a burst is exactly what a reviewer reads as an automated feed. So the
        day's allowance is SPREAD: posting hours only, and a minimum gap between
        posts derived from the cap, with a little jitter so the timing never
        looks machine-regular.
        """
        if not SHOPPING_HUMAN_PACING:
            return 0.0
        now = datetime.now(IST)
        # Outside posting hours nobody is shopping and nobody is curating.
        if not (SHOPPING_ACTIVE_START <= now.hour < SHOPPING_ACTIVE_END):
            tomorrow = now.replace(hour=SHOPPING_ACTIVE_START, minute=0, second=0, microsecond=0)
            if now.hour >= SHOPPING_ACTIVE_END:
                tomorrow += timedelta(days=1)
            return max(60.0, (tomorrow - now).total_seconds())
        day_key = now.strftime("%Y-%m-%d")
        async with self.lock:
            row = self.conn.execute(
                "SELECT last_sent_at FROM shopping_quota WHERE day_key=?", (day_key,)
            ).fetchone()
        last = float(row["last_sent_at"]) if row and row["last_sent_at"] else 0.0
        if not last:
            return 0.0
        active_seconds = (SHOPPING_ACTIVE_END - SHOPPING_ACTIVE_START) * 3600
        cap = SHOPPING_DAILY_CAP if SHOPPING_DAILY_CAP > 0 else 50
        # Spread the cap across the active window, then relax it slightly so a
        # busy hour can still catch up rather than silently dropping deals.
        gap = (active_seconds / max(1, cap)) * 0.7
        gap += random.uniform(0, gap * 0.4)          # never machine-regular
        waited = time.time() - last
        return max(0.0, gap - waited)

    async def note_shopping_sent(self) -> None:
        day_key = datetime.now(IST).strftime("%Y-%m-%d")
        async with self.lock:
            self.conn.execute(
                "INSERT INTO shopping_quota(day_key,sent_count,last_sent_at) VALUES(?,1,?) "
                "ON CONFLICT(day_key) DO UPDATE SET sent_count=sent_count+1, last_sent_at=?",
                (day_key, time.time(), time.time()),
            )
            # Keep the table tiny: yesterday's counters are of no further use.
            self.conn.execute("DELETE FROM shopping_quota WHERE day_key < ?",
                              ((datetime.now(IST) - timedelta(days=3)).strftime("%Y-%m-%d"),))
            await self._commit()

    async def claim_premium(self, queue_id: int) -> tuple[bool, float]:
        """Atomically gate highest-score premium job for the evening window."""
        async with self.lock:
            now = time.time()
            inside, night_key, next_window = premium_time_status(now)
            self.conn.execute("BEGIN IMMEDIATE")
            state = self.conn.execute("SELECT * FROM premium_state WHERE id=1").fetchone()
            if state["night_key"] != night_key:
                self.conn.execute(
                    "UPDATE premium_state SET night_key=?,sent_count=0,next_at=0,claim_queue_id=NULL,claim_at=0 WHERE id=1",
                    (night_key,),
                )
                state = self.conn.execute("SELECT * FROM premium_state WHERE id=1").fetchone()
            if not inside:
                await self._commit()
                return False, next_window
            if state["sent_count"] >= PREMIUM_MAX_PER_NIGHT:
                await self._commit()
                return False, next_window
            if state["claim_queue_id"] and state["claim_queue_id"] != queue_id and state["claim_at"] >= now - 600:
                await self._commit()
                return False, max(now + 60, float(state["next_at"] or 0))
            top = self.conn.execute(
                """SELECT q.id FROM queue q JOIN deliveries d ON d.queue_id=q.id
                   WHERE d.target=? AND d.status NOT IN ('sent','skipped','held') AND q.premium_score IS NOT NULL
                     AND q.status IN ('pending','processing')
                   ORDER BY q.premium_score DESC,q.created_at ASC LIMIT 1""",
                (PREMIUM_TARGET,),
            ).fetchone()
            if top and int(top[0]) != queue_id:
                await self._commit()
                return False, now + 60
            if now < float(state["next_at"] or 0):
                await self._commit()
                return False, float(state["next_at"])
            self.conn.execute(
                "UPDATE premium_state SET claim_queue_id=?,claim_at=? WHERE id=1",
                (queue_id, now),
            )
            await self._commit()
            return True, now

    async def complete_premium(self, queue_id: int, ok: bool) -> None:
        async with self.lock:
            state = self.conn.execute("SELECT claim_queue_id FROM premium_state WHERE id=1").fetchone()
            if not state or state[0] != queue_id:
                return
            if ok:
                gap_max = max(int(PREMIUM_GAP_MIN_SECONDS), int(PREMIUM_GAP_MAX_SECONDS))
                next_at = time.time() + random.randint(int(PREMIUM_GAP_MIN_SECONDS), gap_max)
                self.conn.execute(
                    "UPDATE premium_state SET sent_count=sent_count+1,next_at=?,claim_queue_id=NULL,claim_at=0 WHERE id=1",
                    (next_at,),
                )
            else:
                self.conn.execute(
                    "UPDATE premium_state SET claim_queue_id=NULL,claim_at=0 WHERE id=1"
                )
            await self._commit(patient=ok)

    async def finish(self, row: sqlite3.Row, successes: int, price: int | None,
                     premium_defer_until: float | None = None) -> None:
        async with self.lock:
            queue_id = row["id"]
            now = time.time()
            # `row` was claimed before save_render(); refresh mutable fields so
            # successful delivery really commits the rendered product keys.
            fresh = self.conn.execute(
                "SELECT deal_keys_json,attempts FROM queue WHERE id=?", (queue_id,)
            ).fetchone()
            keys = json.loads((fresh["deal_keys_json"] if fresh else None) or "[]")
            attempts = int(fresh["attempts"] if fresh else row["attempts"])
            if successes:
                for key in keys:
                    self.conn.execute(
                        "INSERT OR REPLACE INTO posted_deals VALUES(?,?,?,?)",
                        (key, price, now, queue_id),
                    )
                if price is not None and PRICE_DEDUP_SECONDS > 0:
                    self.conn.execute(
                        "INSERT OR REPLACE INTO price_posts VALUES(?,?,?)", (price, now, queue_id)
                    )
                self.conn.execute("DELETE FROM deal_claims WHERE queue_id=?", (queue_id,))
            remaining_rows = self.conn.execute(
                "SELECT target FROM deliveries WHERE queue_id=? AND status NOT IN ('sent','skipped','held')",
                (queue_id,),
            ).fetchall()
            remaining_targets = [r[0] for r in remaining_rows]
            only_scheduled_premium = (
                remaining_targets == [PREMIUM_TARGET] and premium_defer_until is not None
            )
            if only_scheduled_premium:
                self.conn.execute(
                    "UPDATE queue SET status='pending',next_at=? WHERE id=?",
                    (max(now + 30, premium_defer_until), queue_id),
                )
            elif remaining_targets and attempts < JOB_MAX_ATTEMPTS:
                delay = job_retry_delay(attempts)
                self.conn.execute(
                    "UPDATE queue SET status='pending',attempts=attempts+1,next_at=? WHERE id=?",
                    (now + delay, queue_id),
                )
            else:
                self.conn.execute("UPDATE queue SET status='done' WHERE id=?", (queue_id,))
                if not successes:
                    self.conn.execute("DELETE FROM deal_claims WHERE queue_id=?", (queue_id,))
            await self._commit()
        # A job that still owes targets must be picked up immediately, not at
        # the end of the next idle poll.
        notify_queue()

    async def fail_job(self, row: sqlite3.Row, error: str) -> None:
        async with self.lock:
            attempts = row["attempts"] + 1
            if attempts >= JOB_MAX_ATTEMPTS:
                status, next_at = "failed", 0
                self.conn.execute("DELETE FROM deal_claims WHERE queue_id=?", (row["id"],))
            else:
                status, next_at = "pending", time.time() + job_retry_delay(attempts)
            self.conn.execute(
                "UPDATE queue SET status=?,attempts=?,next_at=?,last_error=? WHERE id=?",
                (status, attempts, next_at, error[:1000], row["id"]),
            )
            await self._commit()
        log.info("RETRY | queue=%s attempt=%s status=%s (%s)",
                 row["id"], attempts, status, error[:160])
        notify_queue()

    async def mark_done(self, queue_id: int, reason: str = "") -> None:
        async with self.lock:
            self.conn.execute(
                "UPDATE queue SET status='done',last_error=? WHERE id=?", (reason[:1000], queue_id)
            )
            self.conn.execute("DELETE FROM deal_claims WHERE queue_id=?", (queue_id,))
            await self._commit()
        notify_queue()

    async def maintenance(self) -> dict[str, int]:
        """Bound disk growth without touching live/pending work."""
        async with self.lock:
            now = time.time()
            queue_cutoff = now - STATE_RETENTION_DAYS * 86400
            cache_cutoff = now - LINK_CACHE_DAYS * 86400
            old_ids = [row[0] for row in self.conn.execute(
                "SELECT id FROM queue WHERE status IN ('done','failed') AND created_at<?",
                (queue_cutoff,),
            ).fetchall()]
            deleted_deliveries = 0
            deleted_queue = 0
            if old_ids:
                placeholders = ",".join("?" for _ in old_ids)
                deleted_deliveries = self.conn.execute(
                    f"DELETE FROM deliveries WHERE queue_id IN ({placeholders})", old_ids
                ).rowcount
                deleted_queue = self.conn.execute(
                    f"DELETE FROM queue WHERE id IN ({placeholders})", old_ids
                ).rowcount
            deleted_cache = self.conn.execute(
                "DELETE FROM link_cache WHERE created_at<?", (cache_cutoff,)
            ).rowcount
            self.conn.execute(
                "DELETE FROM posted_deals WHERE posted_at<?", (now - PRODUCT_DEDUP_SECONDS,)
            )
            self.conn.execute(
                "DELETE FROM price_posts WHERE posted_at<?", (now - PRICE_DEDUP_SECONDS,)
            )
            # Same rule as reserve(): a claim held by a job that is still
            # pending/processing must survive housekeeping. Purging it was how a
            # deferred (Premium) or backlogged job lost its lock and the same
            # campaign from another source slipped through to a second post.
            self.conn.execute(
                "DELETE FROM deal_claims WHERE claimed_at<? AND queue_id NOT IN "
                "(SELECT id FROM queue WHERE status IN ('pending','processing'))",
                (now - 3600,),
            )
            self.conn.execute(
                "DELETE FROM deliveries WHERE queue_id NOT IN (SELECT id FROM queue)"
            )
            await self._commit()
            with contextlib.suppress(sqlite3.OperationalError):
                self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            # Compact only when the durable DB becomes unusually large; normal
            # maintenance avoids frequent blocking VACUUM operations.
            with contextlib.suppress(OSError, sqlite3.OperationalError):
                if DB_PATH.exists() and DB_PATH.stat().st_size > 128 * 1024 * 1024:
                    self.conn.execute("VACUUM")
            return {
                "queue": max(0, deleted_queue),
                "deliveries": max(0, deleted_deliveries),
                "cache": max(0, deleted_cache),
            }


store = Store(DB_PATH)

# ---------------------------------------------------------------------------
# External clients
# ---------------------------------------------------------------------------
# The public converter answers {"success": 1, "data": <our converted link>} -
# but `data` has also been seen as the WHOLE deal text with the links swapped
# inside it, as a LIST, and as an OBJECT of link fields; and on failure as a
# sentence ("Url not found in post!", "... could not locate ...") with success
# 0. Every shape has to be read, because an unreadable answer is not a lost
# post (the deal still goes out) - it is a LOST COMMISSION, silently.
EARNKARO_NO_LINK_MARKERS = (
    "could not locate", "url not found", "not found in post", "no url",
    "invalid url", "unable to convert", "no deal", "not a valid", "cannot convert",
)
EARNKARO_LINK_KEYS = (
    "converted_url", "converted_link", "convertedlink", "affiliate_url",
    "affiliate_link", "ekaro_url", "ekarourl", "short_url", "shortlink",
    "shorten_url", "profit_link", "link", "url", "deal", "deeplink", "deep_link",
)


def _response_flag_failed(value: Any) -> bool:
    """Recognize explicit failure flags without rejecting a missing flag."""
    if value is None:
        return False
    if isinstance(value, bool):
        return not value
    if isinstance(value, (int, float)):
        return value <= 0
    return str(value).strip().lower() in {
        "0", "false", "no", "fail", "failed", "failure", "error", "unsuccessful", "not_ok",
    }


def _matches_any_source(url: str, excluded_urls: Iterable[str]) -> bool:
    """A URL with only source tracking noise removed is still the source URL."""
    candidate = clean_url(url)
    candidate_key = canonical_url(candidate)
    try:
        query = {str(k).lower(): values for k, values in parse_qs(urlparse(candidate).query).items()}
        publisher_ids = query.get("affextparam2", [])
        # affExtParam2 is attribution, not disposable source tracking noise.
        # Let the output gate distinguish our publisher from a foreign one;
        # otherwise canonical_url() would hide the ID difference as a source echo.
        if publisher_ids:
            return False
    except Exception:
        pass
    for source in excluded_urls:
        if not source:
            continue
        source_clean = clean_url(str(source))
        if candidate == source_clean or candidate_key == canonical_url(source_clean):
            return True
    return False


def first_http_url(value: Any, depth: int = 0,
                   excluded_urls: Iterable[str] = ()) -> str | None:
    """Find a usable URL in an API payload, skipping echoed source URLs."""
    if value is None or depth > 4:
        return None
    if isinstance(value, str):
        text = value.strip()
        if any(marker in text.lower() for marker in EARNKARO_NO_LINK_MARKERS):
            return None
        for match in re.finditer(r"https?://[^\s<>\[\](){}\"'|]+", text):
            candidate = clean_url(match.group(0))
            if not _matches_any_source(candidate, excluded_urls):
                return candidate
        return None
    if isinstance(value, dict):
        lowered = {str(k).lower(): v for k, v in value.items()}
        for key in EARNKARO_LINK_KEYS:
            if key in lowered:
                found = first_http_url(lowered[key], depth + 1, excluded_urls)
                if found:
                    return found
        for item in value.values():
            found = first_http_url(item, depth + 1, excluded_urls)
            if found:
                return found
        return None
    if isinstance(value, (list, tuple, set)):
        for item in value:
            found = first_http_url(item, depth + 1, excluded_urls)
            if found:
                return found
    return None


def parse_earnkaro_response(body: str,
                            source_urls: Iterable[str] = ()) -> tuple[str | None, str]:
    """(our converted link | None, a one-line reason for the log).

    Explicit API failures always win over a URL accidentally echoed in `data`.
    When the API returns a whole deal, source links are skipped so the first URL
    in the response cannot silently masquerade as the converted link.
    """
    source_urls = tuple(source_urls)
    text = (body or "").strip()
    if not text:
        return None, "empty response body"
    try:
        payload = json.loads(text)
    except Exception:
        return None, f"non-JSON response (proxy/HTML error page?): {text[:140]!r}"
    if not isinstance(payload, dict):
        found = first_http_url(payload, excluded_urls=source_urls)
        return (found, "ok") if found else (None, f"unexpected shape: {text[:140]!r}")
    message = str(payload.get("message") or payload.get("error") or "").strip()
    success_present = "success" in payload
    success = payload.get("success") if success_present else payload.get("status")
    status = payload.get("status")
    if ((success_present and _response_flag_failed(success))
            or (status is not None and _response_flag_failed(status))):
        reason = message or str(payload.get("data") or payload.get("result") or "API marked conversion unsuccessful")
        return None, f"success={success!r} message={reason[:140]!r}"
    if isinstance(status, str) and status.strip().lower() in {"fail", "failed", "failure", "error"}:
        return None, f"status={status!r} message={message[:140]!r}"
    if "data" in payload:
        data = payload.get("data")
    elif "result" in payload:
        data = payload.get("result")
    else:
        # Some responses put `link`/`converted_url` beside `success`, not under
        # a `data` or `result` member.
        data = payload
    found = first_http_url(data, excluded_urls=source_urls)
    if found:
        return found, message or "ok"
    if message:
        return None, f"success={success!r} message={message[:140]!r}"
    return None, f"success={success!r} no link in data: {str(data)[:140]!r}"


class CircuitBreaker:
    def __init__(self, threshold: int = 5, recovery: float = 60):
        self.threshold, self.recovery = threshold, recovery
        self.failures, self.opened_at = 0, 0.0

    def allow(self) -> bool:
        if self.opened_at and time.monotonic() - self.opened_at < self.recovery:
            return False
        if self.opened_at:
            self.opened_at, self.failures = 0, 0
        return True

    def success(self) -> None:
        self.failures, self.opened_at = 0, 0

    def failure(self) -> None:
        self.failures += 1
        if self.failures >= self.threshold:
            self.opened_at = time.monotonic()


EK_BREAKER = CircuitBreaker()
EK_SEM = asyncio.Semaphore(EK_MAX_CONCURRENCY)


class AffiliateClient:
    def __init__(self, session: aiohttp.ClientSession):
        self.session = session
        # URL -> (checked_at, is_alive). The same URL is probed up to three
        # times per deal (merchant page, affiliate link, pre-send recheck);
        # without a cache each repeat cost another 18-36s of network waiting,
        # which is what made posts land minutes after the source.
        self._health: dict[str, tuple[float, bool]] = {}
        # URL -> when its last probe saw an explicit service outage (503 with
        # the load balancer's own words). "not alive" is not the same answer as
        # "gone": an outage is retried, a dead product page is dropped.
        self._outage: dict[str, float] = {}
        # long_url -> short link, so a retry never re-calls the shortener.
        self._short_cache: dict[str, str] = {}
        # USER RULE (2026-09-06): "review channelo shorten ga marchatam bitly use
        # cheyaku". A bit.ly/is.gd hop hides the destination, and a reviewer who
        # cannot see amazon.in in the link cannot verify the post. So the review
        # channel publishes the NATIVE store URL. Every short link we mint is
        # recorded here so the delivery step can put the real URL back.
        self._short_to_long: dict[str, str] = {}
        # COMPLIANCE (restart gap): this map used to live only in memory, so a
        # bit.ly minted before a restart could deliver OUR tag to an UNDECLARED
        # channel - strip_amazon_tag_for_undeclared() could no longer see behind
        # the hop, and Amazon reads the tag inside the redirect. The short->long
        # pairs are durable in link_cache, so seed the map back at startup
        # (newest first, capped) and both the review-channel expansion and the
        # undeclared-channel strip work across restarts exactly as they do
        # inside one process.
        with contextlib.suppress(Exception):
            for short, long_url in store.recent_shortened_amazon_links(limit=2000):
                self._short_to_long[short] = apply_amazon_tag(long_url)

    async def cache_link(self, source_url: str, affiliate: str, resolved: str, key: str) -> None:
        """Proxy to the global store's link cache so subclasses/tests can override."""
        await store.cache_link(source_url, affiliate, resolved, key)

    async def resolve(self, source_url: str) -> str:
        current = source_url
        for _ in range(4):
            try:
                p = urlparse(current)
                host = (p.hostname or "").lower()
                # OUR HYPD share link is a FINAL link, not a wrapper to unwrap.
                # Following it hands us the merchant page with HYPD's
                # attribution in the query, and the next cleaning pass strips
                # exactly those parameters - the user's own commission link
                # became an untagged page that pays nothing. It is returned
                # untouched; the destination is read separately, for identity.
                if is_our_hypd_link(current):
                    break
                if host_matches(host, "linkredirect.in"):
                    dl = parse_qs(p.query).get("dl", [None])[0]
                    if dl:
                        target = unquote(dl)
                        if target.startswith("http"):
                            current = target
                            continue
                # USER RULE (2026-09-04): whatever wrapper the source used must
                # end up as OUR link. Known shorteners are followed by name;
                # an UNKNOWN host whose link is a single short slug (the shape
                # every shortener has - "loot.deals/xYz9") is followed too, so
                # a brand-new wrapper domain still resolves to the real store
                # page and gets monetized instead of being posted as-is.
                if host not in SHORT_DOMAINS and not is_unresolvable_short_link(host, current):
                    break
                async with self.session.get(
                    current, allow_redirects=True,
                    timeout=aiohttp.ClientTimeout(total=HTTP_TOTAL_TIMEOUT_SECONDS),
                    headers={"User-Agent": "Mozilla/5.0"},
                ) as response:
                    final = str(response.url)
                    if final == current:
                        break
                    current = final
            except Exception as exc:
                log.warning("RESOLVE failed %s: %s", source_url[:60], exc)
                break
        return current

    async def link_not_broken(self, url: str) -> bool:
        """Alive-check a URL, reusing the verdict of a recent identical check."""
        key = clean_url(url)
        cached = self._health.get(key)
        if cached and time.time() - cached[0] < LINK_HEALTH_CACHE_SECONDS:
            return cached[1]
        try:
            verdict = await asyncio.wait_for(self._probe_link(key),
                                             timeout=LINK_PROBE_BUDGET_SECONDS)
        except asyncio.TimeoutError:
            log.info("LINK CHECK inconclusive | %.1fs budget for %s - posting anyway "
                     "(a slow page is not a dead deal)", LINK_PROBE_BUDGET_SECONDS, key[:90])
            verdict = True
        # An outage verdict is deliberately NOT cached for the full window: the
        # retry that follows is meant to look again, and caching "no server
        # behind it" for 15 minutes would turn a two-second blip into a link
        # that stays suppressed long after the site came back.
        cacheable = verdict or not self.link_outage(key)
        if LINK_HEALTH_CACHE_SECONDS > 0 and cacheable:
            if len(self._health) > 3000:
                self._health.clear()
            self._health[key] = (time.time(), verdict)
        return verdict

    def link_outage(self, url: str) -> bool:
        """True when the LAST verdict for this URL was an explicit service outage.

        Kept separate from `link_not_broken` so a caller can tell "the product is
        gone" (drop it) from "the host has no backend right now" (retry it, never
        publish it). Read-only and offline: it answers from the probe's own
        bookkeeping, so no extra HTTP request is ever made for it.
        """
        stamp = getattr(self, "_outage", {}).get(clean_url(url))
        return bool(stamp and time.time() - stamp < LINK_OUTAGE_CACHE_SECONDS)

    def _remember_outage(self, url: str) -> None:
        if not hasattr(self, "_outage"):
            self._outage = {}
        self._outage[clean_url(url)] = time.time()

    def _forget_outage(self, url: str) -> None:
        getattr(self, "_outage", {}).pop(clean_url(url), None)

    async def _probe_link(self, url: str) -> bool:
        """Follow the URL and reject explicit merchant repair/dead-page responses.

        Three verdicts, not two, even though the return type stays a bool:

          * dead words in the page  -> False, at once (the product is gone);
          * an explicit 5xx outage  -> one more attempt (these last seconds),
            then False, and `link_outage()` says WHICH kind of False it was so
            the caller retries the deal instead of throwing it away;
          * a bare 404/5xx, a bot block, or a timeout -> "inconclusive", which
            stays True: our datacenter IP is not the reader's browser, and a
            doubt must never cost a live deal.
        """
        outage = False
        for attempt in range(LINK_CHECK_ATTEMPTS):
            try:
                async with self.session.get(
                    url, allow_redirects=True,
                    timeout=aiohttp.ClientTimeout(total=HTTP_TOTAL_TIMEOUT_SECONDS),
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36"},
                ) as response:
                    raw = await response.content.read(400_000)
                    body = raw.decode(response.charset or "utf-8", errors="ignore")
                    if looks_like_service_outage(response.status, body):
                        outage = True
                        log.warning("LINK OUTAGE | status=%s attempt %s/%s | the host has no "
                                    "server behind it right now (retried, never published): %s",
                                    response.status, attempt + 1, LINK_CHECK_ATTEMPTS, url[:100])
                    elif looks_broken_page(response.status, body):
                        self._forget_outage(url)
                        log.warning("BROKEN LINK blocked | status=%s | %s", response.status, url[:100])
                        return False
                    elif response.status < 500:
                        self._forget_outage(url)
                        return True
                    # 401/403/429 can be merchant bot/rate protection rather than
                    # a dead customer-facing page, so they remain inconclusive.
            except Exception as exc:
                log.warning("LINK CHECK attempt %s inconclusive %s: %s", attempt + 1, url[:70], exc)
            if attempt + 1 < LINK_CHECK_ATTEMPTS:
                # An outage is retried a little later than an unknown failure:
                # "no server available" is what a rolling deploy looks like.
                await asyncio.sleep(LINK_CHECK_RETRY_SLEEP_SECONDS * (3 if outage else 1))
        if outage:
            self._remember_outage(url)
            return False
        # Do not discard a valid deal solely because Oracle was bot-blocked or
        # temporarily offline; explicit repair/dead-page signatures are blocked.
        return True

    async def link_is_proven_ours(self, url: str) -> tuple[bool, str]:
        """Is this EXACT link provably a paid link of ours? (True, why) / (False, why not).

        Four kinds of proof, nothing else:
          * native attribution - our Amazon tag, or a Flipkart-family page carrying
            our publisher id AND a real conversion id (affExtParam1);
          * a converted hop we recorded (owned_link_proofs: the converter minted it
            for this account, bound to our publisher id);
          * our own HYPD share link with a verified Meesho mapping;
          * an exact row in the link cache whose pair is proven ours.
        A page where somebody merely appended our NUMBER fails all four - and that
        is the point of the rule (USER RULE 2026-10-19).
        """
        url = clean_url(url)
        if not url:
            return False, "empty link"
        if Store.has_native_owned_attribution(url):
            return True, "native attribution"
        missing = conversion_signature_missing(url)
        try:
            if await store.cached_link_is_owned(url, ""):
                return True, "converted hop with stored proof"
        except Exception:  # noqa: BLE001 - a DB hiccup is a refusal, not a crash
            pass
        if is_our_hypd_link(url):
            return True, "our HYPD share link"
        return False, missing or "no stored proof that this link pays our account"

    async def preflight_links(self, text: str, require_ours: bool = True
                              ) -> tuple[list[str], dict[str, str], int]:
        """Verify every link for POSTING, up to POST_VERIFY_ATTEMPTS times.

        Returns (urls, {bad_url: kind}, passes_used) where kind is:
          "unowned" - not provably ours (never retried: retrying cannot help);
          "outage"  - an explicit 503 "no server behind it" (retry);
          "dead"    - the page's own dead words (retry, then the caller decides).
        An empty dict means every link was verified OUR and alive.
        """
        urls = list(dict.fromkeys(clean_url(x) for x in URL_RE.findall(text or "")))
        if not urls:
            return [], {}, 0
        sem = asyncio.Semaphore(max(1, EK_MAX_CONCURRENCY))

        async def one(url: str) -> tuple[str, str]:
            async with sem:
                if require_ours:
                    owned, _why = await self.link_is_proven_ours(url)
                    if not owned:
                        return url, "unowned"
                # Fresh look every pass: a cached "alive" from render time must
                # not answer a check that exists to catch a link dying in between.
                health = getattr(self, "_health", None)
                if isinstance(health, dict):
                    health.pop(url, None)
                if await self.link_not_broken(url):
                    return url, ""
                return url, "outage" if self.link_outage(url) else "dead"

        bad: dict[str, str] = {}
        passes = 0
        for attempt in range(POST_VERIFY_ATTEMPTS):
            passes = attempt + 1
            bad = {url: kind for url, kind in await asyncio.gather(*(one(u) for u in urls)) if kind}
            if not bad:
                return urls, {}, passes
            if set(bad.values()) == {"unowned"}:
                # Ownership is a fact about the link, not about timing: a second
                # look cannot turn somebody else's page into ours.
                return urls, bad, passes
            if attempt + 1 < POST_VERIFY_ATTEMPTS:
                log.warning("POST VERIFY | pass %s/%s: %s link(s) not ready (%s); "
                            "re-checking in %.1fs before this post is allowed out",
                            attempt + 1, POST_VERIFY_ATTEMPTS, len(bad),
                            ", ".join(sorted(set(bad.values()))), POST_VERIFY_SLEEP_SECONDS)
                await asyncio.sleep(POST_VERIFY_SLEEP_SECONDS)
        log.warning("POST VERIFY | %s link(s) still unverified after %s pass(es): %s",
                    len(bad), passes, ", ".join(sorted(set(bad.values()))))
        return urls, bad, passes

    async def rendered_links_not_broken(self, text: str) -> bool:
        """Belt-and-braces pre-send check, run CONCURRENTLY and time-boxed.

        The old serial loop could hold a worker for a minute or more on a
        multi-link post (each URL up to 2 x 18s). Every link is still checked;
        if the whole budget runs out we keep the render-path verdict instead of
        delaying a live deal, because a slow probe is not a broken deal.
        """
        if PRESEND_CHECK_BUDGET_SECONDS <= 0:
            # A zero budget is the operator saying "never hold a post for this extra
            # check" - and it used to mean the OPPOSITE (fall back to probing every link
            # SERIALLY, which is slower than the concurrent default). The render path has
            # already verified these links, so the honest reading is: skip the pre-send
            # pass, keep the post, and say nothing.
            return True
        urls = list(dict.fromkeys(clean_url(x) for x in URL_RE.findall(text or "")))
        if not urls:
            return False
        if PRESEND_FRESH_SECONDS > 0:
            # Render may have been minutes ago (a held job, a retry, a queue
            # backlog) and the render-time verdict is a cached "alive". Only a
            # verdict older than the window is dropped; a seconds-old one is
            # deliberately reused so the common path pays no second round trip.
            health = getattr(self, "_health", None)
            if isinstance(health, dict):
                now = time.time()
                for url in urls:
                    cached = health.get(url)
                    if cached and now - cached[0] >= PRESEND_FRESH_SECONDS:
                        health.pop(url, None)
        if len(urls) == 1:
            return await self.link_not_broken(urls[0])
        sem = asyncio.Semaphore(max(1, EK_MAX_CONCURRENCY))

        async def check(url: str) -> bool:
            async with sem:
                return await self.link_not_broken(url)

        try:
            results = await asyncio.wait_for(
                asyncio.gather(*(check(url) for url in urls)),
                timeout=PRESEND_CHECK_BUDGET_SECONDS,
            )
        except asyncio.TimeoutError:
            log.warning("PRESEND CHECK | %s link(s) exceeded the %ss budget; "
                        "keeping the verified render-path links (deal is never lost over a slow probe)",
                        len(urls), int(PRESEND_CHECK_BUDGET_SECONDS))
            return True
        return all(results)

    @staticmethod
    def valid_generated(link: str) -> bool:
        """Only trust an owned affiliate link and reject visible foreign attribution."""
        if not link.startswith("http"):
            return False
        parsed = urlparse(link)
        host = (parsed.hostname or "").lower()
        query = {str(k).lower(): v for k, v in parse_qs(parsed.query).items()}
        # Flipkart exposes the publisher in affExtParam2. If present, it must be
        # ours; never accept an authenticated API echo carrying somebody else's ID.
        visible_ids = query.get("affextparam2", [])
        if OUR_EK_ID and visible_ids and any(str(v) != OUR_EK_ID for v in visible_ids):
            return False
        if in_domains(host, AMAZON_DOMAINS):
            tags = query.get("tag", [])
            return bool(OUR_TAG and tags) and all(str(tag).strip() == OUR_TAG for tag in tags)
        if in_domains(host, FOREIGN_ECHO_DOMAINS):
            return False
        return bool(host)

    @staticmethod
    def earnkaro_output_kind(link: str) -> str | None:
        """Prove the API returned an affiliate link, not a plain merchant URL.

        A 200 response is not proof of conversion. Accept a known Affiliaters/
        network redirect or a direct Flipkart-family URL carrying our publisher
        id. A native Amazon tag is deliberately NOT counted as EarnKaro output:
        it is the separate fallback path for accounts without an Amazon campaign.
        """
        try:
            parsed = urlparse(clean_url(link))
            host = (parsed.hostname or "").lower()
            if parsed.scheme not in {"http", "https"} or not host:
                return None
            if in_domains(host, AMAZON_DOMAINS) or in_domains(host, FOREIGN_ECHO_DOMAINS):
                return None
            query = {str(k).lower(): values for k, values in parse_qs(parsed.query).items()}
            publisher_ids = query.get("affextparam2", [])
            if publisher_ids:
                if OUR_EK_ID and all(str(value).strip() == OUR_EK_ID for value in publisher_ids):
                    return "publisher"
                return None
            redirect_domains = OUR_SHORTENER_DOMAINS | {"earnkaro.com", "earnkaro.in"}
            if in_domains(host, redirect_domains):
                return "redirect"
            return None
        except Exception:
            return None

    async def _verify_unknown_affiliate_output(self, link: str, source_urls: tuple[str, ...],
                                               resolved: str) -> str | None:
        """Follow an UNRECOGNIZED converter output and accept it only on evidence.

        `earnkaro_output_kind()` can only call a link ours when it recognizes the
        network's short domain. Affiliaters adds and renames redirect domains, and
        the old behaviour for an unknown one was `EK REJECT` + an unmonetized post -
        a lost commission that looks exactly like "this store has no campaign".
        So an output that is short-link-SHAPED is followed instead of refused:

          * it must not be a known foreign shortener/echo domain;
          * its destination must be a real store page, not the source URL;
          * a foreign `affExtParam2`/tag on that destination is a REFUSAL (somebody
            else's money must never be posted as ours);
          * OUR publisher id or OUR tag on the destination is proof -> accept;
          * a bare store page (attribution travelling server-side, exactly how
            ekaro.in itself works) is accepted only when the short host is not a
            known foreign shortener and the destination differs from the source.

        Returns the API's own (short) link, or None - never raises: verification is
        a bonus on top of the refusal it replaces, never a new way to lose a post.
        """
        try:
            original = clean_url(link)
            parsed = urlparse(original)
            host = (parsed.hostname or "").lower()
            if not host or in_domains(host, FOREIGN_ECHO_DOMAINS):
                return None
            if not looks_like_shortener(host, original):
                # A merchant-page echo keeps its old treatment: a 200 is not a
                # conversion, and a plain page pays nobody.
                return None
            source_keys = {canonical_url(u) for u in source_urls if u}
            async with self.session.get(
                original, allow_redirects=True,
                timeout=aiohttp.ClientTimeout(total=HTTP_TOTAL_TIMEOUT_SECONDS),
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                       "AppleWebKit/537.36 Chrome/131 Safari/537.36"},
            ) as response:
                final = clean_url(str(response.url) or original)
                raw = await response.content.read(200_000)
            final_host = (urlparse(final).hostname or "").lower()
            redirect_seen = bool(final_host) and clean_url(final) != clean_url(original)
            if redirect_seen:
                if canonical_url(final) in source_keys:
                    return None                   # it only led back to the source link
                if in_domains(final_host, FOREIGN_ECHO_DOMAINS):
                    return None                   # somebody else's wrapper
                if (in_domains(final_host, NON_STORE_DOMAINS)
                        or in_domains(final_host, NON_SHOP_DOMAINS)):
                    return None                   # a blog / share / app wrapper
                if in_domains(final_host, AMAZON_DOMAINS):
                    tags = {str(v).strip() for v in
                            parse_qs(urlparse(final).query).get("tag", []) if str(v).strip()}
                    if OUR_TAG and tags == {OUR_TAG}:
                        log.info("EK VERIFIED | unknown short domain %s -> our Amazon tag on %s",
                                 host, final_host)
                        return original
                    return None
            destination = final if (redirect_seen
                                    and in_domains(final_host, KNOWN_MERCHANT_DOMAINS)) else ""
            if not destination:
                # A JS redirect page (no HTTP redirect at all) still carries its
                # target in the markup - read it the way the HYPD destination is.
                for candidate in URL_RE.findall(raw.decode("utf-8", errors="ignore")):
                    candidate = clean_url(candidate).replace("\\/", "/")
                    candidate_host = (urlparse(candidate).hostname or "").lower()
                    if not in_domains(candidate_host, KNOWN_MERCHANT_DOMAINS):
                        continue
                    if canonical_url(candidate) in source_keys:
                        continue
                    destination = candidate
                    final_host = candidate_host
                    break
                else:
                    return None                   # nothing proven: keep the refusal
            query = {str(k).lower(): v for k, v in parse_qs(urlparse(destination).query).items()}
            visible_ids = {str(v).strip() for v in query.get("affextparam2", []) if str(v).strip()}
            if visible_ids and (not OUR_EK_ID or visible_ids != {OUR_EK_ID}):
                log.error("EK REJECT | unknown short domain %s leads to FOREIGN attribution %s",
                          host, ",".join(sorted(visible_ids))[:40])
                return None
            log.info("EK VERIFIED | unknown short domain %s resolves to %s%s", host, final_host,
                     " carrying OUR publisher id" if visible_ids else
                     " (attribution travels in the redirect, as ekaro.in does)")
            return original
        except Exception as exc:
            log.warning("EK VERIFY | could not verify %s (%s: %s); keeping the old refusal",
                        (urlparse(link).hostname or link)[:60], type(exc).__name__, exc)
            return None

    async def convert(self, source_url: str, multi_link: bool, resolved_hint: str | None = None) -> "LinkResult | None":
        cached = await store.cached_link(source_url)
        if cached and is_amazon_search_or_browse_link(source_url):
            # canonical_url() collapses EVERY /s? search to one cache key (the
            # query carries no pid/asin/node), so a row under it belongs to the
            # FIRST search cached, never this one. Searches are never served
            # from (or written to) the cache - the tag/API answer is always fresh.
            cached = None
        if cached:
            cached_url = clean_url(cached["affiliate_url"])
            cached_resolved = cached["resolved_url"] or resolved_hint or source_url
            cached_host = (urlparse(cached_url).hostname or "").lower()
            cached_resolved_host = (urlparse(clean_url(cached_resolved)).hostname or "").lower()
            cached_hypd_link = await store.hypd_link_for(
                source_url, cached_resolved, canonical_url(cached_resolved),
                product_key(cached_resolved), include_outside_meesho=True)
            cached_is_hypd = bool(cached_hypd_link) or is_our_hypd_link(cached_url)
            if STRICT_OUR_LINKS:
                cache_attribution_proven = await store.cached_link_is_owned(
                    cached_url, cached_resolved)
            else:
                cache_attribution_proven = (
                    in_domains(cached_host, OUR_RUNTIME_SHORTENER_DOMAINS)
                    or self.valid_generated(cached_url)
                )
            cache_is_safe = (
                clean_url(cached_url) != clean_url(source_url)
                and cache_attribution_proven
            )
            if cache_is_safe and meesho_product_id(cached_resolved) and cached_hypd_link:
                # A cache hit is not a fresh redirect check. Revalidate the share
                # against the cached identity, including source-share retargeting.
                return await self._hypd_affiliate_link(cached_hypd_link, source_url, multi_link,
                                                       destination_hint=cached_resolved)
            # Old releases cached Shopsy->HYPD results. Do not keep serving them
            # after the Meesho-only policy change; remove the stale product map and
            # re-run the normal route for that merchant instead.
            if cached_is_hypd and not in_domains(cached_resolved_host, HYPD_MERCHANT_DOMAINS):
                cache_is_safe = False
                if cached_hypd_link:
                    await store.forget_hypd_link(cached_hypd_link)
                log.warning("HYPD CACHE INVALIDATED | only Meesho uses our HYPD store; "
                            "re-checking %s through its normal route",
                            cached_resolved_host or "unknown destination")
            # POLICY SWITCH SAFETY. link_cache rows live for LINK_CACHE_DAYS
            # (14) and a row cached under the OLD policy would keep pinning it
            # long after the switch - the channel would post yesterday's answer
            # for a fortnight.
            #   2026-09-24 (network-first era): a NATIVE Amazon row was stale
            #   (it earned nothing) and got re-converted through EarnKaro;
            #   EarnKaro rows were served from cache, so no second API call.
            #   2026-10-04 (Associates APPROVED): the desired shape for an
            #   Amazon SOURCE is OUR OWN native tag. A cached NETWORK row for an
            #   Amazon source is therefore rebuilt natively - it still pays us,
            #   but it pays the network's share too, and the approval removed
            #   the only reason to accept that.
            cached_is_amazon_native = in_domains(cached_host, AMAZON_DOMAINS)
            cached_is_amazon_source = in_domains(cached_resolved_host, AMAZON_DOMAINS)
            if (cache_is_safe and cached_is_amazon_source
                    and (AMAZON_DIRECT_ASSOCIATES or not AMAZON_VIA_EARNKARO)
                    and not cached_is_amazon_native):
                upgraded = await self._native_amazon_link(
                    source_url, cached_resolved, cached_resolved, multi_link)
                if upgraded is not None:
                    log.info("AMAZON CACHE UPGRADED | cached network row for %s replaced by our "
                             "own Associates link (direct mode; full commission)",
                             cached_resolved_host or "an Amazon page")
                    return upgraded
            if cache_is_safe and not (AMAZON_VIA_EARNKARO and cached_is_amazon_native):
                # Old cache rows may predate the current policy. Upgrade them
                # before returning; never leak a long link.
                #
                # A TAGGED AMAZON LINK IS NEVER SHORTENED ON THE REVIEW
                # CHANNEL (Round 24): hiding that a link goes to Amazon is
                # link cloaking, a documented closure reason. Since 2026-09-06
                # the rule is per-shape, not per-store: a LIST is Bitly'd (its
                # links are expanded back to the native tagged URL when the
                # review channel receives the post), a single tagged Amazon
                # link stays native. So a list shortens BOTH stores now; a
                # single Amazon row still posts native and only a long
                # non-Amazon single link pays for a shortener.
                cached_is_amazon = in_domains(
                    (urlparse(cached_url).hostname or "").lower(), AMAZON_DOMAINS)
                needs_short = (
                    should_use_bitly(cached_resolved, multi_link)
                    or (not cached_is_amazon and len(cached_url) > SHORTEN_MIN_LEN))
                if needs_short and not (in_domains(cached_host, OUR_RUNTIME_SHORTENER_DOMAINS)
                                        or in_domains(cached_host, OUR_SHORTENER_DOMAINS)):
                    shortened = await self.shorten(cached_url)
                    if shortened:
                        cached_url = shortened
                        await store.cache_link(source_url, cached_url, cached_resolved,
                                               cached["deal_key"] or product_key(cached_resolved))
                    else:
                        log.warning("BITLY unavailable; using verified cached EarnKaro link")
                cached_key = cached["deal_key"] or product_key(source_url)
                if STRICT_OUR_LINKS:
                    # A legacy cache row can carry an opaque URL-hash key for a
                    # merchant page that DOES name its product id. Dedup must
                    # key on the verified identity, so upgrade the key instead
                    # of serving the stale one (the render gate skips the post
                    # outright when no identity exists at all).
                    verified_key = verified_product_id(cached_resolved, cached_url)
                    if verified_key:
                        cached_key = verified_key
                return LinkResult(source_url, cached_resolved, cached_url, cached_key)
        resolved = resolved_hint or await self.resolve(source_url)
        host = (urlparse(resolved).hostname or "").lower()
        if in_domains(host, NON_STORE_DOMAINS) or in_domains(host, NON_SHOP_DOMAINS):
            return None
        # Preserve meaningful category/filter parameters (for example Men vs
        # Women) while removing only source attribution/tracking parameters.
        clean = merchant_url(resolved)
        # OUR HYPD links are allowed for Meesho ONLY. Verify the merchant behind
        # a direct share before publishing it; never let an old Shopsy HYPD link
        # slip through just because its creator-store ID is ours.
        non_meesho_hypd_destination = ""
        if is_our_hypd_link(source_url) or is_our_hypd_link(resolved):
            hypd_link = source_url if is_our_hypd_link(source_url) else resolved
            destination = await self._hypd_destination(hypd_link)
            destination_host = (urlparse(clean_url(destination)).hostname or "").lower()
            if in_domains(destination_host, HYPD_MERCHANT_DOMAINS):
                return await self._hypd_affiliate_link(
                    hypd_link, source_url, multi_link, destination_hint=destination, destination_verified=True)
            if destination and in_domains(destination_host, KNOWN_MERCHANT_DOMAINS):
                # Shopsy/other merchants must not inherit our HYPD route. Continue
                # through their ordinary affiliate path, then keep a clean merchant
                # URL as the safe fallback so the deal itself is not lost.
                await store.forget_hypd_link(hypd_link)
                log.warning("HYPD OUT OF SCOPE | our HYPD ID is configured for Meesho only; "
                            "using the normal route for %s", destination_host)
                resolved = clean_url(destination)
                host = destination_host
                clean = merchant_url(resolved)
                non_meesho_hypd_destination = clean
            else:
                log.warning("HYPD REJECT | destination could not be verified as Meesho; "
                            "our HYPD link was not published")
                return None

        # Meesho is the sole merchant routed to our HYPD store. Shopsy and all
        # other merchants follow the normal affiliate path.
        if in_domains(host, HYPD_MERCHANT_DOMAINS):
            learned = await store.hypd_link_for(
                clean_url(resolved), canonical_url(resolved), product_key(resolved))
            if learned:
                return await self._hypd_affiliate_link(learned, source_url, multi_link,
                                                       destination_hint=clean_url(resolved))
            # Nothing curated for this Meesho product yet. Record it as a to-do
            # and say so ONCE, with the exact action that fixes it.
            first_time = False
            with contextlib.suppress(Exception):
                first_time = await store.remember_hypd_wanted(
                    clean_url(resolved), product_key(resolved))
            if first_time:
                log.warning(
                    "HYPD MISSING | no curated HYPD link for this Meesho product yet, "
                    "so strict-all skips it: %s | fix: create the link in the HYPD app, then "
                    "run: python3 ops/hypd_links.py '<that link>'",
                    clean_url(resolved)[:90])
                log.info("HYPD WANTED | added to the curation list (%s product(s) pending)",
                         len(store.recent_hypd_wanted(limit=1000)))
            return None  # fail closed: never invent a HYPD token or publish bare/source Meesho

        # Do not monetize/post an expired campaign destination. This catches
        # Flipkart's HTTP-200 "Just a quick repair needed" page shown to users.
        if not await self.link_not_broken(clean):
            if self.link_outage(clean):
                # The store is momentarily without a backend (503 "no server is
                # available"). That is a RETRY, not a rejection: converting now
                # would mint a link to a page nobody can open, and dropping the
                # deal would lose a product that is usually back in seconds.
                raise RuntimeError(
                    f"merchant page answered a service outage (503): "
                    f"{(urlparse(clean).hostname or clean)[:60]}")
            return None
        # AMAZON. Three policies, two switches:
        #   AMAZON_DIRECT_ASSOCIATES=true (default since the 2026-10-04
        #   approval) - the NATIVE tagged product link is the FIRST choice: the
        #   whole Associates commission is ours, no network share. A shape the
        #   native path cannot build (no usable ASIN) falls through to EarnKaro
        #   as the second chance, so no Amazon deal loses its monetization.
        #   AMAZON_DIRECT_ASSOCIATES=false + AMAZON_VIA_EARNKARO=true - the
        #   2026-09-24 order: EarnKaro first, native tagged link as the fallback.
        #   AMAZON_VIA_EARNKARO=false - the 2026-09-06 behaviour: the native
        #   tagged product URL, never sent to EarnKaro.
        # Amazon SEARCH / hidden-keywords / browse-node links have no single ASIN
        # but still earn on the tag path, so the native path covers them too.
        is_amazon = in_domains(host, AMAZON_DOMAINS)
        native_amazon_possible = bool(OUR_TAG) and is_amazon
        native_direct_first = AMAZON_DIRECT_ASSOCIATES or not AMAZON_VIA_EARNKARO
        native_result: "LinkResult | None" = None
        if native_amazon_possible and native_direct_first:
            native_result = await self._native_amazon_link(source_url, clean, resolved, multi_link)
            if native_result is not None:
                if AMAZON_VIA_EARNKARO:
                    log.info("AMAZON DIRECT | our own Associates tag %s on %s - the whole "
                             "commission is ours (account approved 2026-10-04)",
                             OUR_TAG, (urlparse(clean).hostname or clean)[:40])
                return native_result
            if not AMAZON_VIA_EARNKARO:
                return None
        # The native tagged link is still a fallback when it has not been tried yet.
        native_fallback_possible = native_amazon_possible and not native_direct_first
        # ALREADY OURS (USER REPORT 2026-10-19: "chala miss chesthunnav"). A
        # source channel can post a link that ALREADY carries our EarnKaro
        # publisher id (affExtParam2=<our id>, the shape the converter mints) or
        # our Associates tag. When the converter then answers "no campaign"
        # - or the API is down - the deal used to be dropped even though the
        # link in hand was a paid link of ours. Proven by the URL itself, it is
        # published as it stands: the reader lands on the same product, the
        # commission is still ours, and a doubt can no longer cost the post.
        # A FOREIGN id never qualifies: has_native_owned_attribution() requires
        # every value to be exactly ours.
        already_ours = ""
        if not is_amazon:
            for candidate in (resolved, source_url):
                if candidate and Store.has_native_owned_attribution(candidate):
                    already_ours = clean_url(candidate)
                    break
        earned: "LinkResult | None" = None
        # The Amazon switch must not touch other stores: with
        # AMAZON_VIA_EARNKARO=false an Amazon link never goes to the network,
        # but Flipkart/Myntra/... always do (that switch is about Amazon only).
        if AMAZON_VIA_EARNKARO or not is_amazon:
            try:
                earned = await self._earnkaro_link(source_url, clean, resolved, multi_link)
            except Exception:
                # Temporary API failures stay retryable unless strict-all can
                # construct a genuine native affiliate destination (Amazon tag
                # or supported publisher ID). A clean Shopsy/Myntra page is not
                # a fallback merely because the HYPD destination was resolved.
                publisher_fallback = bool(
                    non_meesho_hypd_destination
                    and attribute_with_our_publisher(non_meesho_hypd_destination)
                    != non_meesho_hypd_destination
                )
                if STRICT_OUR_LINKS:
                    if not (native_fallback_possible or publisher_fallback or already_ours):
                        raise
                elif not (native_fallback_possible or non_meesho_hypd_destination):
                    raise
                if native_fallback_possible:
                    log.warning("EK FALLBACK | API unavailable for %s; using the native Amazon tag "
                                "(not an EarnKaro conversion)",
                                (urlparse(clean).hostname or clean)[:60])
        if earned is not None:
            return earned
        if already_ours:
            # No conversion was needed: the link we were given already pays us.
            key = product_key(already_ours) if not is_amazon_search_or_browse_link(
                source_url) else product_key(resolved)
            await store.cache_link(source_url, already_ours, resolved, key)
            # No proof row is written on purpose: the link IS the proof (its own
            # affExtParam2/tag), and _strict_cache_pair_is_owned() plus
            # verify_generated_text() both accept native attribution directly.
            # Recording it under a converter proof type would claim a
            # conversion that never happened.
            log.warning("OUR LINK KEPT | %s already carries our publisher id - the converter "
                        "had nothing to add, so the verified link is published as-is instead "
                        "of losing the deal", (urlparse(already_ours).hostname or "")[:45])
            return LinkResult(source_url, resolved, already_ours, key)
        if native_fallback_possible:
            # The network could not monetize this Amazon link. Dropping it would
            # lose the deal and posting it untagged would earn nothing, so publish
            # the native tagged product URL; delivery strips the tag on every
            # channel that is not declared to Amazon.
            log.warning("EK FALLBACK | no EarnKaro conversion for %s; using the native Amazon tag "
                        "(AMAZON_VIA_EARNKARO=%s; this fallback is not EarnKaro commission)",
                        (urlparse(clean).hostname or clean)[:60], AMAZON_VIA_EARNKARO)
            return await self._native_amazon_link(source_url, clean, resolved, multi_link)
        if non_meesho_hypd_destination:
            # The HYPD link was outside the Meesho-only rule. Rebuild a native
            # publisher-attributed Flipkart-family link when supported; strict-all
            # skips every clean/unattributed fallback. Only legacy mode may still
            # publish that clean merchant page (USER REPORT 2026-10-04: a bare page
            # opens for free and pays nobody).
            published = attribute_with_our_publisher(non_meesho_hypd_destination)
            if (STRICT_OUR_LINKS and published == non_meesho_hypd_destination
                    and not Store.has_native_owned_attribution(published)):
                log.warning("OWN-LINK SKIP | HYPD is scoped to Meesho and %s has no verified "
                            "EarnKaro publisher attribution: %s", host or "that store",
                            non_meesho_hypd_destination[:90])
                return None
            key = product_key(non_meesho_hypd_destination)
            await store.cache_link(source_url, published, non_meesho_hypd_destination, key)
            if published != non_meesho_hypd_destination:
                log.warning("LINK ATTRIBUTED | HYPD out of scope for %s, so the page is "
                            "posted WITH our publisher id (%s) instead of a bare link that "
                            "pays nobody: %s", host or "that store", OUR_EK_ID, published[:90])
            else:
                log.warning("UNMONETIZED LINK | legacy mode only; HYPD is configured for "
                            "Meesho only, so posting the clean %s destination: %s",
                            host, non_meesho_hypd_destination[:90])
            return LinkResult(source_url, non_meesho_hypd_destination,
                              published, key)
        return None

    async def _hypd_destination(self, afflink: str) -> str:
        """The merchant page OUR HYPD share link points at (identity only).

        NEVER published - the post carries the HYPD (or Bitly) link. The page is
        used for the product identity (so the same product never posts twice)
        and for the product -> HYPD-link map that later monetizes a bare Meesho
        link. HYPD answers with a redirect page, so the destination is read from
        the redirect, and failing that from the page's own markup.
        """
        try:
            async with self.session.get(
                afflink, allow_redirects=True,
                timeout=aiohttp.ClientTimeout(total=HTTP_TOTAL_TIMEOUT_SECONDS),
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                       "AppleWebKit/537.36 Chrome/131 Safari/537.36"},
            ) as response:
                if response.status >= 400:
                    return ""
                final = str(response.url)
                if final and clean_url(final) != clean_url(afflink):
                    return clean_url(final)
                raw = await response.content.read(200_000)
                body = raw.decode(getattr(response, "charset", None) or "utf-8", errors="ignore")
            candidates = {}
            body = body.replace("\\/", "/")
            for candidate in URL_RE.findall(body):
                url = clean_url(candidate)
                host = (urlparse(url).hostname or "").lower()
                if not host or in_domains(host, HYPD_DOMAINS):
                    continue
                if in_domains(host, NON_STORE_DOMAINS) or in_domains(host, {"googletagmanager.com"}):
                    continue
                if in_domains(host, KNOWN_MERCHANT_DOMAINS) or in_domains(host, HYPD_MERCHANT_DOMAINS):
                    candidates.setdefault(canonical_url(url), url)
            if len(candidates) == 1:
                return next(iter(candidates.values()))
        except Exception as exc:
            log.warning("HYPD destination unresolved for %s: %s", afflink[:60], exc)
        return ""

    async def _hypd_affiliate_link(self, afflink: str, source_url: str, multi_link: bool,
                                   destination_hint: str = "", destination_verified: bool = False) -> "LinkResult | None":
        """Only our exact share token, resolving to the SAME identified Meesho product."""
        if not is_our_hypd_link(afflink):
            return None
        known_product = await store.hypd_product_for(afflink)
        destination = destination_hint if destination_verified else await self._hypd_destination(afflink)
        pid = meesho_product_id(destination)
        expected_urls = [value for value in (destination_hint, known_product) if value]
        expected_ids = {meesho_product_id(value) for value in expected_urls}
        if not pid or (expected_ids and expected_ids != {pid}):
            await store.forget_hypd_link(afflink)
            for expected_url in expected_urls:
                if meesho_product_id(expected_url) and meesho_product_id(expected_url) != pid:
                    await store.remember_hypd_wanted(expected_url, meesho_key(expected_url))
            log.warning("HYPD REJECT | unverified destination or product mapping drift; link withheld")
            return None
        key = meesho_key(destination)
        if not await store.remember_hypd_link(afflink, destination, key):
            return None
        affiliate = afflink
        if HYPD_ALWAYS_BITLY or len(afflink) > SHORTEN_MIN_LEN:
            affiliate = await self.shorten(afflink) or afflink
            if affiliate == afflink:
                log.warning("BITLY unavailable; keeping verified OUR HYPD link")
        await store.cache_link(source_url, affiliate, destination, key)
        if affiliate != afflink:
            await store.remember_owned_link_proof(affiliate, afflink, "hypd")
        log.info("HYPD LINK | owned store=%s product=%s", hypd_store_of(afflink), key)
        return LinkResult(source_url, destination, affiliate, key)

    async def _native_amazon_link(self, source_url: str, clean: str, resolved: str,
                                  multi_link: bool) -> "LinkResult | None":
        """OUR Associates tag on a native Amazon URL (product, search or browse).

        USER RULE (2026-09-06): "channels anni mana new tag use chesi". A LIST
        (2+ store links) goes out as Bitly short links - one uniform link style,
        our key pays for it - while a SINGLE Amazon link is already short and
        stays native (no quota spent). Every link minted here is recorded in
        _short_to_long, and delivery to t.me/smartbuyhub11 expands our short
        links back to exactly the URL that was shortened, so the reviewer always
        sees https://www.amazon.in/dp/ASIN?tag=OUR_TAG.
        """
        native = compact_amazon_product_link(clean)
        asin = re.search(r"/dp/([A-Z0-9]{10})(?:[/?#]|$)", native, re.I)
        if asin:
            tagged = apply_amazon_tag(native)
            affiliate = tagged
            if should_use_bitly(resolved, multi_link) or SHORTEN_AMAZON_LINKS:
                shortened = await self.shorten(tagged)
                if shortened:
                    affiliate = shortened
                    # Delivery expands this pair again for the review channel, so
                    # the reviewed post still shows the real tagged product page.
                    log.info("AMAZON LINK SHORTENED | %s -> %s (native tagged form kept "
                             "for the review channel)", tagged[:70], shortened)
                else:
                    # Never lose a valid commission link merely because the
                    # cosmetic shortener is unavailable/rate-limited.
                    log.warning("BITLY unavailable; posting the native tagged Amazon link")
            key = product_key(clean)
            # Keep the verified tagged destination beside any minted short URL;
            # a bare page in resolved_url would make strict provenance ambiguous.
            await store.cache_link(source_url, affiliate, tagged, key)
            return LinkResult(source_url, clean, affiliate, key)
        if is_amazon_search_or_browse_link(clean):
            # No cache entry: canonical_url() collapses every /s? search link to
            # one key (the query carries no pid/asin/node), so caching here would
            # hand the FIRST search link back for every later one. The tag on the
            # URL is self-proving at the provenance gate, so no cache is needed.
            tagged = apply_amazon_tag(clean)
            affiliate = tagged
            if should_use_bitly(clean, multi_link) or SHORTEN_AMAZON_LINKS:
                shortened = await self.shorten(tagged)
                if shortened:
                    affiliate = shortened
                    # Search/browse URLs avoid link_cache because canonical_url()
                    # collapses distinct queries. Persist this proof by exact short
                    # URL so strict verification survives a restart without a
                    # shared cache key.
                    await store.remember_owned_link_proof(
                        affiliate, tagged, "amazon_native")
                    # Delivery expands this pair again for the review channel, so
                    # the reviewed post still shows the real tagged browse page.
                    log.info("AMAZON LINK SHORTENED | %s -> %s (native tagged form kept "
                             "for the review channel)", tagged[:70], shortened)
                else:
                    # Never lose a valid commission link merely because the
                    # cosmetic shortener is unavailable/rate-limited.
                    log.warning("BITLY unavailable; posting the native tagged Amazon link")
            return LinkResult(source_url, clean, affiliate, product_key(clean))
        return None

    async def _earnkaro_link(self, source_url: str, clean: str, resolved: str,
                             multi_link: bool) -> "LinkResult | None":
        """Convert ONE merchant URL through the EarnKaro/Affiliaters API.

        Returns our converted link, or None when the network has nothing for
        this URL (the caller then picks the fallback). Raises when the API is
        unreachable/rate-limited so the JOB can retry: a temporary outage must
        not silently cost a commission.
        """
        if not EK_BREAKER.allow():
            raise RuntimeError("EarnKaro circuit open")
        async with EK_SEM:
            last = None
            attempt = 0
            refused: set[int] = set()
            while attempt < 3:
                try:
                    async with self.session.post(
                        EK_API,
                        # `convert_option: convert_only` is the documented contract:
                        # convert the link and do nothing else (no posting, no
                        # account-default formatting). Sending it explicitly is what
                        # makes the RESPONSE shape predictable.
                        json={"deal": clean, "convert_option": EARNKARO_CONVERT_OPTION},
                        # Cloudflare fronts this API and answers a bare python
                        # User-Agent with "error code: 1010" (403) - live probe
                        # 2026-10-04. The UA below is what the rest of this file
                        # already sends on every fetch.
                        headers={"Authorization": f"Bearer {ek_current_key()}",
                                 "Content-Type": "application/json",
                                 "User-Agent": API_USER_AGENT},
                        timeout=aiohttp.ClientTimeout(total=max(8.0, HTTP_TOTAL_TIMEOUT_SECONDS * 2)),
                    ) as response:
                        body = await response.text()
                        if response.status in (401, 403):
                            # The TOKEN is refused. With more than one key this is
                            # a failover, not a failure: the same request is retried
                            # with the next key, which must pay the same publisher
                            # (enforced at startup). A silent 401 is indistinguishable
                            # from "this store has no campaign" in the log, so the
                            # last key still says exactly where the fix is.
                            refused.add(EK_ROTATION["index"])
                            if (ek_rotate(f"HTTP {response.status}")
                                    and EK_ROTATION["index"] not in refused):
                                continue
                            log.error("EK AUTH | the EarnKaro API refused our token "
                                      "(HTTP %s at %s, %s key(s) tried). Regenerate "
                                      "EARNKARO_API_KEY and save it in the dashboard's API keys "
                                      "panel - every link falls back to unmonetized until then.",
                                      response.status, EK_API, len(refused))
                            EK_BREAKER.failure()
                            return None
                        if response.status in (429, 500, 502, 503, 504):
                            raise RuntimeError(f"EarnKaro HTTP {response.status}")
                        if response.status < 200 or response.status >= 300:
                            EK_BREAKER.failure()
                            log.error("EK HTTP | status=%s host=%s body=%s",
                                      response.status,
                                      (urlparse(clean).hostname or "unknown"), body[:180].replace("\n", " "))
                            return None
                        result, reason = parse_earnkaro_response(
                            body, source_urls=(source_url, clean, resolved))
                        if not result:
                            log.warning("EK MISS | no converted link for %s | API said: %s",
                                        (urlparse(clean).hostname or clean)[:60], reason[:200])
                            return None
                        result = clean_url(result)
                        output_kind = self.earnkaro_output_kind(result)
                        if not output_kind:
                            # A domain this build has never seen is not automatically
                            # somebody's junk: the network mints new redirect domains,
                            # and refusing them means the deal posts and earns nothing
                            # (which looks identical to "store has no campaign"). The
                            # output is therefore FOLLOWED and accepted only when its
                            # destination proves it (see _verify_unknown_affiliate_output).
                            verified = await self._verify_unknown_affiliate_output(
                                result, (source_url, clean, resolved), resolved)
                            if verified:
                                # The returned short link stays the published link
                                # (the network's attribution travels behind it).
                                output_kind = "verified"
                            else:
                                log.error("EK REJECT | API response is not an attributable affiliate "
                                          "link (host=%s); checking Affiliaters network selections "
                                          "and campaigns",
                                          (urlparse(result).hostname or "unknown").lower())
                                return None
                        if (result == clean_url(source_url) and output_kind != "publisher"):
                            log.error("EK REJECT | API echoed the source URL instead of converting it "
                                      "(host=%s)", (urlparse(result).hostname or "unknown").lower())
                            return None
                        if output_kind == "redirect" and any(
                                canonical_url(result) == canonical_url(candidate)
                                for candidate in (clean, resolved) if candidate):
                            log.error("EK REJECT | API returned the original merchant destination "
                                      "without affiliate attribution (host=%s)",
                                      (urlparse(result).hostname or "unknown").lower())
                            return None
                        if not self.valid_generated(result):
                            log.warning("EK REJECT | the API answered a link with foreign attribution "
                                        "or an invalid destination (host=%s)",
                                        (urlparse(result).hostname or "unknown").lower())
                            return None
                        # The converter's output is published as EarnKaro minted it.
                        # Its affid/cmpid/mcn parameters are the network's own
                        # routing; affExtParam1 is the conversion id and
                        # affExtParam2 is the publisher that is paid - all checked
                        # by earnkaro_output_kind() just above. See the note on
                        # FOREIGN_ATTRIBUTION_KEYS: stripping those is what would
                        # actually break the commission.
                        result = apply_amazon_tag(result)
                        if not await self.link_not_broken(result):
                            if self.link_outage(result):
                                # The converter's own short domain (bitli.in) or
                                # the page behind it is in an outage. Raising
                                # makes the attempt loop below re-mint the link
                                # (a different short code often lands on a
                                # healthy node) and, if the outage outlasts the
                                # attempts, hands the job back to its retry
                                # schedule - the proven conversion is never
                                # published as a 503 and never thrown away.
                                raise RuntimeError(
                                    "converted link answered a service outage: "
                                    + (urlparse(result).hostname or result)[:60])
                            return None
                        affiliate = result
                        # Single non-Amazon deal: preserve EarnKaro's own short link.
                        # Amazon always uses our Bitly; every 2+ link post uses Bitly
                        # for all generated links so the final post stays neat.
                        # A Flipkart product URL that came back long is compacted
                        # natively first (slug + item id + pid): free, no quota,
                        # and it is what keeps "shortga ravali" true even when the
                        # shortener is rate-limited.
                        if len(affiliate) > SHORTEN_MIN_LEN:
                            compact = compact_flipkart_product_link(affiliate)
                            if compact != affiliate and len(compact) < len(affiliate):
                                affiliate = result = compact
                        # A LIST must look uniform: one link shortened and the
                        # next left long reads like a mistake. (On the pure native
                        # Amazon path an Amazon product link is already short and
                        # never reaches here; on the EarnKaro path every store is
                        # treated the same, which is the whole point.)
                        if (should_use_bitly(resolved, multi_link)
                                or len(result) > SHORTEN_MIN_LEN
                                # Only a link that actually carries OUR tag may be
                                # shortened: cloaking an untagged Amazon page behind a
                                # short link is both unmonetized and a policy risk.
                                or (SHORTEN_AMAZON_LINKS and OUR_TAG and in_domains(
                                    (urlparse(result).hostname or "").lower(), AMAZON_DOMAINS))):
                            shortened = await self.shorten(result)
                            if shortened:
                                affiliate = shortened
                            else:
                                # Never lose a valid commission link merely because
                                # the cosmetic shortener is unavailable/rate-limited.
                                log.warning("BITLY unavailable; using verified EarnKaro fallback")
                        key = product_key(resolved)
                        if not is_amazon_search_or_browse_link(source_url):
                            await store.cache_link(source_url, affiliate, resolved, key)
                            # Preserve the actual authenticated converter URL when
                            # the public link was wrapped in generic Bitly/is.gd.
                            # resolved remains the merchant page for identity and
                            # routing; ownership proof lives in its own table.
                            await store.remember_owned_link_proof(
                                affiliate, result, "earnkaro_api")
                        # (Search links are deliberately NOT cached: every /s?
                        # search shares one canonical key, so storing here would
                        # hand this search's link back for every later one.)
                        EK_BREAKER.success()
                        # One line per monetized link: this is how an operator
                        # answers "are the EarnKaro links actually converting?"
                        # from the log alone.
                        log.info("EK SUCCESS | %s -> %s",
                                 (urlparse(resolved).hostname or resolved)[:45], affiliate[:90])
                        return LinkResult(source_url, resolved, affiliate, key)
                except Exception as exc:
                    last = exc
                    # Brief jitter, not a 8s sleep per attempt: an API blip must
                    # delay this deal by seconds, never by minutes.
                    await asyncio.sleep(min(2.5, 0.4 * (2 ** attempt) + random.random() * 0.3))
                attempt += 1
            EK_BREAKER.failure()
            log.error("EK NETWORK | conversion API retries exhausted: %s", last)
            raise RuntimeError(f"EarnKaro failed: {last}")

    @staticmethod
    def with_our_attribution(url: str) -> str:
        """The same page carrying OUR attribution, before a hop is minted.

        A hop is only safe when its destination is provably ours, so the tag is
        applied to the DESTINATION first and the shortener is pointed at that.
        The reported links (2026-10-21) are exactly what skipping this produces:
        an is.gd hop to `amazon.in/dp/ASIN` with no tag, which opens fine and
        pays nobody.
        """
        try:
            host = (urlparse(clean_url(url)).hostname or "").lower()
        except Exception:
            return url
        if in_domains(host, AMAZON_DOMAINS):
            return apply_amazon_tag(url)
        return url

    @classmethod
    def may_mint_short_link(cls, url: str) -> bool:
        """True only for a URL whose DESTINATION can be made provably ours.

        * a link that is ALREADY a hop is never wrapped in another hop (a source's
          tinyurl inside our bit.ly hides both the store and the original owner);
        * an Amazon page needs OUR Associates tag - which `with_our_attribution()`
          puts there, so an untagged page is still fine to shorten as long as the
          tag can be applied (i.e. AMAZON_TAG is configured);
        * anything else (our converter's long affiliate URL, a tagged search page)
          carries our attribution in the URL itself.
        """
        try:
            parsed = urlparse(clean_url(url))
            host = (parsed.hostname or "").lower()
        except Exception:
            return False
        if not host:
            return False
        if in_domains(host, SHORTENER_HOSTS):
            return False
        if in_domains(host, AMAZON_DOMAINS):
            return bool(OUR_TAG) or Store.is_our_amazon_tag_link(url)
        return True

    async def shorten(self, long_url: str) -> str | None:
        # Same long URL seen again (retry, re-render, another target)? Reuse the
        # short link we already minted instead of spending another API call.
        cached_short = self._short_cache.get(long_url)
        if cached_short:
            return cached_short
        # Point the hop at a destination that carries OUR tag, never at the
        # untagged page: that is the difference between an is.gd link that earns
        # and the two that did not.
        target = self.with_our_attribution(long_url)
        if not self.may_mint_short_link(target):
            log.warning("SHORTENER refused | not a link we could prove is ours: %s",
                        long_url[:90])
            return None
        # USER RULE (2026-10-22, "commission asalu miss avvakunda"): a hop is only
        # worth minting when the page behind it PAYS US. Wrapping a bare merchant
        # page in bit.ly makes a link that opens, looks ours, and earns nothing -
        # the exact shape of the two is.gd links that were reported twice.
        if not await self.link_is_provably_ours(target):
            log.warning("SHORTENER refused | the destination carries no attribution of "
                        "ours, so the hop would earn nobody: %s", target[:90])
            return None
        shortened = await self.bitly(target)
        if shortened:
            self._short_cache[long_url] = shortened
            self._short_to_long[shortened] = long_url
            return shortened
        if not TOKENLESS_SHORTENER:
            # Nothing in an is.gd URL says it is ours, and it may wrap a page that
            # earns nothing (see TOKENLESS_SHORTENER). The caller keeps the native
            # tagged link instead: shorter beats unprovable.
            log.warning("SHORTENER unavailable (no Bitly); keeping the native link: %s",
                        long_url[:90])
            return None
        # Tokenless fallback, only when this host opted in. The authenticated
        # affiliate destination is created first; this service only redirects to it.
        try:
            async with self.session.get(
                "https://is.gd/create.php",
                params={"format": "simple", "url": target},
                timeout=aiohttp.ClientTimeout(total=max(6.0, HTTP_TOTAL_TIMEOUT_SECONDS)),
            ) as response:
                if response.status == 200:
                    link = (await response.text()).strip()
                    if link.startswith("https://is.gd/"):
                        log.info("SHORTENER fallback=is.gd")
                        self._short_cache[long_url] = link
                        self._short_to_long[link] = long_url
                        return link
        except Exception as exc:
            log.warning("is.gd failed: %s", exc)
        return None

    async def bitly(self, long_url: str) -> str | None:
        for token in BITLY_TOKENS:
            try:
                async with self.session.post(
                    "https://api-ssl.bitly.com/v4/shorten",
                    json={"long_url": long_url},
                    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=max(6.0, HTTP_TOTAL_TIMEOUT_SECONDS)),
                ) as response:
                    if response.status == 429:
                        continue
                    if response.status in (200, 201):
                        data = await response.json(content_type=None)
                        link = data.get("link")
                        if isinstance(link, str) and link.startswith("http"):
                            return link
            except Exception as exc:
                log.warning("BITLY failed: %s", exc)
        return None

    async def expand_our_short_links(self, text: str) -> str:
        """Put the NATIVE store URL back wherever we minted a short link.

        Only links WE minted are touched, so nothing is guessed and a source's
        own short link is left exactly as it arrived. Used for the Amazon-review
        channel, where a bit.ly hop hides the destination the reviewer has to
        be able to see. A short link minted by an earlier process is resolved
        through the persistent link cache - the reviewer must never meet a bare
        hop just because the bot restarted between render and delivery.
        """
        out = text or ""
        for short, long_url in self._short_to_long.items():
            if short in out:
                out = out.replace(short, tag_native_amazon(long_url))
        for raw in dict.fromkeys(URL_RE.findall(out)):
            if raw not in out:
                continue
            host = (urlparse(clean_url(raw)).hostname or "").lower()
            if not (in_domains(host, OUR_RUNTIME_SHORTENER_DOMAINS)
                    or in_domains(host, OUR_SHORTENER_DOMAINS)):
                continue
            native = await store.affiliate_destination(raw)
            if native:
                out = out.replace(raw, tag_native_amazon(native))
        return out

    # ------------------------------------------------------------------ #
    # LINK REPAIR (USER RULE 2026-10-22): "commission asalu miss avvakunda"
    # ------------------------------------------------------------------ #
    # Reported twice: `https://is.gd/c3Gl9d` and `https://is.gd/bO79HA` in a
    # channel. Both were valid links and both resolved to UNTAGGED
    # amazon.in/dp pages, so every click through them paid nobody. Refusing such
    # a post protects the channel but still loses the sale, and a stale queue row
    # can carry the hop again after a restart. So the last action before a post
    # leaves is to REWRITE each link that cannot prove it pays us into one that
    # can: unwrap the hop, read its destination, and publish the destination in
    # OUR form (`amazon.in/dp/ASIN?tag=OURTAG`, or a converter link whose
    # publisher id is ours). Nothing is dropped and no commission is left behind.
    @staticmethod
    def provable_form(url: str) -> str | None:
        """`url` rewritten into a shape that proves it pays THIS account.

        Returns None when no such shape exists (a hop, another account's tag, a
        merchant page with no attribution we can add). Callers treat None as
        "this link must not be published as-is", never as "publish it anyway".
        """
        url = clean_url(url or "")
        if not url:
            return None
        try:
            host = (urlparse(url).hostname or "").lower()
        except ValueError:
            return None
        if in_domains(host, AMAZON_DOMAINS):
            if not OUR_TAG:
                return None                      # cannot make it pay us
            tagged = apply_amazon_tag(url)
            candidate = compact_amazon_product_link(tagged) or tagged
            return candidate if Store.is_our_amazon_tag_link(candidate) else None
        if (in_domains(host, SHORTENER_HOSTS) or in_domains(host, OUR_SHORTENER_DOMAINS)
                or in_domains(host, OUR_RUNTIME_SHORTENER_DOMAINS)):
            return None                          # a hop is never a provable form
        if Store.has_native_owned_attribution(url):
            return url                           # converter/HYPD attribution is ours
        return None

    async def link_is_provably_ours(self, url: str, book=None) -> bool:
        """True when `url` itself proves it pays us, or our own book says so.

        Two kinds of proof, and both are needed: the URL can carry the evidence
        (our Associates tag), or the row we wrote when we minted it can (a
        converter link bound to OUR publisher id in `owned_link_proofs`). A bare
        shortener hostname is never proof of either kind.
        """
        url = clean_url(url or "")
        if not url:
            return False
        if Store.has_native_owned_attribution(url):
            return True                       # the URL itself carries our proof
        book = book if book is not None else getattr(self, "repair_book", None)
        if book is None:
            book = store
        checker = getattr(book, "cached_link_is_owned", None)
        if checker is not None:
            with contextlib.suppress(Exception):
                if await checker(url, ""):
                    return True
        checker = getattr(book, "_strict_url_is_owned", None)
        if checker is not None:
            with contextlib.suppress(Exception):
                if checker(url):
                    return True
        return False

    @staticmethod
    def _is_service_link(url: str) -> bool:
        try:
            return in_domains((urlparse(clean_url(url)).hostname or "").lower(),
                              SERVICE_OFFER_DOMAINS)
        except ValueError:
            return False

    async def repair_unowned_links(self, text: str, *, store_obj=None,
                                   multi_link: bool = False) -> tuple[str, list[dict]]:
        """Rewrite every link that cannot prove it pays us. Returns (text, notes).

        For each candidate the destination is taken from our own book first
        (`link_cache`/`owned_link_proofs`), and only a hop with no stored
        destination costs a network round trip. `notes` is the audit trail: one
        row per link, `status` in {kept, repaired, unrepairable}.
        """
        book = store_obj
        if book is None:
            # `repair_book` is the seam tests use: a link book that records what
            # was written instead of touching an operator's database.
            book = getattr(self, "repair_book", None)
        if book is None:
            book = store
        out = text or ""
        notes: list[dict] = []
        family = {clean_url(OUR_FOLDER_LINK), *(clean_url(x) for x in OUR_MAIN_CHANNEL_LINKS)}
        for raw in dict.fromkeys(URL_RE.findall(out)):
            if raw not in out:
                continue
            url = clean_url(raw)
            if url in family or is_share_intent(url) or self._is_service_link(url):
                continue                          # not an affiliate destination
            if await self.link_is_provably_ours(url, book):
                continue                      # already proves it pays us
            own_form = self.provable_form(url)
            if own_form:
                if own_form == url:
                    continue                      # already proves it pays us
                # The same page in OUR form (a foreign/absent tag): swap it now,
                # a stranger's tag pays a stranger and no tag pays nobody.
                out = replace_url_everywhere(out, raw, own_form)
                notes.append({"url": url, "raw": raw, "host": (urlparse(url).hostname or "").lower(),
                              "hop": False, "destination": url, "repaired": own_form,
                              "status": "repaired", "why": ""})
                log.info("LINK REPAIR | %s -> %s (attribution retagged)", url[:70], own_form[:90])
                continue
            host = (urlparse(url).hostname or "").lower()
            hop = (in_domains(host, SHORTENER_HOSTS) or in_domains(host, OUR_SHORTENER_DOMAINS)
                   or in_domains(host, OUR_RUNTIME_SHORTENER_DOMAINS))
            note = {"url": url, "raw": raw, "host": host, "hop": hop,
                    "destination": "", "repaired": "", "status": "unrepairable",
                    "why": ""}
            destination = ""
            if book is not None:
                with contextlib.suppress(Exception):
                    destination = clean_url(await book.affiliate_destination(url) or "")
            if not destination and not hop:
                destination = url                 # a plain page: the page IS the destination
            if not destination and hop:
                # No stored destination: only a live unwrap can tell us what the
                # hop hides. A dead hop stays unrepairable - and therefore never
                # gets published as "probably ours".
                with contextlib.suppress(Exception):
                    destination = clean_url(await self.resolve(url))
            note["destination"] = destination
            repaired = self.provable_form(destination) if destination else None
            if not repaired and destination and not hop:
                # A plain merchant page we do not yet earn on: convert it now, so
                # the deal keeps its link AND the commission.
                with contextlib.suppress(Exception):
                    result = await self.convert(destination, multi_link, destination)
                    if result and result.affiliate:
                        candidate = clean_url(result.affiliate)
                        # A converter link is ours because OUR proof row says so,
                        # not because of its hostname (ekaro.in is anybody's).
                        if await self.link_is_provably_ours(candidate, book):
                            repaired = candidate
                            note["converted"] = True
            if repaired and not await self.link_is_provably_ours(repaired, book):
                note.setdefault("why", "the candidate form does not prove ownership")
                repaired = ""
            if repaired and repaired != url:
                out = replace_url_everywhere(out, raw, repaired)
                note.update(status="repaired", repaired=repaired)
                if book is not None:
                    # Bind the rewritten link to the destination we just proved,
                    # so the final gate can read the same answer without network.
                    with contextlib.suppress(Exception):
                        await book.cache_link(url, repaired, repaired, product_key(repaired))
                log.info("LINK REPAIR | %s -> %s (destination %s)", url[:70],
                         repaired[:90], destination[:70] or "unknown")
            else:
                note["why"] = ("hop has no destination we can prove" if hop
                               else "no attribution we can add")
                log.warning("LINK REPAIR failed | %s: %s", url[:80], note["why"])
            notes.append(note)
        return out, notes

    async def shorten_long_urls_in_text(self, rendered: str) -> str:
        """FINAL guarantee that no link leaves the post clumsy/long:
          1. Every Amazon PRODUCT (/dp/ASIN) URL is collapsed to its shortest
             native form - https://www.amazon.in/dp/ASIN?tag=OURTAG (~48 chars) -
             dropping psc/smid/th/ref noise, at no Bitly cost and with our tag
             intact (self-proving for provenance).
          2. Any remaining long link (Amazon SEARCH / hidden-keywords lists,
             category/filter URLs) is shortened via Bitly (is.gd fallback).
        Links already on a shortener domain are never re-shortened; if the
        shortener is unavailable the original link is kept (a deal is never lost)."""
        out = rendered or ""
        # Pass -1 (2026-10-22): repair every link that cannot prove it pays us
        # BEFORE any cosmetic work. A hop reported in a channel ("ilaga invalid
        # url link vasthunnai") is unwrapped here and republished as OUR tagged
        # destination, so the post keeps its link and we keep the commission.
        out, repair_notes = await self.repair_unowned_links(out)
        if any(note["status"] == "repaired" for note in repair_notes):
            log.info("LINK REPAIR | %d of %d unproven link(s) rewritten to ours",
                     sum(1 for note in repair_notes if note["status"] == "repaired"),
                     len(repair_notes))
        # Pass 0: a foreign Amazon tag is replaced with OURS on every Amazon
        # link first (a stranger's tag pays a third party; an untagged link
        # earns nothing). apply_amazon_tag() keeps exactly one tag - ours.
        for raw in dict.fromkeys(URL_RE.findall(out)):
            url = clean_url(raw)
            host = (urlparse(url).hostname or "").lower()
            if not in_domains(host, AMAZON_DOMAINS):
                continue
            stripped = apply_amazon_tag(url)
            if stripped and stripped != url and stripped != raw:
                out = replace_url_everywhere(out, raw, stripped)
        # Pass 1: native compaction of Amazon /dp/ product links (free).
        compacted = 0
        for raw in dict.fromkeys(URL_RE.findall(out)):
            url = clean_url(raw)
            host = (urlparse(url).hostname or "").lower()
            if not in_domains(host, AMAZON_DOMAINS):
                continue
            compact = compact_amazon_product_link(url)
            if compact and compact != url and compact != raw:
                out = replace_url_everywhere(out, raw, compact)
                compacted += 1
        # Pass 1b: native compaction of Flipkart product links (also free).
        # A dl.flipkart.com product URL arrives ~177 chars because of lid /
        # marketplace / srno session noise; slug + item id + pid is the same page
        # at about a third of the length, and it costs no shortener quota. This
        # runs BEFORE pass 2 so the shortener is only ever asked for the links
        # that genuinely cannot be compacted.
        for raw in dict.fromkeys(URL_RE.findall(out)):
            url = clean_url(raw)
            host = (urlparse(url).hostname or "").lower()
            if host not in FLIPKART_HOSTS:
                continue
            compact = compact_flipkart_product_link(url)
            if compact and compact != url and compact != raw:
                # A direct Flipkart affiliate URL can be compacted only if the
                # publisher's attribution survives and the compact form is
                # registered before the final provenance gate checks the post.
                if self.earnkaro_output_kind(compact) == "publisher":
                    destination = await store.affiliate_destination(raw) or url
                    with contextlib.suppress(Exception):
                        await self.cache_link(raw, compact, destination, product_key(destination))
                out = replace_url_everywhere(out, raw, compact)
                compacted += 1
        # Pass 2: Bitly/is.gd the remaining long links (search/category) — all
        # of them at once, so a 6-link list pays one round trip, not six.
        pending: list[tuple[str, str]] = []
        for raw in dict.fromkeys(URL_RE.findall(out)):
            url = clean_url(raw)
            host = (urlparse(url).hostname or "").lower()
            # USER RULE (2026-09-24): "bitly tho shorten ga chesi cheyu" — OUR
            # HYPD share links are always shortened, however short they look, so
            # nothing after the domain announces our store or the product.
            hypd_ours = is_our_hypd_link(url) and HYPD_ALWAYS_BITLY
            if len(url) <= SHORTEN_MIN_LEN and not hypd_ours:
                continue
            # A hop is never wrapped in another hop: SHORTENER_HOSTS is every
            # shortener we know (ours and strangers'), so a source's is.gd link
            # stays visible to the ownership gate instead of hiding behind a
            # bit.ly that would look like ours.
            if in_domains(host, SHORTENER_HOSTS) or in_domains(host, OUR_SHORTENER_DOMAINS):
                continue
            pending.append((raw, url))
        shortened_all: list[str | None] = []
        if pending:
            sem = asyncio.Semaphore(max(1, min(6, EK_MAX_CONCURRENCY)))

            async def _short(url: str) -> str | None:
                async with sem:
                    return await self.shorten(url)

            shortened_all = list(await asyncio.gather(
                *(_short(url) for _, url in pending),
                return_exceptions=True,
            ))
        replacements: dict[str, str] = {}
        for (raw, url), shortened in zip(pending, shortened_all):
            if isinstance(shortened, Exception) or not shortened:
                if isinstance(shortened, Exception):
                    log.warning("SHORTEN failed %s: %s", url[:60], shortened)
                continue
            if shortened != url:
                replacements[raw] = shortened
                # Register the new short link in link_cache so the FINAL
                # provenance gate (verify_generated_text queries affiliate_url)
                # recognises a link we just minted. self.cache_link writes to
                # the real store; tests can override it.
                with contextlib.suppress(Exception):
                    await self.cache_link(url, shortened, url, product_key(url))
                    if is_our_hypd_link(url):
                        await store.remember_owned_link_proof(shortened, url, "hypd")
        for raw, shortened in replacements.items():
            out = replace_url_everywhere(out, raw, shortened)
        if compacted or replacements:
            log.info("FINAL link tidy: %d amazon product link(s) compacted, %d shortened",
                     compacted, len(replacements))
        return out


@dataclass(frozen=True)
class LinkResult:
    source: str
    resolved: str
    affiliate: str
    deal_key: str


def distinct_affiliate_results(results: Iterable[LinkResult]) -> list[LinkResult]:
    """Keep colour/gender variants; remove only exact repeated generated URLs."""
    unique: dict[str, LinkResult] = {}
    for result in results:
        unique.setdefault(result.affiliate, result)
    return list(unique.values())

# ---------------------------------------------------------------------------
# Telegram helpers
# ---------------------------------------------------------------------------
def fetch_chat_id(entity: Any, fallback: Any = None) -> int:
    """The chat id Telethon accepts for get_messages()/send_*() for this entity."""
    try:
        return int(tl_utils.get_peer_id(entity))
    except Exception:
        return marked_chat_id(fallback if fallback is not None else entity)


async def resolve_entity(client: TelegramClient, identifier: str):
    """Resolve what the session can ALREADY reach. This function never joins.

    USER RULE (standing, pinned): "nothing auto-joins channels, no history
    replay". This used to call ImportChatInviteRequest for a t.me/+ invite, so
    merely having an invite link in the source list made the bot JOIN that
    channel - the live log showed "JOIN failed https://t.me/+-mv6..." on every
    boot for exactly that reason. Joining is the operator's decision, so the
    membership check is now read-only (`CheckChatInvite`: peeking does not join)
    and only an ALREADY-joined chat is returned. Not a member -> None, with the
    reason recorded for the dashboard.
    """
    # Telegram uses both t.me/+hash and telegram.me/+hash invite forms.
    if identifier.startswith(("https://t.me/+", "https://telegram.me/+")):
        invite_hash = identifier.split("+", 1)[1]
        with contextlib.suppress(Exception):
            invite = await client(CheckChatInviteRequest(invite_hash))
            if (type(invite).__name__ == "ChatInviteAlready"
                    and getattr(invite, "chat", None) is not None):
                return invite.chat
        log.warning("SOURCE NOT JOINED %s | the bot session is not a member of this "
                    "channel; join it yourself once with that account - the bot never "
                    "joins anything by itself", identifier)
        return None
    with contextlib.suppress(Exception):
        return await client.get_entity(identifier)
    return None


async def backfill_source(client: TelegramClient, entity, source: str) -> None:
    """Recover recent messages missed during downtime/private-source reconnects."""
    if BACKFILL_HOURS <= 0 or BACKFILL_LIMIT <= 0:
        return
    if source in TRICKS_SOURCES:
        source_hours, source_limit = 60 * 24, 5
    elif source == OZ_SOURCE:
        source_hours, source_limit = 48, max(BACKFILL_LIMIT, 50)
    elif normalize_source_name(source) in {
            normalize_source_name(s) for s in FIRST_PREFERENCE_SOURCES}:
        # A first-preference source is claimed from the queue ahead of
        # everything else, so a first connect that recovered its whole backfill
        # (50 posts x 3 channels) would fire a burst at our channels before
        # anything else could post. They are on the hot path: recover only the
        # recent tail and let live events carry the feed.
        source_hours, source_limit = BACKFILL_HOURS, max(1, int(os.getenv(
            "FIRST_PREFERENCE_BACKFILL_LIMIT", "12")))
    else:
        source_hours, source_limit = BACKFILL_HOURS, BACKFILL_LIMIT
    cutoff = datetime.now(timezone.utc).timestamp() - source_hours * 3600
    queued = 0
    # Queue under the SAME chat id the live event stream uses, otherwise the
    # (chat,msg_id) uniqueness check misses and one message is queued (and
    # posted) twice - once from backfill, once from the live update.
    chat_key = fetch_chat_id(entity, getattr(entity, "id", 0))
    try:
        messages = await client.get_messages(entity, limit=source_limit)
        for msg in reversed(messages):
            stamp = msg.date.timestamp() if getattr(msg, "date", None) else 0
            if stamp < cutoff:
                continue
            if not extract_urls(msg) and not getattr(msg, "reply_to", None):
                continue
            if await store.enqueue(chat_key, msg.id, source,
                                   (msg.message or msg.text or "")):
                queued += 1
        if queued:
            log.info("BACKFILL | source=%s candidates=%s hours=%s", source, queued, source_hours)
    except Exception as exc:
        log.warning("BACKFILL failed %s: %s", source, exc)


RESOLVED_SOURCE_IDS: dict[str, int] = {}


async def resolve_dashboard_source(client, source):
    """Resolve already-joined channels only. Never invokes Import/Join requests."""
    if "/+" in source:
        invite = await client(CheckChatInviteRequest(source.split("+", 1)[1]))
        entity = getattr(invite, "chat", None)
        if type(invite).__name__ != "ChatInviteAlready" or entity is None:
            raise ValueError("Private source: join using the bot session account, then retry")
    else:
        entity = await client.get_entity(source)
    if not getattr(entity, "broadcast", False):
        raise ValueError("Source must be a Telegram broadcast channel, not a user/group")
    participant = (await client(GetParticipantRequest(entity, "me"))).participant
    if type(participant).__name__ in {"ChannelParticipantLeft", "ChannelParticipantBanned"} or getattr(entity, "left", False):
        raise ValueError("Source access missing: join with the bot session account first")
    return entity


def dashboard_source_added(source, entity, activated):
    RESOLVED_SOURCE_IDS[source] = fetch_chat_id(entity, entity.id)
    if source not in BUILTIN_SOURCE_NAMES:
        DASHBOARD_SCOPED_SOURCES.add(source)
        SOURCE_ACTIVATED_AT.setdefault(source, activated)


def dashboard_source_categories(source, categories):
    """Apply a watched source's own category policy while the bot is running."""
    key = str(source or "").strip().lower()
    cats = [str(c).strip().lower() for c in (categories or []) if str(c).strip()]
    if cats:
        SOURCE_CATEGORY_FILTERS[key] = frozenset(cats)
    else:
        SOURCE_CATEGORY_FILTERS.pop(key, None)
    detail = SOURCE_DETAILS.get(source)
    if isinstance(detail, dict):
        detail["categories"] = cats


def source_message_is_current(source, msg):
    cutoff = SOURCE_ACTIVATED_AT.get(source, 0)
    stamp = msg.date.timestamp() if getattr(msg, "date", None) else 0
    return not cutoff or stamp >= cutoff


def scope_dashboard_targets(source, targets):
    if source not in DASHBOARD_SCOPED_SOURCES:
        return targets
    allowed = {target.lower() for target in SOURCE_TO_TARGETS.get(source, [])}
    return [target for target in targets if target.lower() in allowed]


async def register_source(client: TelegramClient, source_map: dict, source: str,
                          targets: list[str], do_backfill: bool = False, target_map=None) -> bool:
    if source in DASHBOARD_SCOPED_SOURCES:
        try:
            entity = await resolve_dashboard_source(client, source)
        except Exception as exc:
            SOURCE_DETAILS[source] = {"title": source, "state": "join_required", "detail": str(exc)[:160]}
            return False
    else:
        entity = await resolve_entity(client, source)
    if not entity:
        # Never silent: "the source posted and we received nothing" has to be
        # explainable in the dashboard, and the explanation is membership - not
        # a bug the operator has to infer from an empty channel.
        SOURCE_DETAILS.setdefault(source, {
            "title": source, "state": "join_required",
            "detail": "not reachable with the bot session: join it yourself once with "
                      "that account (the bot never joins automatically)"})
        return False
    fetch_id = fetch_chat_id(entity, getattr(entity, "id", 0))
    if source in DASHBOARD_SCOPED_SOURCES:
        aliases = {entry[0] for sid, entry in source_map.items()
                   if abs(int(sid)) in {entity.id, 1000000000000 + entity.id}}
        if ((aliases and source not in aliases)
                or any(getattr(target, "id", None) == entity.id for target in (target_map or {}).values())):
            SOURCE_DETAILS[source] = {"title": str(getattr(entity, "title", source)), "state": "blocked",
                                      "detail": "Source aliases another intake or posting destination; select the existing source"}
            return False
    # Map EVERY id convention that can arrive on an update (raw entity id,
    # Telethon's marked channel id, the plain -chat id of a legacy group). A
    # source that only matched one form silently received nothing at all.
    for key in {raw_chat_id(entity), fetch_id, int(getattr(entity, "id", 0) or 0)}:
        if key:
            source_map[key] = (source, list(targets))
    RESOLVED_SOURCE_IDS[source] = fetch_id
    SOURCE_DETAILS[source] = {"title": str(getattr(entity, "title", "") or source), "state": "ready", "checked_at": time.time()}
    if source in DASHBOARD_SCOPED_SOURCES:
        SOURCE_ACTIVATED_AT.setdefault(source, time.time())
        do_backfill = False
    log.info("SOURCE OK @%s -> %s -> %s", source, fetch_id, targets)
    if do_backfill:
        await backfill_source(client, entity, source)
    return True


async def build_maps(client: TelegramClient):
    source_map: dict[int, tuple[str, list[str]]] = {}
    target_map: dict[str, Any] = {}
    all_targets = set(MAIN_TARGETS + [UNDER99_TARGET, UNDER499_TARGET, PREMIUM_TARGET,
                                      SHOPPING_TARGET])
    all_targets.update(target for target in CATEGORY_TARGETS.values() if target)
    for targets in SOURCE_TO_TARGETS.values():
        all_targets.update(targets)
    for target in sorted(all_targets):
        entity = await resolve_entity(client, target)
        if entity:
            target_map[target] = entity
            log.info("TARGET OK @%s -> %s", target, entity.id)
        else:
            log.error("TARGET FAIL @%s", target)
    for source, targets in SOURCE_TO_TARGETS.items():
        if not await register_source(client, source_map, source, targets, do_backfill=True, target_map=target_map):
            log.error("SOURCE FAIL @%s", source)
        await asyncio.sleep(0.08)
    return source_map, target_map


async def maintenance_loop(stop: asyncio.Event) -> None:
    while not stop.is_set():
        try:
            stats = await store.maintenance()
            removed_media = 0
            cutoff = time.time() - 6 * 3600
            for item in MEDIA_DIR.iterdir():
                with contextlib.suppress(OSError):
                    if item.is_file() and item.stat().st_mtime < cutoff:
                        item.unlink()
                        removed_media += 1
            log.info("MAINTENANCE | queue=%s deliveries=%s cache=%s media=%s",
                     stats["queue"], stats["deliveries"], stats["cache"], removed_media)
            await asyncio.wait_for(stop.wait(), timeout=MAINTENANCE_SECONDS)
        except asyncio.TimeoutError:
            continue
        except Exception as exc:
            log.warning("MAINTENANCE failed: %s", exc)
            try:
                await asyncio.wait_for(stop.wait(), timeout=3600)
            except asyncio.TimeoutError:
                continue


async def refresh_missing_sources(client: TelegramClient, source_map: dict,
                                  stop: asyncio.Event, target_map=None) -> None:
    """Periodically recover private/invite sources that failed during startup."""
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), timeout=SOURCE_REFRESH_SECONDS)
            break
        except asyncio.TimeoutError:
            pass
        mapped = {entry[0] for entry in source_map.values()}
        missing = [(source, targets) for source, targets in SOURCE_TO_TARGETS.items()
                   if source not in mapped]
        for source, targets in missing:
            if await register_source(client, source_map, source, targets, do_backfill=True, target_map=target_map):
                log.info("SOURCE RECOVERED @%s", source)
            else:
                log.warning("SOURCE STILL UNAVAILABLE @%s", source)
            await asyncio.sleep(0.2)


async def source_rescan_loop(client: TelegramClient, source_map: dict,
                             stop: asyncio.Event) -> None:
    """Never-stall safety net for ingest, reclaims and stale work.

    Ingest is event-based; if the Telethon session degrades (network flap, DC
    switch, stale auth) the events silently stop while the process stays up -
    refresh_missing_sources does not help because the sources are still mapped.
    This loop therefore, every SOURCE_RESCAN_SECONDS:

      1. reclaims jobs orphaned in 'processing' (task killed mid-await),
      2. drops pending work older than MAX_JOB_AGE_HOURS (dead loot is never
         posted late), and
      3. re-scans every live source's recent messages and enqueues anything
         new (the queue dedups on the canonical (chat_key,msg_id) index, so
         re-seeing a post is free and can never create a second post).

    Sources are scanned CONCURRENTLY so a 20-source list costs one short round
    trip instead of minutes, which is what makes a recovered deal go out
    seconds after the cycle rather than a quarter of an hour later.

    NOTE: LAST_INGEST_AT is deliberately NOT refreshed here - it measures the
    live event stream, so INGEST SILENCE keeps reporting a degraded session.
    """
    sem = asyncio.Semaphore(max(1, SOURCE_RESCAN_CONCURRENCY))
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), timeout=max(0.5, SOURCE_RESCAN_SECONDS))
            break
        except asyncio.TimeoutError:
            pass
        try:
            reclaimed = await store.reclaim_stuck_jobs()
            if reclaimed:
                log.warning("RECLAIMED | %s stuck processing job(s) returned to the queue", reclaimed)
        except Exception as exc:
            log.warning("RECLAIM failed: %s", exc)
        with contextlib.suppress(Exception):
            await store.drop_stale_jobs()
        # Scan window: at least two cycles plus slack, so a slipped cycle can
        # never leave an uncovered gap. Re-seeing a post is free (dedup).
        window_start = time.time() - (SOURCE_RESCAN_SECONDS * 2 + 180)
        items: list[tuple[str, int]] = []
        seen: set[str] = set()
        for chat_id, (source, _targets) in list(source_map.items()):
            if source in seen:
                continue
            fetch_id = RESOLVED_SOURCE_IDS.get(source)
            if not fetch_id and str(chat_id).startswith("-100"):
                fetch_id = chat_id
            if not fetch_id:
                continue
            seen.add(source)
            items.append((source, int(fetch_id)))

        async def scan_one(source: str, chat_id: int) -> int:
            recovered = 0
            try:
                async with sem:
                    messages = await client.get_messages(chat_id, limit=SOURCE_RESCAN_LIMIT)
                for msg in reversed(messages or []):
                    stamp = msg.date.timestamp() if getattr(msg, "date", None) else 0
                    if stamp < window_start or not source_message_is_current(source, msg):
                        continue
                    # Cheap pre-filter: a message already in the queue never even
                    # reaches the fingerprint/normalisation work in enqueue.
                    if await store.seen_message(chat_id, msg.id):
                        continue
                    raw = (msg.message or msg.text or "") if msg is not None else ""
                    has_media = bool(
                        msg is not None and msg.media is not None
                        and not isinstance(msg.media, (MessageMediaWebPage, MessageMediaInvoice))
                    )
                    if not extract_urls(msg) and not has_media and not getattr(msg, "reply_to", None):
                        continue
                    if await store.enqueue(chat_id, msg.id, source, raw, has_media):
                        recovered += 1
                        log.info("RECOVERED | source=%s msg=%s (event stream gap)", source, msg.id)
            except Exception as exc:
                log.warning("RESCAN failed source=%s: %s", source, exc)
            return recovered

        results = await asyncio.gather(
            *(scan_one(source, chat_id) for source, chat_id in items),
            return_exceptions=True,
        ) if items else []
        recovered_total = sum(r for r in results if isinstance(r, int))
        silence_min = (time.time() - LAST_INGEST_AT) / 60
        if silence_min >= 30:
            log.warning(
                "INGEST SILENCE | no source events for %.0f min; the %ss rescan keeps deals flowing",
                silence_min, int(SOURCE_RESCAN_SECONDS),
            )
        if recovered_total:
            log.info("RESCAN | cycle=%ss limit=%s recovered=%s sources=%s",
                     int(SOURCE_RESCAN_SECONDS), SOURCE_RESCAN_LIMIT, recovered_total, len(items))


def media_is_too_large(msg) -> bool:
    """True when the source media would tie up a worker longer than it is worth."""
    limit = int(MAX_MEDIA_MB * 1024 * 1024)
    if limit <= 0:
        return False
    media = getattr(msg, "media", None)
    if media is None:
        return False
    sizes: list[int] = []
    for name in ("video", "document", "voice", "round_message", "sticker", "gif", "file"):
        item = getattr(media, name, None)
        if item is not None:
            with contextlib.suppress(Exception):
                sizes.append(int(getattr(item, "size", 0) or 0))
    with contextlib.suppress(Exception):
        photo_sizes = getattr(media, "sizes", None) or []
        sizes.append(max((int(getattr(p, "size", 0) or 0) for p in photo_sizes), default=0))
    sizes = [size for size in sizes if size > 0]
    return bool(sizes) and max(sizes) > limit


def media_list(media) -> list[str]:
    """One path, a list of paths or nothing - all three arrive here; deliver as a list."""
    if not media:
        return []
    if isinstance(media, (list, tuple)):
        return [str(x) for x in media if x]
    return [str(media)]


async def album_messages(client, msg) -> list:
    """Every message of the source album, in the order the source posted them.

    A loot channel sending six product photos does NOT send six posts: it sends one
    album, and Telethon exposes the siblings through `grouped_id`. A client or a message
    without that support is just [msg], so a normal single-photo post keeps the exact
    code path it always had.
    """
    primary = [msg]
    if not getattr(msg, "grouped_id", None):
        return primary
    try:
        siblings = list(await msg.get_grouped_items())
    except Exception as exc:  # noqa: BLE001 - a missing lookup must never lose the post
        log.info("ALBUM | sibling lookup failed (%s); posting the photo we have", exc)
        return primary
    photos = [m for m in siblings if getattr(m, "photo", None) is not None]
    photos.sort(key=lambda m: getattr(m, "id", 0) or 0)
    if not photos:
        return primary
    if not any(getattr(m, "id", None) == getattr(msg, "id", None) for m in photos):
        photos.insert(0, msg)
    return photos[:max(1, MAX_ALBUM_PHOTOS)]


async def download_album(client, msg, base_target, queue_id) -> tuple[list[str], list]:
    """Download the album's photos with the same per-file budget as a single photo, and
    keep each photo's Telegram reference.

    A photo that is slow or missing is LEFT OUT rather than stalling the deal: six
    images are nicer than one, but a deal that goes out late is no deal at all. The
    references are what let the target post go out as one grid without re-uploading a
    single byte, which is the difference between "posted now" and "posted after six
    uploads".
    """
    paths: list[str] = []
    refs: list = []
    for index, item in enumerate(await album_messages(client, msg)):
        target = base_target if index == 0 else Path(f"{base_target}_{index}")
        try:
            saved = await asyncio.wait_for(
                client.download_media(item, file=str(target)),
                timeout=MEDIA_DOWNLOAD_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            log.warning("MEDIA SLOW | queue=%s album item %s exceeded %ss; posting the rest",
                        queue_id, index, int(MEDIA_DOWNLOAD_TIMEOUT_SECONDS))
            saved = None
        except Exception as exc:  # noqa: BLE001 - never fail a post over one image
            log.warning("MEDIA FAILED | queue=%s album item %s: %s", queue_id, index, exc)
            saved = None
        if saved:
            paths.append(str(saved))
            refs.append(getattr(item, "photo", None))
    return paths, refs


def _random_id() -> int:
    import random
    return random.randrange(1, 2 ** 63)


async def send_media_group(client, entity, caption: str, paths: list[str], refs: list) -> bool:
    """Post the photos as ONE album - the grid a source channel's post shows.

    Telethon 1.44 has no `send_media_group` helper, so the raw `SendMultiMediaRequest`
    is used. When the source photo references are still usable nothing is uploaded at
    all; otherwise each file is uploaded first. False means preparation failed
    BEFORE publication, so individual-file fallback is safe. A publication error
    propagates: it may hide an accepted album and must never trigger fallback.
    """
    try:
        from telethon import functions, types as tl_types
        medias: list = []
        if refs and len(refs) == len(paths) and all(ref is not None for ref in refs):
            medias = [tl_types.InputMediaPhoto(id=ref) for ref in refs]
        else:
            peer = await client.get_input_entity(entity)
            for path in paths:
                handle = await client.upload_file(path)
                uploaded = await client(functions.messages.UploadMediaRequest(
                    peer, media=tl_types.InputMediaUploadedPhoto(file=handle)))
                photo = getattr(getattr(uploaded, "media", None), "photo", None)
                if photo is None:
                    return False
                medias.append(tl_types.InputMediaPhoto(id=photo))
    except Exception as exc:  # preparation only: no publication RPC was issued
        log.warning("ALBUM | preparation failed (%s); using individual photos", exc)
        return False
    # Never fall back after this call: a lost response can hide a successful
    # album publication. deliver() holds ambiguous outcomes for review.
    await client(functions.messages.SendMultiMediaRequest(
        entity,
        multi_media=[tl_types.InputSingleMedia(
            media=media, message=caption if index == 0 else "", random_id=_random_id())
            for index, media in enumerate(medias)],
    ))
    return True


async def send_media_item(client, entity, media, caption: str, refs: list | None = None,
                          buttons: list | None = None) -> None:
    """One photo with its caption, or the whole album as one grid, with real fallbacks.

    If the grid cannot be sent, the first photo goes out with the caption - exactly what
    the bot always did - and the remaining photos follow as their own messages, so the
    reader still gets every image the source posted. `buttons` rides only on sends that
    carry the caption: an album's raw multi-media request keeps today's shape until its
    markup path is covered by tests.
    """
    paths = media_list(media)
    if len(paths) <= 1:
        await client.send_file(entity, paths[0] if paths else None, caption=caption,
                               parse_mode=None, buttons=buttons or None)
        return
    if await send_media_group(client, entity, caption, paths, list(refs or [])):
        return
    await client.send_file(entity, paths[0], caption=caption, parse_mode=None,
                           buttons=buttons or None)
    for extra in paths[1:]:
        with contextlib.suppress(Exception):
            await client.send_file(entity, extra, parse_mode=None)


def post_inline_buttons():
    """The dashboard-configured URL button row, ready for Telethon, or [].

    Telegram draws inline URL buttons below the message - the "Join … ❤️" row a
    big channel ends every post with. Empty config (the default, and every
    deployment until an operator saves buttons) returns [], and `deliver` then
    passes buttons=None, so nothing about today's posts changes. WhatsApp has no
    inline buttons, so this is a Telegram-only surface.
    """
    try:
        import post_buttons
    except ImportError:  # imported as bestgaa.main_bot_new
        from bestgaa import post_buttons
    rows = post_buttons.load_buttons()
    if not rows:
        return []
    from telethon import Button
    # `entry`, not `row`: these are config dicts, and the pipeline suite audits
    # every row["…"] read against the SQL table it came from.
    return [[Button.url(entry["label"], entry["url"])] for entry in rows]


def channel_header_line() -> str:
    return f"\U0001f449 All Loot Channels: {OUR_FOLDER_LINK}"


def keep_source_spacing(text: str, raw_text: str) -> str:
    """Layout is part of "exactly like the source", so a blank line WE created goes.

    A line our own passes deleted - a foreign channel's share button, a stripped CTA
    clause, a link cut because it never resolved - used to stay behind as an empty line,
    and subscribers read that as the bot adding space that the source never wrote. If the
    source had no blank line, neither does our copy; where the source DID space its blocks
    apart, that spacing is the source's own and is kept exactly as it was.
    """
    if not text or not raw_text:
        # No source text to compare against (an older queue row) means no licence to
        # re-flow anything: leave the layout exactly as the renderer wrote it.
        return text
    if "\n\n" in raw_text:
        return text
    return re.sub(r"\n{2,}", "\n", text)


def prepend_channel_header(text: str) -> str:
    """The one-line family link on top, never a second time, never on a post that
    already carries it. Nothing else is added: the deal text below stays the source's."""
    body = (text or "").strip("\n")
    if OUR_FOLDER_LINK in body:
        return body
    return f"{channel_header_line()}\n{body}" if body else channel_header_line()


def outbound_parts(text: str, media_path: str | None) -> list[tuple[str, str]]:
    """Build deterministic chunks so a retry can resume after the last sent part."""
    if media_list(media_path):
        caption_parts = chunks(text, 1024)
        parts: list[tuple[str, str]] = [("file", caption_parts[0])]
        remainder = "\n".join(caption_parts[1:]).strip()
        parts.extend(("message", part) for part in (chunks(remainder, 4096) if remainder else []))
        return parts
    return [("message", part) for part in chunks(text, 4096)]


class AmbiguousDelivery(Exception):
    """The remote send may have succeeded: never automatically send it again."""


async def deliver(client, entity, text: str, media_path: str | None, start_chunk: int = 0,
                  progress_callback=None, link_preview: bool = True,
                  media_refs: list | None = None, attempt_callback=None) -> tuple[bool, str]:
    # LAST GATE: markdown debris, glued random tokens and empty bullet lines are
    # removed here - after cleaning, after shortening, after chunking decisions -
    # so whatever produced them can never reach a subscriber's screen.
    parts = outbound_parts(sanitize_outbound_text(text), media_path)
    if attempt_callback:
        # Media disappearing or changed target formatting must not shift chunk
        # boundaries on resume. Freeze the complete layout before publication.
        plan_hash = hashlib.sha256(json.dumps(parts, ensure_ascii=False).encode()).hexdigest()
        await attempt_callback(-1, plan_hash, "plan")
    if start_chunk > len(parts):
        return False, "invalid chunk checkpoint"
    # The button row opens the post, exactly once: the first message actually sent
    # (which is the photo when there is one). A resumed job puts it on the message
    # that resumes, so a post never shows zero rows because of a retry.
    button_row = post_inline_buttons() or None
    for index in range(start_chunk, len(parts)):
        kind, content = parts[index]
        chunk_buttons = button_row if index == start_chunk else None
        sent = False
        last_error = "unknown send failure"
        payload_hash = hashlib.sha256((kind + "\n" + content).encode()).hexdigest()
        for attempt in range(POST_RETRIES):
            if attempt_callback:
                if not await attempt_callback(index, payload_hash, "started"):
                    sent = True  # a durable success from an earlier worker/pass
                    break
            try:
                if kind == "file":
                    await send_media_item(client, entity, media_path, content, media_refs,
                                          chunk_buttons)
                else:
                    await client.send_message(
                        entity, content, parse_mode=None, link_preview=link_preview,
                        buttons=chunk_buttons
                    )
            except FloodWaitError as exc:
                if attempt_callback:
                    await attempt_callback(index, payload_hash, "rejected")
                # A Telegram rate-limit. Never let a very long flood (hours /
                # an account soft-ban) freeze a worker for that long — cap the
                # in-loop wait, log it loudly, and let the job fall through as
                # a retryable failure (fail_job backs off; the other workers
                # keep posting; the never-die loop + Restart=always stay alive).
                wait = min(int(getattr(exc, "seconds", 60) or 60), 300)
                log.warning("FLOOD WAIT | target=%s seconds=%s (capped sleep=%s) "
                            "— a long flood means Telegram is rate-limiting the "
                            "account; posting resumes automatically.",
                            getattr(entity, "id", entity), getattr(exc, "seconds", 60), wait)
                await asyncio.sleep(wait + 2)
                continue
            except (ChannelPrivateError, ChatAdminRequiredError) as exc:
                if attempt_callback:
                    await attempt_callback(index, payload_hash, "rejected")
                return False, str(exc)
            except Exception as exc:
                if attempt_callback:
                    with contextlib.suppress(Exception):
                        await attempt_callback(index, payload_hash, "uncertain")
                raise AmbiguousDelivery(f"send outcome unknown ({type(exc).__name__}); no automatic retry") from exc
            if attempt_callback:
                try:
                    await attempt_callback(index, payload_hash, "sent")
                except Exception as exc:
                    raise AmbiguousDelivery("send accepted but durable receipt failed; no automatic retry") from exc
            sent = True
            break
        if not sent:
            return False, last_error
        # The chunk is OUT on Telegram. The checkpoint below records that fact -
        # and it lives OUTSIDE the retry loop on purpose. It used to sit inside
        # it, so a ledger write that threw (a locked/busy database during a
        # VACUUM, a checkpoint, or an overlapping writer right after a deploy)
        # retried the TELEGRAM send instead of the write: one queue went out up
        # to POST_RETRIES (3) times to the same targets (2026-10-11 repeats).
        # A failed checkpoint is now logged loudly and the post continues; the
        # ledger write itself already retries inside Store. Re-sending an
        # already-sent chunk is never the answer to a bookkeeping failure.
        # Production also writes a durable send intent before the network call;
        # an ambiguous result or failed receipt write is held, never retried.
        if progress_callback:
            try:
                await progress_callback(index + 1)
            except Exception as exc:  # noqa: BLE001 - bookkeeping must never resend
                log.error("CHECKPOINT FAILED | chunk %s/%s reached Telegram but the "
                          "ledger write failed (%s); continuing without resend - "
                          "a later resume may re-check this target",
                          index + 1, len(parts), exc)
    return True, ""

# ---------------------------------------------------------------------------
# Worker pipeline
# ---------------------------------------------------------------------------
class StoredSourceMessage:
    """Stand-in for a source message Telegram will not hand back.

    A loot channel deletes or re-posts some of its own messages within seconds. Until
    now that killed the deal HERE: render_job refused to render without the live message,
    the job burned JOB_MAX_ATTEMPTS on a message that was never coming back, and a post
    intake had already received in full disappeared - the one thing the pipeline is not
    allowed to do. Intake keeps the text it was given (`queue.source_text`), so the post
    is now rendered from our own copy of it.

    Nothing is invented for the media: those photos really are gone, so `.media` stays
    None and every media branch of the pipeline remains exactly as unreachable as the
    message itself. The deal text, its links and its layout all survive.
    """

    def __init__(self, text: str, chat_id: int, msg_id: int, date):
        self.id = msg_id
        self.chat_id = chat_id
        self.text = text
        self.message = text
        self.entities: list = []
        self.reply_markup = None
        self.reply_to = None
        self.media = None
        self.photo = None
        self.document = None
        self.grouped_id = None
        # `.date` is a datetime everywhere else in the pipeline (backfill and rescan both
        # call msg.date.timestamp()), so hand back the intake timestamp as one rather than
        # a bare float that would only work as long as nobody reads it.
        self.date = (datetime.fromtimestamp(date, tz=timezone.utc)
                     if isinstance(date, (int, float)) and date else date)


async def render_job(client, affiliate: AffiliateClient, row: sqlite3.Row):
    # v18.3: whether the source message is still fetchable decides media and entities,
    # never WHETHER the post exists. A row whose own copy of the text is intact renders.
    stored_copy = (row["source_text"] if "source_text" in row.keys() else "") or ""
    fetch_error = None
    try:
        msg = await client.get_messages(row["chat_id"], ids=row["msg_id"])
    except Exception as exc:  # noqa: BLE001 - judged below, never swallowed here
        fetch_error, msg = exc, None
    if not msg:
        transient = isinstance(fetch_error, (FloodWaitError, ConnectionError, TimeoutError,
                                             asyncio.TimeoutError, OSError))
        # A rate limit or a broken connection says nothing about the post, and the photos
        # may still be there one retry later - so keep trying while the job has attempts
        # left, and only then fall back to the copy without media. A message that simply
        # is not there any more (Telegram returned nothing) is never coming back, so that
        # one renders from our own copy immediately.
        if transient and int(row["attempts"] or 0) + 1 < JOB_MAX_ATTEMPTS:
            raise fetch_error
        if stored_copy.strip():
            log.warning(
                "SOURCE MESSAGE GONE | queue=%s chat=%s msg=%s - rendering from the copy "
                "intake kept (%s chars); that message's media cannot be re-attached%s",
                row["id"], row["chat_id"], row["msg_id"], len(stored_copy),
                f" (fetch raised {type(fetch_error).__name__})" if fetch_error is not None else "")
            msg = StoredSourceMessage(stored_copy, row["chat_id"], row["msg_id"], row["created_at"])
        elif fetch_error is not None:
            raise fetch_error          # nothing stored to fall back on: retry like before
        else:
            # Nothing fetched AND nothing stored (a row written by an older build):
            # still a retryable failure, not a silent drop.
            raise RuntimeError("source message no longer available")
    # IMPORTANT: Telegram entity offsets refer to the ORIGINAL text. Never run
    # footer/branding cleanup before rebuilding entities, otherwise offsets shift
    # and fragments such as `uy` / `tps://` get glued to the affiliate URL.
    # msg.message is that original text; msg.text re-renders it through the
    # client's parse mode and INSERTS markdown marks ("**bold**"), shifting every
    # offset after them - which is how "BUY - <link>" was published as "BUJYEi".
    raw_text = msg.message or msg.text or ""
    text = clean_source_text(raw_text)
    source_urls = extract_urls(msg)
    # Reply-only deal support.
    reply_to = getattr(msg, "reply_to", None)
    if reply_to and getattr(reply_to, "reply_to_msg_id", None):
        with contextlib.suppress(Exception):
            replied = await client.get_messages(row["chat_id"], ids=reply_to.reply_to_msg_id)
            if replied:
                for url in extract_urls(replied):
                    if url not in source_urls:
                        source_urls.append(url)
    has_merchant_candidate = any(
        not in_domains((urlparse(url).hostname or "").lower(), NON_STORE_DOMAINS)
        for url in source_urls
    )
    msg_media = getattr(msg, "media", None)
    has_media_now = bool(msg_media) and not isinstance(
        msg_media, (MessageMediaWebPage, MessageMediaInvoice))
    # Only a post that shows the deal (a photo/video of it) AND states real deal terms
    # qualifies. A caption with no price, no discount and no card/service offer is a
    # screenshot, not a deal - publishing that is exactly the "unwanted text" the user
    # forbids, so it keeps the skip it always had.
    # USER REPORT (2026-09-06): "ilaga link pamplkudnaa just names vasthunndi" -
    # posts like "Cello Feast Deluxe Kids Lunch Box @264 / Apply 31% Off Coupon"
    # went out as a NAME AND A PRICE WITH NOTHING TO TAP. The link-free path was
    # built for a photo whose picture IS the product; it was never meant to carry
    # a shopping LIST. A post that names two or more priced products but offers
    # no link is a broken post, not a deal - the reader cannot buy any of it. So
    # the allowance is now limited to a SINGLE product; a multi-product list with
    # no link is skipped and retried instead of published half-dead.
    _priced_lines = [ln for ln in (text or "").splitlines()
                     if parse_price(ln) is not None and re.search(r"[A-Za-z]{3}", ln)]
    link_free_candidate = (not source_urls or not has_merchant_candidate) and has_media_now and (
        parse_price(text) is not None or parse_discount(text) is not None
        or has_card_offer(text) or has_service_offer(text)) and len(_priced_lines) < 2
    had_social_promo = bool(TRICK_PROMO_LINK_RE.search(raw_text)) or any(
        in_domains((urlparse(url).hostname or "").lower(), NON_STORE_DOMAINS)
        for url in source_urls
    )
    # Any source-only Telegram/WhatsApp advertisement is rewritten to our own
    # folder/main-channel promo and routed to Tricks; foreign join links never survive.
    if had_social_promo and not has_merchant_candidate:
        return await render_trick_promo(row, msg, raw_text)

    # Legacy-only path: photo-only products may be posted without inventing a link,
    # but strict-all requires a verified commission link and disables this exception.
    # The legacy renderer still supports a photo-only post, but strict-all may
    # publish only an item whose link itself proves our commission attribution.
    link_free_post = bool(link_free_candidate) and not STRICT_OUR_LINKS
    if not source_urls and not link_free_post:
        raise PermanentSkip("no URLs")

    # Resolve first so social/footer URLs do not inflate the 2+ Bitly threshold.
    # Every remaining merchant candidate is atomic: if even one cannot be freshly
    # converted, the whole post is retried/skipped rather than posting a partial deal.
    # Every source shortener is expanded CONCURRENTLY: a mega list used to pay
    # one 18s hop chain per link, serially, before anything could be posted.
    candidates: list[tuple[str, str]] = []
    resolved_list = (await asyncio.gather(
        *(affiliate.resolve(url) for url in source_urls), return_exceptions=True
    )) if source_urls else []
    for source_url, resolved in zip(source_urls, resolved_list):
        if isinstance(resolved, BaseException):
            log.warning("RESOLVE failed %s: %s", source_url[:60], resolved)
            resolved = source_url
        host = (urlparse(str(resolved)).hostname or "").lower()
        if is_share_intent(resolved) or in_domains(host, NON_STORE_DOMAINS):
            # A share button in the source text is content, not a destination: it is
            # left in the post (minus the cleaning that already handles it) but it can
            # never hold up or cancel the deal next to it.
            continue
        candidates.append((source_url, str(resolved)))
    if not candidates and not link_free_post:
        raise PermanentSkip("no monetizable URLs")

    # Service/lifestyle offers (Zomato, Swiggy, Zepto, movies, payment-app and
    # card offers) are not affiliate products. Keep their classification separate
    # from store conversion, then strict-all below refuses the post instead of
    # passing through an unmonetized service URL.
    service_pairs: list[tuple[str, str]] = []
    store_candidates: list[tuple[str, str]] = []
    for source_url, resolved in candidates:
        host = (urlparse(resolved).hostname or "").lower()
        if in_domains(host, SERVICE_OFFER_DOMAINS):
            clean_resolved = clean_url(resolved)
            if clean_resolved not in {r for _, r in service_pairs}:
                service_pairs.append((source_url, clean_resolved))
        else:
            store_candidates.append((source_url, resolved))
    if STRICT_OUR_LINKS and service_pairs:
        raise PermanentSkip("service/non-affiliate URLs are not owned monetized links")
    if not store_candidates and not service_pairs and not link_free_post:
        raise PermanentSkip("no monetizable URLs")

    multi_link = len(store_candidates) >= 2
    # Conversion is the slow step (shortener hops + EarnKaro + health checks),
    # so a multi-link post converts every product at once. EK_SEM still caps the
    # pressure on the API and `converted` keeps source order.
    converted: list[LinkResult] = []
    transient_errors: list[str] = []
    convert_results = (await asyncio.gather(
        *(affiliate.convert(url, multi_link, resolved) for url, resolved in store_candidates),
        return_exceptions=True,
    )) if store_candidates else []
    # A completed conversion with no output means this account cannot monetize
    # the URL; strict-all records it as unsupported and skips the post. The old
    # clean-merchant fallback remains unreachable in production and exists only
    # for isolated legacy-renderer tests.
    passthrough: list[tuple[str, str]] = []

    def keep_passthrough(source_url: str, resolved: str) -> None:
        if STRICT_OUR_LINKS or not PASSTHROUGH_UNMONETIZED:
            return
        host = (urlparse(str(resolved or "")).hostname or "").lower()
        # Subdomain-aware (www.myntra.com must count as myntra.com).
        if not host or not in_domains(host, KNOWN_MERCHANT_DOMAINS):
            return
        if is_amazon_short_host(host):
            # Defensive: a passthrough never publishes an Amazon SHORT link. The
            # short code is somebody's wrapper (see is_amazon_short_host) - our tag
            # on it earns nothing and the reader lands on THEIR page.
            log.warning("AMAZON SHORT REFUSED | queue=%s %s is a wrapper, not a "
                        "destination; it is never posted as-is", row["id"], host)
            return
        clean_resolved = clean_url(merchant_url(resolved))
        # USER REPORT (2026-10-04): the bare merchant page opens the product and
        # pays NOBODY. Where the network's own attribution works on a plain
        # product page (Flipkart family -> affExtParam2, the same parameter the
        # converter puts on the links it returns for our account), publish it
        # WITH our publisher id; a foreign id on the source page is replaced,
        # never carried along.
        published = attribute_with_our_publisher(clean_resolved)
        if not published or published in {clean_url(r) for _, r in passthrough}:
            return
        passthrough.append((source_url, published))
        if published != clean_resolved:
            log.warning("LINK ATTRIBUTED | queue=%s no campaign came back, so the product "
                        "page is posted WITH our publisher id (%s) instead of a bare link "
                        "that pays nobody: %s", row["id"], OUR_EK_ID, published[:80])
            log.info("PASSTHROUGH | queue=%s attributed merchant link: %s",
                     row["id"], published[:80])
            return
        # USER RULE (2026-09-05, "idi manvena?" / "mana links matharem"): a
        # passthrough link is a CLEAN merchant link, not a monetized link of
        # ours - the deal still goes out (that is the point), but it must be
        # obvious in the log which posts earn nothing, instead of quietly
        # looking like every other post. WARNING, not INFO, so an operator
        # grepping the log can actually find them.
        log.warning("UNMONETIZED LINK | queue=%s this deal posts a plain merchant "
                    "link (the affiliate network had no campaign for it): %s",
                    row["id"], clean_resolved[:70])
        log.info("PASSTHROUGH | queue=%s unmonetizable link kept clean: %s",
                 row["id"], clean_resolved[:70])

    unresolvable: list[str] = []
    for (source_url, resolved), result in zip(store_candidates, convert_results):
        if isinstance(result, BaseException):
            transient_errors.append(str(result))
            log.warning("CONVERT failed %s: %s", source_url[:60], result)
        elif result:
            if STRICT_OUR_LINKS:
                generated_url = clean_url(result.affiliate)
                generated_host = (urlparse(generated_url).hostname or "").lower()
                hidden_amazon = (getattr(affiliate, "_short_to_long", {}) or {}).get(generated_url, "")
                hidden_host = (urlparse(clean_url(hidden_amazon)).hostname or "").lower()
                amazon_link_is_ours = (
                    not is_amazon_short_host(generated_host)
                    and (not in_domains(generated_host, AMAZON_DOMAINS)
                         or Store.is_our_amazon_tag_link(generated_url))
                    and (not in_domains(hidden_host, AMAZON_DOMAINS)
                         or Store.is_our_amazon_tag_link(hidden_amazon))
                )
                if not amazon_link_is_ours:
                    unresolvable.append(source_url)
                    log.warning("OWN-LINK SKIP | queue=%s Amazon output lacks our Associates "
                                "tag/provenance: %s", row["id"], generated_url[:80])
                    continue
            converted.append(result)
        else:
            resolved_host = (urlparse(resolved).hostname or "").lower()
            before = len(passthrough)
            keep_passthrough(source_url, resolved)
            if len(passthrough) > before:
                continue
            if STRICT_OUR_LINKS:
                # A completed conversion response with no affiliate URL is not
                # ours. Treat it as unsupported and fail closed immediately;
                # only exceptions above use retry/backoff for a transient API.
                unresolvable.append(source_url)
                log.warning("OWN-LINK SKIP | queue=%s converter returned no paid link for %s",
                            row["id"], resolved_host or source_url[:70])
                continue
            if (in_domains(resolved_host, NON_SHOP_DOMAINS)
                    or (is_unresolvable_short_link(resolved_host, source_url)
                        and clean_url(source_url) == clean_url(str(resolved or "")))):
                # Nothing to monetize and nothing to retry: a non-shop (a deal blog or
                # an app-deep-link wrapper) or a short link that never resolved. The
                # ONLY reason the whole deal used to disappear for a "₹85 https://…"
                # post was the retry loop. Cut the link, keep the post.
                unresolvable.append(source_url)
                log.warning("LINK DROPPED | queue=%s link never monetizes (%s), posting "
                            "the deal without it: %s", row["id"], resolved_host, source_url[:70])
                continue
            # Unknown destination: never publish an unvetted domain, retry.
            transient_errors.append(
                f"affiliate conversion returned no link: {resolved_host or 'unknown'}"
            )
    if transient_errors and row["attempts"] + 1 < JOB_MAX_ATTEMPTS:
        # A temporary API/Bitly/network failure retries before making a decision.
        raise RuntimeError("conversion retry required: " + "; ".join(transient_errors[:3]))
    if transient_errors and STRICT_OUR_LINKS:
        raise PermanentSkip("affiliate conversion did not verify an owned link")
    if transient_errors:
        # Legacy-only mode: final attempt may use a clean merchant fallback.
        already = {clean_url(r.source) for r in converted}
        log.warning("DEGRADED POST | queue=%s attempt=%s %s link(s) unresolved: %s",
                    row["id"], row["attempts"] + 1, len(transient_errors),
                    "; ".join(transient_errors[:2])[:180])
        for source_url, resolved in store_candidates:
            if clean_url(source_url) not in already:
                keep_passthrough(source_url, resolved)
    if STRICT_OUR_LINKS and unresolvable:
        raise PermanentSkip("source link is dead, unknown, or not monetized by us")
    if (not converted and not service_pairs and not passthrough
            and not unresolvable and not link_free_post):
        raise PermanentSkip("no monetizable URLs")

    # Preserve distinct variant links (colour/gender/size/category filters) inside
    # one source post. Collapse only an exact repeated generated URL. Product-key
    # reservation still provides global 24-hour dedup across source channels.
    converted = distinct_affiliate_results(converted)
    if STRICT_OUR_LINKS and converted:
        # POST-DEPLOY RULE (2026-10-11): no trustworthy product identity, no
        # post. Every converted item must name its merchant product id on the
        # verified merchant page (or on the verified affiliate destination our
        # converter produced for it). A search/category/offer page and an
        # opaque shortener URL carry no identity: posting one risks repeating a
        # product the channels already saw - or mis-attaching a price to the
        # wrong product - and dropping just the item would orphan its
        # name/price lines. So the post is skipped as a unit, like any other
        # unverified strict-all item. Nothing is invented to fill the gap: no
        # guessed name, no merchant-page fetch, no URL-hash identity.
        for result in converted:
            if not verified_product_id(result.resolved, result.affiliate):
                host = (urlparse(clean_url(result.resolved or "")).hostname or "?").lower()
                raise PermanentSkip(
                    "no trustworthy product identity for %s - skipping rather "
                    "than risking a mis-posted duplicate" % host)
    keys = list(dict.fromkeys(
        [product_key(resolved) for _, resolved in service_pairs]
        + [product_key(resolved) for _, resolved in passthrough]
        + [r.deal_key for r in converted]
    ))
    has_identity = any(not key.startswith("URL:") for key in keys)
    price = parse_price(text)
    content_key = content_deal_key(text)
    ok, new_keys = await store.reserve(
        row["id"], keys, price, has_identity, content_key=content_key
    )
    if not ok:
        raise DuplicateDeal("duplicate deal")
    allowed = {key for key in new_keys}
    # USER RULE (2026-09-06): an item of a list whose product was already
    # posted DROPS WHOLE - name, price and link together. The old behaviour
    # kept the item's label line and emitted its raw source link, so the
    # "fresh" list still advertised a deal the channels had already seen,
    # with an unmonetized link under it.
    dedup_dropped = [r for r in converted if r.deal_key not in allowed]
    for dropped in dedup_dropped:
        log.warning("DEDUP DROP | queue=%s list item already posted, dropped whole: %s",
                    row["id"], clean_url(dropped.source)[:70])
    converted = [r for r in converted if r.deal_key in allowed]
    passthrough = [(s, r) for s, r in passthrough if product_key(r) in allowed]
    # Service-only posts have an empty `converted` by design (their links are
    # pass-through, already reserved via their product keys above) — only a
    # STORE-only post can be fully duplicated this way.
    if (not converted and not service_pairs and not passthrough
            and not unresolvable and not link_free_post):
        raise DuplicateDeal("all products already posted")

    mapping = {clean_url(r.source): r.affiliate for r in converted}
    # Visible product lists are rebuilt directly by source order so each label
    # keeps its own link. Fall back to entity-aware replacement for mixed/hidden posts.
    # The already-posted items' source URLs ride along as drop_urls, so the
    # rebuild removes those items whole instead of printing their raw link.
    drop_urls = frozenset(clean_url(r.source) for r in dedup_dropped)
    rendered = format_visible_source_product_pairs(raw_text, mapping, drop_urls)
    if rendered is None:
        rendered = rebuild_text(raw_text, getattr(msg, "entities", None), mapping)
        rendered = remove_source_url_residue(
            rendered, source_urls, [result.affiliate for result in converted]
        )
        if drop_urls:
            for dropped_url in drop_urls:
                rendered = rendered.replace(dropped_url, "")
        rendered = clean_source_text(rendered)

    # Reply-only / hidden entity / inline-button links may not be literal in the
    # visible text. Ensure every DISTINCT converted product appears exactly once.
    for result in converted:
        if result.affiliate not in rendered:
            rendered = (rendered.rstrip() + "\n" + result.affiliate).strip()
    # Pass-through store links: swap the source shortener for the clean merchant
    # destination and register the exact pair so the provenance gate vouches for it.
    for source_url, resolved in passthrough:
        with contextlib.suppress(Exception):
            await store.remember_passthrough(clean_url(source_url), resolved, product_key(resolved))
        for variant in dict.fromkeys(v for v in (source_url, clean_url(source_url)) if v):
            if variant in rendered:
                rendered = rendered.replace(variant, resolved)
    for _source_url, resolved in passthrough:
        if resolved not in rendered:
            rendered = (rendered.rstrip() + "\n" + resolved).strip()
    # Service offer links: show the resolved clean destination (a zom.to short
    # link becomes the real offer page) and ensure each one is present.
    for source_url, resolved in service_pairs:
        clean_source = clean_url(source_url)
        if clean_source in rendered:
            rendered = rendered.replace(clean_source, resolved)
    for _source_url, resolved in service_pairs:
        if resolved not in rendered:
            rendered = (rendered.rstrip() + "\n" + resolved).strip()
    if (not STRICT_OUR_LINKS
            and (row["source"] in TRICKS_SOURCES or (had_social_promo and ADD_OUR_CHANNEL_FOOTER))):
        rendered = f"{rendered.rstrip()}\n\n{tricks_footer()}"
    rendered = tidy_post(rendered)
    # A source that wrote the whole list on one line is split first, so the two
    # list shapes (inline, and links grouped at the bottom) are both handled.
    rendered = split_inline_product_links(rendered)
    multi_product_list = len(converted) >= 3
    if multi_product_list:
        rendered = format_clustered_product_list(rendered)
    rendered = strict_orphan_token_cleanup(
        rendered, list_context=len({clean_url(url) for url in source_urls}) >= 2
    )
    # Cut the dead short links out of the copy itself. Leaving them in would publish a
    # foreign, unverified link (the provenance rule); removing them must not remove the
    # deal, so a post whose only link was dead goes out as complete text instead of
    # being skipped - "source lo vasthundi, mana target lo raledu" is the bug, a dead
    # shortener is not a reason for it.
    for dead_link in unresolvable:
        for variant in dict.fromkeys(v for v in (dead_link, clean_url(dead_link)) if v):
            rendered = rendered.replace(variant, " ")
    if unresolvable:
        rendered = sanitize_outbound_text(tidy_post(clean_source_text(rendered)))
    if not rendered or (not URL_RE.search(rendered) and not unresolvable and not link_free_post):
        raise PermanentSkip("rendered post has no affiliate URL")

    discount = parse_discount(text, price)
    card_offer = has_card_offer(text)
    list_prices = extract_deal_prices(text) if multi_product_list else []
    routing_price = max(list_prices) if list_prices else price

    # Card / bank offers: user wants them on EVERY owned channel at once plus
    # the premium channel, with the Loots Family folder link appended. These
    # are the strongest, most time-sensitive deals, so fanning out is correct.
    if (not STRICT_OUR_LINKS and card_offer and ADD_OUR_CHANNEL_FOOTER
            and OUR_FOLDER_LINK not in rendered):
        # "nothing of ours in the post" - the folder link is our own promo text,
        # so it only rides along when the operator asks for it. The card offer
        # itself is published complete either way.
        rendered = append_folder_link(rendered)

    # Final provenance guard: every URL must be an exact generated output.
    generated = {r.affiliate for r in converted}
    allowed_final_urls = set(generated)
    if not STRICT_OUR_LINKS:
        if row["source"] in TRICKS_SOURCES or had_social_promo:
            allowed_final_urls.update({OUR_FOLDER_LINK, *OUR_MAIN_CHANNEL_LINKS})
        if card_offer:
            allowed_final_urls.add(OUR_FOLDER_LINK)
    if not STRICT_OUR_LINKS:
        if service_pairs:
            allowed_final_urls.update(resolved for _, resolved in service_pairs)
        if passthrough:
            allowed_final_urls.update(resolved for _, resolved in passthrough)
    # GUARANTEE: the source's link is gone, only OUR link remains. A single
    # leftover foreign/shortener link used to throw the whole deal away
    # ("foreign URL survived") - that is how posts silently went missing. The
    # offending link is now repaired out of the post; we still refuse to publish
    # something that carries no verified link at all.
    leftover = [raw for raw in dict.fromkeys(URL_RE.findall(rendered))
                if clean_url(raw) not in allowed_final_urls]
    if leftover and STRICT_OUR_LINKS:
        # Removing only a URL from a list can leave its name/price stranded.
        # Fail the post as a unit when the final render contains any unverified
        # link that did not come from our converter.
        raise PermanentSkip("unverified link would break the product name/price/link association")
    if leftover:
        for raw in leftover:
            rendered = rendered.replace(raw, " ")
        rendered = tidy_post(clean_source_text(rendered))
        log.info("LINK REPAIR | queue=%s removed %s unverified link(s): %s",
                 row["id"], len(leftover), ", ".join(u[:40] for u in leftover[:4]))
        # The source's own layout is the reference, and it lives on the row (v18.2) -
        # reading a column that is not there would crash the repair and lose the post.
        rendered = keep_source_spacing(rendered, row["source_text"] if "source_text" in row.keys() else "")
    if (not any(clean_url(raw) in allowed_final_urls for raw in URL_RE.findall(rendered))
            and not unresolvable and not link_free_post):
        raise PermanentSkip("no verified affiliate link survived in the rendered post")
    if unresolvable and not URL_RE.search(rendered):
        # Every link this post carried was a dead shortener, so the deal goes out as
        # complete text. Refusing it here would repeat the old sin: the source has the
        # post, our channel does not.
        log.warning("LINK-FREE POST | queue=%s posted complete, without a link "
                    "(source's short link no longer resolves)", row["id"])

    # PowerLoots1 is now a global filtered destination across ALL configured
    # sources. Remove legacy unconditional routing, then add it only when the
    # deal is <=₹499, >=70% off, or an explicit bank/card offer.
    base_targets = [
        target for target in SOURCE_TO_TARGETS.get(row["source"], [])
        if target != POWER_FILTER_TARGET
    ]
    if multi_product_list and row["source"] not in TRICKS_SOURCES:
        for main_target in LZI_SECRET:
            if main_target not in base_targets:
                base_targets.append(main_target)
    if (SECRET_TARGET in base_targets
            and not eligible_for_secret(text, routing_price, discount,
                                        multi_product_list, card_offer)):
        base_targets = [target for target in base_targets if target != SECRET_TARGET]
    # Card / bank offers are the user's highest priority: fan out to EVERY
    # owned channel, force the premium channel, and rank them as premium.
    premium_rank = None
    if card_offer:
        for target in ALL_OWNED_TARGETS:
            if target not in base_targets:
                base_targets.append(target)
        if PREMIUM_TARGET not in base_targets:
            base_targets.append(PREMIUM_TARGET)
        premium_rank = max(1, premium_score(text, routing_price, discount))
    elif service_pairs:
        # Zomato/Swiggy/Zepto/movie/card-app offers fan out to EVERY owned
        # channel like bank/card offers — the user must not miss them.
        for target in ALL_OWNED_TARGETS:
            if target not in base_targets:
                base_targets.append(target)
        premium_rank = max(1, premium_score(text, routing_price, discount))
    elif row["source"] not in TRICKS_SOURCES:
        if multi_product_list:
            # 3+ product lists fan out to the curated non-Tricks destinations, and
            # POWER + PREMIUM take every list (their audience expects roundups).
            # The user's rule for the price channels (Aug 2026): a LIST roundup
            # belongs in BOTH of them whatever the item prices are - "under 99
            # channel lo under 99 products mariyu list of products undali", and the
            # under-499 channel pulls its picks from all sources. Single deals stay
            # band-checked, and dedup is untouched: every channel still receives a
            # given post exactly once, so this cannot double-post.
            for price_channel in (UNDER99_TARGET, UNDER499_TARGET):
                if price_channel not in base_targets:
                    base_targets.append(price_channel)
            for target in (POWER_FILTER_TARGET, PREMIUM_TARGET):
                if target not in base_targets:
                    base_targets.append(target)
            premium_rank = max(1, premium_score(text, routing_price, discount))
        else:
            # "powerloots lo anni cheyali" - PowerLoots1 takes EVERY deal the
            # pipeline accepts, from every non-Tricks source (the old
            # <=₹499 / >=70%-off filter made it silently miss posts). Dedup is
            # untouched, so this is still exactly one copy per channel.
            if POWER_FILTER_TARGET not in base_targets:
                base_targets.append(POWER_FILTER_TARGET)
            for price_target in automatic_price_targets(routing_price):
                if price_target not in base_targets:
                    base_targets.append(price_target)
            # under499loots is the main feed for every configured source. Price
            # routing above already handles parseable prices; this catches the
            # strong deals whose price the source never printed.
            if (UNDER499_TARGET not in base_targets
                    and eligible_for_under499_best(text, routing_price, discount, card_offer)):
                base_targets.append(UNDER499_TARGET)
            if eligible_for_premium(text, routing_price, discount):
                base_targets.append(PREMIUM_TARGET)
                premium_rank = premium_score(text, routing_price, discount)
    # USER RULE: every valid source post is published to the Telegram channels;
    # the best-deal CURATION applies to WhatsApp only. A real post that has a
    # monetizable link therefore ALWAYS reaches the main feed
    # (LootZoneIndia11) - and Tricks sources always reach the Tricks channel -
    # regardless of price/discount. The themed filters above (Secret, Power,
    # Premium, Under99/Under499 price routes) decide only the EXTRA channels;
    # they can never silence a post on the main feed.
    if row["source"] in TRICKS_SOURCES:
        guaranteed = TRICKS_TARGET
    else:
        guaranteed = "LootZoneIndia11"
        # An under-₹99 SOURCE that posts an item we cannot verify as ≤₹99 (or
        # that costs more) must not push it to the Under99 price channel - but
        # it still goes to the main feed instead of being dropped.
        if (row["source"] in UNDER99_SOURCES and not service_pairs
                and (routing_price is None or routing_price > 99)):
            base_targets = [target for target in base_targets if target != UNDER99_TARGET]
    if guaranteed not in base_targets:
        base_targets.append(guaranteed)
    # Category shelves are an additive mirror: a confident product always
    # remains on the Main feed and adds exactly one category target. This also
    # brings a genuine product out of a Tricks source into Main; unclassified
    # Tricks posts and service promos keep their existing routing.
    deal_category = ""
    category_reason = "service_promotion"
    if not service_pairs:
        # The category shelf follows the product, not just caption keywords:
        # include source, resolved merchant, and final affiliate URLs. Readable
        # slugs/search terms survive even when the incoming link was shortened.
        category_link_context = [
            value for result in converted
            for value in (result.source, result.resolved, result.affiliate)
            if value
        ]
        category_decision = classify_category(text, category_link_context, CATEGORY_RULES)
        category = category_decision["category"]
        category_reason = category_decision["reason"]
        deal_category = category or ""
        category_target = CATEGORY_TARGETS.get(category or "", "")
        if category_target:
            if "LootZoneIndia11" not in base_targets:
                base_targets.append("LootZoneIndia11")
            if category_target not in base_targets:
                base_targets.append(category_target)
            log.info("CATEGORY ROUTE | %s -> @%s | queue=%s",
                     CATEGORY_DEFINITIONS[category]["label"], category_target, row["id"])
    # A source-level category policy is stronger than a shelf filter: if the
    # watched source is for fashion only, a grocery post is not posted anywhere.
    # Raised as PermanentSkip so it is recorded with its reason (never retried,
    # never counted as a lost post).
    _source_block = source_category_blocked(row["source"], deal_category)
    if _source_block:
        raise PermanentSkip(_source_block)
    # Dashboard category shelves (2026-10-13): a dashboard target with a
    # category filter keeps ONLY posts classified into its categories (an
    # electronics shelf never sees fashion, promos, or unclassified posts).
    # Unfiltered targets - every built-in and every plain dashboard channel -
    # pass through untouched.
    if DASHBOARD_CATEGORY_FILTERS and base_targets:
        withheld = [target for target in base_targets
                    if not dashboard_category_ok(target, deal_category)]
        if withheld:
            log.info("CATEGORY WITHHELD | queue=%s category=%s reason=%s targets=%s",
                     row["id"], deal_category or "unknown", category_reason, ",".join(withheld))
        base_targets = [target for target in base_targets
                        if dashboard_category_ok(target, deal_category)]
    # USER RULE (2026-09-05): the Amazon-Associates review channel. It takes the
    # same PRODUCT deals every other channel takes, in the programme-safe form
    # rendered at delivery time (name + price + link). A trick/recharge/app promo
    # is not a shoppable product, and a post with no buyable link cannot be
    # reviewed as one, so neither reaches it.
    if (SHOPPING_TARGET_ENABLED
            and row["source"] not in TRICKS_SOURCES
            and not service_pairs
            and URL_RE.search(rendered)
            and (not SHOPPING_AMAZON_ONLY or is_amazon_only_post(rendered))
            and SHOPPING_TARGET not in base_targets):
        base_targets.append(SHOPPING_TARGET)
    # Custom intake is channel-local: never fan it into built-in/global routes.
    base_targets = scope_dashboard_targets(row["source"], base_targets)
    if not base_targets:
        raise PermanentSkip("no eligible targets")
    # FINAL safety net: no affiliate link may leave the post long — shorten any
    # long generated URL (Amazon category/search links with our tag, missed
    # multi-link shortens) before persisting/sending.
    rendered = await affiliate.shorten_long_urls_in_text(rendered)
    rendered = sanitize_outbound_text(rendered)
    # v17.6 numeric fidelity gate: a figure the source never printed is corruption,
    # so the NUMBER goes out of the post - never the post out of the channel.
    # The basis is the RAW source message (not the cleaned copy): cleaning may
    # drop a promo clause that sat next to a price, and the renderer legitimately
    # re-prints that price in the tidied header. Numbers the source itself never
    # printed are what gets removed - nothing else.
    try:
        rendered, fidelity_notes = enforce_numeric_fidelity(f"{raw_text}\n{text}", rendered)
        for note in fidelity_notes:
            log.info("PRICE FIDELITY | queue=%s removed %s", row["id"], note)
        rendered = rendered.strip() or ""
    except Exception as exc:  # noqa: BLE001 - a gate must never lose a live deal
        log.warning("PRICE FIDELITY check skipped (post kept as rendered): %s", exc)
    if not URL_RE.search(rendered):
        if link_free_post:
            # The SOURCE never wrote a link and the post carries the product's own
            # photo, so the reader can still see and search the deal. That post is
            # published exactly as posted (round 13's rule) - nothing was lost here.
            log.warning("LINK-FREE POST | queue=%s the source posted this with no link at all "
                        "- publishing it exactly as posted", row["id"])
        elif unresolvable and not REQUIRE_LINK_IN_POST:
            log.warning("LINK-FREE POST | queue=%s every link the source wrote was a dead "
                        "short link - posting the deal complete, without a link", row["id"])
        elif unresolvable:
            # USER RULE (2026-09-05): "asalu link yeh ledu" - a text deal with no
            # link at all is not a post our readers can use, and it earns nothing.
            # The source DID write links here; every one of them was a dead
            # shortener, so there is nothing to publish. It is skipped instead of
            # going out as a linkless teaser.
            raise PermanentSkip("every link the source wrote is dead - nothing buyable to post")
        else:
            raise PermanentSkip("rendered post has no affiliate URL after shorten pass")
    rendered = keep_source_spacing(rendered, raw_text)
    # Persist only the products actually rendered/reserved; never extend the
    # dedup timestamp of products filtered as already-posted.
    commit_keys = list(new_keys)
    if content_key:
        commit_keys.append(content_key)
    await store.save_render(
        row["id"], rendered, list(dict.fromkeys(base_targets)), commit_keys, premium_rank
    )
    if product_identities(text) or commit_keys:
        # Remember what products this row stands for, so a better copy arriving
        # later can find (and take over) this pending job.
        await store.remember_products(row["id"], sorted(set(product_identities(text))
                                                         | comparable_product_ids(commit_keys)))
    return msg, rendered, price


def extract_urls_from_buttons(msg) -> list[str]:
    result = []
    markup = getattr(msg, "reply_markup", None)
    if isinstance(markup, ReplyInlineMarkup):
        for row in markup.rows:
            for button in row.buttons:
                url = button_url(button)
                if url:
                    result.append(clean_url(url))
    return result


class DuplicateDeal(Exception):
    pass


class PermanentSkip(Exception):
    """A non-retryable source message: spam/no URL/unsupported/no eligible target."""


TRICK_PROMO_LINK_RE = re.compile(
    r"(?i)(?:https?://)?(?:t|telegram)\.me/(?:addlist/|joinchat/|\+|[A-Za-z0-9_]+)[^\s|]*|"
    r"https?://(?:www\.)?whatsapp\.com/channel/[^\s|]+"
)


def sanitize_trick_promo(text: str) -> str:
    cleaned = clean_source_text(text)
    cleaned = TRICK_PROMO_LINK_RE.sub("", cleaned)
    cleaned = re.sub(
        r"(?im)^.*(?:many\s+loot\s+being\s+posted|don[’']?t\s+miss|"
        r"ye\s+channels\s+join|biggest\s+loot.*(?:buy\s+now|join\s+fast)).*?$",
        "", cleaned,
    )
    cleaned = re.sub(r"(?im)^\s*(?:link|₹\s*\d+)\s*:\s*[|\s]*$", "", cleaned)
    cleaned = re.sub(r"(?im)^\s*(?:buy\s*now|join\s*fast)\s*[👇.🔥😍😱]*\s*$", "", cleaned)
    cleaned = cleaned.replace("**", "").replace("__", "")
    cleaned = re.sub(r"\|{1,}", " ", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip(" |\n")
    if len(cleaned) < 12:
        cleaned = "🎯 BIGGEST LOOT & SHOPPING TRICKS\n\n⚡ Fresh trick/update — check quickly"
    return cleaned


async def render_trick_promo(row: sqlite3.Row, msg, raw_text: str):
    if STRICT_OUR_LINKS:
        raise PermanentSkip("promo-only post has no verified monetized product link")
    body = sanitize_trick_promo(raw_text)
    rendered = f"{body}\n\n{tricks_footer()}"
    key = "URL:" + hashlib.sha256(("TRICK:" + body.lower()).encode()).hexdigest()
    ok, keys = await store.reserve(row["id"], [key], None, False)
    if not ok:
        raise DuplicateDeal("duplicate trick/promo")
    await store.save_render(row["id"], rendered, [TRICKS_TARGET], keys)
    return msg, rendered, None


async def settle_unrecorded_target(queue_id: int, target: str, premium: bool,
                                   identity_keys: list, price: int | None,
                                   discount: int | None) -> None:
    """Retry the ledger write for an already-sent target - never the send.

    Called when a target's post reached Telegram but SETTLE FAILED (the
    database refused the record even after patient retries). Success pops the
    SETTLED_BUT_UNRECORDED entry so finish() can close the job; failure idles
    on UNRECORDED_SETTLE_RETRY_DELAY so a wedged database waits instead of
    hot-looping the claim/finish cycle. Either way nothing re-posts. This is
    ledger-outage backoff, not fan-out pacing: the send path never waits on it.
    """
    try:
        if premium:
            await store.complete_premium(queue_id, True)
        if identity_keys:
            await store.mark_product_posted(target, identity_keys[0], price, discount,
                                            identity_keys[1:], queue_id=queue_id)
        await store.delivery(queue_id, target, True, "")
        if target == SHOPPING_TARGET:
            with contextlib.suppress(Exception):
                await store.note_shopping_sent()
    except Exception as exc:
        log.critical(
            "SETTLE STILL FAILING | queue=%s target=%s (%s): the post is already out - "
            "retrying the ledger write, never the send", queue_id, target, exc)
        await asyncio.sleep(UNRECORDED_SETTLE_RETRY_DELAY)
    else:
        SETTLED_BUT_UNRECORDED.pop((queue_id, target), None)


async def preflight_links(affiliate, text: str, require_ours: bool = True
                          ) -> tuple[list[str], dict[str, str], int]:
    """Verify the text's links for posting; tolerant of test doubles.

    The real client implements preflight_links() (ownership + health, repeated).
    A double that only implements the older rendered_links_not_broken() contract
    keeps the old semantics instead of crashing the worker.
    """
    urls = list(dict.fromkeys(clean_url(x) for x in URL_RE.findall(text or "")))
    probe = getattr(affiliate, "preflight_links", None)
    if callable(probe):
        return await probe(text, require_ours=require_ours)
    if not urls:
        return [], {}, 0
    if await affiliate.rendered_links_not_broken(text):
        return urls, {}, 1
    # The double only answers "something is dead": ask it per link, exactly as
    # the delivery path used to, so only the dead ones are repaired/cut.
    verdicts = await asyncio.gather(
        *(affiliate.link_not_broken(url) for url in urls), return_exceptions=True)
    bad = {url: ("outage" if link_is_outage(affiliate, url) else "dead")
           for url, ok in zip(urls, verdicts) if ok is False}
    return urls, bad, 1


async def process_job(client, affiliate: AffiliateClient, target_map, row: sqlite3.Row):
    stored_copy = (row["source_text"] if "source_text" in row.keys() else "") or ""
    # a list of files (with their Telegram refs) when the source posted an album
    media_path: list[str] = []
    media_refs: list = []
    successes = 0
    new_sends = 0
    settlement_retries = 0
    held_targets = 0
    confirmed_chunks = 0
    price = None
    try:
        # A channel we publish to is never a source. The user added the new
        # channel's own link as a source; without this the bot re-reads its own
        # post and publishes it again, forever.
        if is_own_channel_source(row["source"]):
            raise PermanentSkip(
                f"@{row['source']} is our own channel - not a deal source")
        if row["rendered_text"]:
            # The post is already rendered and stored: this fetch only sharpens the
            # residue cleaning and re-attaches media. A source message that has since
            # been deleted must not abort a job that is ready to send, so a failed
            # lookup degrades to "no message" - which the branches below already treat
            # as "post the stored copy, without media".
            msg = None
            try:
                msg = await client.get_messages(row["chat_id"], ids=row["msg_id"])
            except Exception as exc:  # noqa: BLE001 - optional enrichment, never a blocker
                log.info("SOURCE MESSAGE GONE | queue=%s fetch raised %s - posting the stored copy",
                         row["id"], type(exc).__name__)
            rendered = row["rendered_text"]
            if await store.has_partial_delivery(row["id"]):
                # At least one chunk is already out. Re-cleaning would shift the
                # chunk boundaries and the resumed part would post a duplicated
                # or half-eaten line, so finish this job with the stored bytes.
                pass
            else:
                # Nothing sent yet: re-clean persisted pending work so a hotfix
                # applies to posts queued by an older formatter before delivery,
                # then freeze the result so every target gets identical text.
                if msg:
                    rendered = remove_source_url_residue(
                        rendered, extract_urls(msg), URL_RE.findall(rendered)
                    )
                rendered = tidy_post(clean_source_text(rendered))
                rendered = split_inline_product_links(rendered)
                rendered = format_clustered_product_list(rendered)
                rendered = strict_orphan_token_cleanup(
                    rendered,
                    list_context=(len(set(URL_RE.findall(stored_copy))) >= 2
                                  or len(set(URL_RE.findall(rendered))) >= 2),
                )
                rendered = sanitize_outbound_text(rendered)
                if rendered != row["rendered_text"]:
                    with contextlib.suppress(Exception):
                        await store.update_rendered(row["id"], rendered)
            if not await store.claim_content_key(row["id"], content_deal_key(rendered)):
                raise DuplicateDeal("duplicate pending content")
            price = parse_price(msg.message or msg.text or "") if msg else None
        else:
            msg, rendered, price = await render_job(client, affiliate, row)
        # v17.8 ONE PRODUCT, ONE CHANNEL, ONE POST. Two sources can carry the same
        # product through two different short links, and until a link is resolved
        # the merchant ids look different - which is how a channel got the same
        # earphones twice. The product's own words (plus the merchant host and any
        # size/model token) settle it, and a repeat is skipped per channel. A
        # strictly better copy still posts, so coverage is never traded away.
        product_sig = product_signature(rendered)
        target_discount = parse_discount(rendered, price)
        # The repeat guard matches ANY of these: the headline key (the
        # product's own words) plus the exact link identities behind the
        # post's URLs. The same product wearing a different caption still
        # shares a link key, so a reworded cross-source repeat cannot slip
        # past the headline (user rule 2026-10-12).
        identity_keys = [product_sig] if product_sig else []
        identity_keys += [key for key in await store.text_identity_keys(rendered)
                          if key not in identity_keys]
        if msg and getattr(msg, "media", None) and not isinstance(msg.media, (MessageMediaWebPage, MessageMediaInvoice)):
            if media_is_too_large(msg):
                log.info("MEDIA SKIPPED | queue=%s oversized media; posting the deal as text",
                         row["id"])
            else:
                # Parent exists and no fake .bin extension: Telethon preserves the
                # actual photo/video/document type so target posts render correctly.
                # An album (a grid of photos in one bubble) is downloaded IN FULL -
                # the source's own layout is what the target must show.
                media_target = MEDIA_DIR / f"{row['chat_id']}_{row['msg_id']}"
                media_path, media_refs = await download_album(client, msg, media_target, row["id"])
        # LAST-MILE AMAZON SHORT REPAIR (USER REPORT 2026-10-04): a row queued by an
        # older build may still carry an `amzn.to?...` short link, which opens the
        # page of whoever created that short code. The link is cut (never the deal)
        # and the log says so; a short link WE minted expands back to its long form.
        rendered, short_cut = cut_amazon_short_links(rendered, affiliate)
        if short_cut and STRICT_OUR_LINKS:
            raise PermanentSkip("legacy render contains an unowned Amazon short link")
        if short_cut:
            with contextlib.suppress(Exception):
                await store.update_rendered(row["id"], rendered)
            log.warning("AMAZON SHORT CUT | queue=%s removed %s Amazon short link(s) - a "
                        "short code is somebody's wrapper, never our destination: %s",
                        row["id"], len(short_cut), ", ".join(x[:60] for x in short_cut[:2]))
            if not rendered.strip() and not row["source"]:
                raise PermanentSkip("post was only an Amazon short link")
        # Final provenance gate runs again immediately before target delivery.
        owned_candidates = set() if STRICT_OUR_LINKS else {
            OUR_FOLDER_LINK, *OUR_MAIN_CHANNEL_LINKS
        }
        owned_external = {url for url in owned_candidates if url in rendered}
        # A post with no URL at all has nothing to prove (this happens only when every
        # link the source wrote was a dead short link, cut above): the deal text still
        # goes out rather than being skipped.
        if URL_RE.search(rendered) and not await store.verify_generated_text(rendered, owned_external):
            # USER RULE (2026-10-22): a link that cannot prove it pays us is
            # REPAIRED, not thrown away with the deal. Unwrap the hop, tag the
            # destination, then re-run the same gate on the rewritten text.
            repaired_text, repairs = await repair_links_if_possible(affiliate, rendered)
            if repaired_text != rendered and await store.verify_generated_text(
                    repaired_text, owned_external):
                log.info("LINK REPAIR | queue=%s final recheck passed after rewriting %s link(s)",
                         row["id"], sum(1 for n in repairs if n["status"] == "repaired"))
                rendered = repaired_text
                with contextlib.suppress(Exception):
                    await store.update_rendered(row["id"], rendered)
            else:
                raise PermanentSkip("final provenance recheck failed")
        # Owned Telegram promo links are not merchant destinations; all other
        # generated shopping links still receive the normal health check.
        merchant_health_text = rendered
        for owned_url in owned_external:
            merchant_health_text = merchant_health_text.replace(owned_url, "")
        # Share/forward links are excluded from the health verdict too: they can 4xx,
        # be bot-blocked, or be a plain "tg://" scheme, and none of that says anything
        # about whether the product page is live.
        for share_url in URL_RE.findall(merchant_health_text):
            if is_share_intent(share_url):
                merchant_health_text = merchant_health_text.replace(share_url, " ")
        # USER RULE (2026-10-19): "10 time check perefctga convert then post".
        # Every link is re-verified for POSTING - provably OURS, and open right
        # now - up to POST_VERIFY_ATTEMPTS times, immediately before delivery.
        # The ownership half only runs in strict mode: legacy mode is explicitly
        # allowed to pass clean merchant pages through.
        all_urls, bad_links, verify_passes = await preflight_links(
            affiliate, merchant_health_text, require_ours=STRICT_OUR_LINKS)
        if bad_links and verify_passes > 1:
            log.info("POST VERIFY | queue=%s verified %s time(s) before giving up on %s link(s)",
                     row["id"], verify_passes, len(bad_links))
        unowned = [u for u, kind in bad_links.items() if kind == "unowned"]
        if unowned:
            # A link that is not provably ours is NEVER published, whatever else
            # the post carries: that is exactly the "our number on their long
            # link" mistake this rule exists to stop.
            log.warning("LINK NOT OURS | queue=%s refusing to publish %s unverified link(s): %s",
                        row["id"], len(unowned), ", ".join(u[:60] for u in unowned[:2]))
            keep = [u for u in all_urls if u not in set(unowned)]
            if not keep:
                raise PermanentSkip("every link is unverified ownership (not our conversion)")
            for url in unowned:
                rendered = rendered.replace(url, " ")
            rendered = sanitize_outbound_text(tidy_post(clean_source_text(rendered)))
            with contextlib.suppress(Exception):
                await store.update_rendered(row["id"], rendered)
            rendered = keep_source_spacing(
                rendered, row["source_text"] if "source_text" in row.keys() else "")
            all_urls = keep
        if bad_links and not unowned and URL_RE.search(merchant_health_text):
            dead = [u for u, kind in bad_links.items() if kind in {"dead", "outage"}]
            # A DEAD HOP IS NOT A DEAD PRODUCT (USER REPORT 2026-10-19: "idlga
            # vasthundi 503 Service Unavailable"). Every short link we mint is
            # remembered with the long URL behind it. When the HOP is what
            # answered 503, publishing the hop is the dead link the reader gets,
            # and dropping it loses the deal's only link - so the verified long
            # URL takes its place. A source's own short link is not in the map
            # (we never verified where it goes) and is handled exactly as before.
            repaired: list[str] = []
            still_dead: list[str] = []
            for url in dead:
                long_url = short_url_destination(affiliate, url)
                if long_url and await affiliate.link_not_broken(long_url):
                    rendered = rendered.replace(url, long_url)
                    repaired.append(url)
                    log.warning("SHORT LINK REPAIRED | queue=%s %s answers as a dead/"
                                "service-outage hop; publishing the verified destination "
                                "behind it instead: %s", row["id"], url[:60], long_url[:80])
                else:
                    still_dead.append(url)
            if repaired:
                with contextlib.suppress(Exception):
                    await store.update_rendered(row["id"], rendered)
            dead = still_dead
            survivors = [u for u in all_urls if u not in set(dead)]
            if dead and survivors:
                for url in dead:
                    rendered = rendered.replace(url, " ")
                rendered = sanitize_outbound_text(tidy_post(clean_source_text(rendered)))
                with contextlib.suppress(Exception):
                    await store.update_rendered(row["id"], rendered)
                log.warning("LINK REPAIR | queue=%s dropped %s dead destination(s); posting the rest",
                            row["id"], len(dead))
                rendered = keep_source_spacing(rendered, row["source_text"] if "source_text" in row.keys() else "")
            elif dead:
                # Every link answered as an explicit "this page is gone" page - and
                # THIS used to be a silent missing post, the exact complaint the user
                # brought back after v17.9 ("source lo post vasthundi, mana target
                # lo raledu"). It is not proof: Amazon and Flipkart serve 404/repair
                # pages to a datacenter IP all day long, and a link a human source
                # channel just published is far more likely alive than our probe is
                # right. A deal our readers can still use beats a suppressed one, so
                # the post goes out and the log says which link was unverified.
                outages = [u for u in dead if link_is_outage(affiliate, u)]
                if outages:
                    # BUT an explicit "no server is available to handle this
                    # request" is not datacenter-IP doubt: it is the host saying
                    # nothing is behind it right now. Posting it publishes the
                    # exact 503 page the reader complained about, so the post
                    # waits for its next attempt instead. Only a job with no
                    # attempts left gives up the link (never the deal, and never
                    # a link that is answering 503 at send time).
                    if row["attempts"] + 1 < JOB_MAX_ATTEMPTS:
                        raise RuntimeError(
                            "delivery retry required: %s destination(s) answered a service-outage "
                            "page (503) - the host has no server behind it right now" % len(outages))
                    for url in dead:
                        rendered = rendered.replace(url, " ")
                    rendered = sanitize_outbound_text(tidy_post(clean_source_text(rendered)))
                    with contextlib.suppress(Exception):
                        await store.update_rendered(row["id"], rendered)
                    rendered = keep_source_spacing(
                        rendered, row["source_text"] if "source_text" in row.keys() else "")
                    log.warning("LINK OUTAGE | queue=%s last attempt: dropped %s destination(s) "
                                "answering 503 rather than publishing a dead link; the deal "
                                "itself still goes out", row["id"], len(dead))
                elif DROP_DEAD_LINKS:
                    raise PermanentSkip("every destination is a confirmed dead merchant page")
                else:
                    log.warning("LINK UNVERIFIED | queue=%s %s destination(s) answered as a dead "
                                "page (our IP may simply be blocked); posting anyway",
                                row["id"], len(dead))
        premium_defer_until = None
        first_target_sent = False
        for target in await store.pending_targets(row["id"]):
            # USER RULE: Telegram never waits — no ban rule there, keep posting.
            # Every target goes back to back: a gap exists only if the operator
            # asks for one via TARGET_FANOUT_GAP_MIN/MAX (both default 0), so
            # fan-out to six channels costs nothing.
            if first_target_sent and TARGET_FANOUT_GAP_MAX > 0:
                await asyncio.sleep(random.uniform(TARGET_FANOUT_GAP_MIN, TARGET_FANOUT_GAP_MAX))
            first_target_sent = True
            unrecorded = SETTLED_BUT_UNRECORDED.get((row["id"], target))
            if unrecorded is not None:
                # This target's post is already OUT on Telegram: an earlier
                # pass sent it and the ledger refused the record (SETTLE
                # FAILED). Retry ONLY the bookkeeping - never the send. The
                # ledger row still reads pending, so finish() requeues and
                # this repeats until the write lands; each failing pass idles
                # instead of hot-looping, and the post is never doubled.
                await settle_unrecorded_target(row["id"], target, unrecorded.get("premium"),
                                               identity_keys, price, target_discount)
                successes += 1
                settlement_retries += 1
                continue
            premium_claimed = False
            if target == PREMIUM_TARGET:
                premium_claimed, defer_until = await store.claim_premium(row["id"])
                if not premium_claimed:
                    premium_defer_until = (
                        defer_until if premium_defer_until is None
                        else min(premium_defer_until, defer_until)
                    )
                    continue
            entity = target_map.get(target)
            if not entity:
                entity = await resolve_entity(client, target)
                if entity:
                    target_map[target] = entity
            if not entity:
                if premium_claimed:
                    await store.complete_premium(row["id"], False)
                if target == SHOPPING_TARGET:
                    # The review channel is an EXTRA destination. If the account
                    # cannot see it yet (not created, not joined, renamed), that
                    # is never a reason to hold a live deal back from the
                    # channels that DO exist - the job would otherwise sit in
                    # retry until the price went stale.
                    log.warning("SHOPPING TARGET UNRESOLVED | @%s not reachable; the deal "
                                "still goes to every other channel", target)
                    await store.delivery_skipped(row["id"], target, "shopping target unresolved")
                    continue
                if target in {value for value in CATEGORY_TARGETS.values() if value}:
                    log.warning("CATEGORY TARGET UNRESOLVED | @%s not reachable; the deal "
                                "still goes to the Main feed and other channels", target)
                    await store.delivery_skipped(row["id"], target, "category target unresolved")
                    continue
                await store.delivery(row["id"], target, False, "target unresolved")
                continue
            # v17.8 one product, one channel, one post: the exact merchant id can
            # differ between two sources that link the same product through
            # different shorteners, so the product's own words settle it here.
            start_chunk = await store.delivery_progress(row["id"], target)
            target_skip_reason = ""
            if not start_chunk and row["source"] not in TRICKS_SOURCES and identity_keys:
                duplicate, why = await store.product_already_posted(
                    target, identity_keys, price, target_discount)
                if duplicate:
                    target_skip_reason = why
                elif why:
                    log.info("BETTER COPY | queue=%s target=%s %s", row["id"], target, why)
            if target_skip_reason:
                log.info("DUPLICATE PRODUCT (signature) | queue=%s target=%s | %s",
                         row["id"], target, target_skip_reason)
                await store.delivery_skipped(row["id"], target, "duplicate product")
                continue
            async def checkpoint(count: int, queue_id=row["id"], target_name=target):
                await store.set_delivery_progress(queue_id, target_name, count)

            # Power and Premium use filtering/scheduling only. Keep one clean,
            # source-derived post with no repetitive bot-added headers/footers.
            # USER RULE (round 13): our own family link on the TOP line - a reader of any
            # of our channels can reach the rest of the family instead of wandering into
            # somebody else's. It goes on the way OUT, after the stored copy is final: the
            # ledger, the auditor and the chunk-resume logic keep seeing exactly the
            # source-derived text, no cleaning pass can eat the line as "join my channel",
            # and the Tricks posts, which have their own footer, are left untouched.
            # (Toggling the knob between two chunks of ONE long post would shift the
            # boundaries, so it is an operator switch, not a per-post experiment.)
            target_text = rendered
            if target == SHOPPING_TARGET:
                # Amazon Associates review copy: product name, the source's own
                # price, our link. The loot/urgency scaffolding is dropped here,
                # at delivery, so the stored copy every other channel gets stays
                # exactly the source's. A post that has nothing left but a link
                # is not reviewable, so it is skipped for THIS channel only.
                # No shortener hop on the reviewed channel: a bit.ly link hides
                # the destination, and a reviewer who cannot see the store domain
                # cannot verify the post. Our own short links are swapped back to
                # the native store URL (a source's own short link is untouched).
                if SHOPPING_NATIVE_LINKS:
                    target_text = await affiliate.expand_our_short_links(target_text)
                # ALL conditions live here, on the review channel only.
                # affiliate_safe_text() already rebuilds the copy as
                # "product / price / link", but a rating written INSIDE the
                # product line ("boAt Rockerz 255 4.2 star") would survive it,
                # so the ratings strip runs here too - copied ratings and
                # review counts are a documented closure reason.
                # ONE PRODUCT ONLY on the reviewed channel. A roundup reads as
                # a link dump and one weak item in it taints the whole sample;
                # the other channels still get the full list.
                safe_text = affiliate_safe_text(
                    strip_amazon_ratings(pick_one_product_for_review(target_text)))
                # "Price: 99" + a link is not a reviewable listing - there is no
                # product on it. The old test only looked for three letters
                # anywhere, and the word "Price" satisfied that, so nameless
                # posts were published. Require a real product line: something
                # that is neither the link nor the price line we generated.
                _named = [ln for ln in (safe_text or "").splitlines()
                          if ln.strip() and not URL_RE.fullmatch(ln.strip())
                          and not re.fullmatch(r"(?i)price\s*[::]\s*[₹\d,.]+", ln.strip())
                          and re.search(r"[A-Za-z]{3}", ln)]
                if (not safe_text or not URL_RE.search(safe_text) or not _named):
                    log.info("SHOPPING SKIP | queue=%s nothing reviewable left after the "
                             "programme-safe rewrite", row["id"])
                    await store.delivery_skipped(row["id"], target, "not programme-safe")
                    continue
                # Off-programme store on the channel submitted for the AMAZON
                # programme: it belongs on the other channels, not here.
                # A STRANGER'S Associates tag on the channel under review is
                # worse than no tag: to Amazon it reads as our channel paying a
                # third party, and it is unattributable traffic on a property we
                # declared. It can only get here if a link skipped the shorten
                # pass, so it is rewritten to OUR tag (never merely stripped -
                # an untagged link on the declared channel earns nothing).
                safe_text = retag_foreign_amazon_links(safe_text)
                if SHOPPING_AMAZON_ONLY and not is_amazon_only_post(safe_text):
                    log.info("SHOPPING SKIP | queue=%s not an Amazon-only deal", row["id"])
                    await store.delivery_skipped(row["id"], target, "not an amazon deal")
                    continue
                # A curated shop posts 20-30 times a day; a firehose reads as spam.
                if await store.shopping_quota_left() <= 0:
                    log.info("SHOPPING SKIP | queue=%s daily cap of %s reached",
                             row["id"], SHOPPING_DAILY_CAP)
                    await store.delivery_skipped(row["id"], target, "daily cap reached")
                    continue
                # Pace it like a person: the day's allowance is spread across
                # posting hours instead of fired off in one burst. The deal is
                # left PENDING (not closed), so it goes out on a later pass
                # rather than being lost - and every other channel has already
                # received it immediately, untouched by this gate.
                pace_wait = await store.shopping_pace_wait()
                if pace_wait > 0:
                    log.info("SHOPPING PACE | queue=%s holding %s min so the channel "
                             "posts like a human", row["id"], round(pace_wait / 60))
                    continue
                # REJECTION 2026-09-06: "unapproved use of Amazon trademarked
                # words, images ... or reviews". Naming the marketplace in the
                # copy is an unlicensed use of the mark; linking to it is not.
                # A post that cannot say what it means without the word is
                # simply withheld from this ONE channel.
                if has_amazon_trademark(safe_text):
                    log.info("SHOPPING SKIP | queue=%s copy names an Amazon trademark",
                             row["id"])
                    await store.delivery_skipped(row["id"], target, "amazon trademark in copy")
                    continue
                # The same email named t.me/LootZoneIndia11 as its example, so a
                # reviewer must find NO route from here to a loot channel.
                if has_telegram_pointer(safe_text):
                    log.info("SHOPPING SKIP | queue=%s copy points at another channel",
                             row["id"])
                    await store.delivery_skipped(row["id"], target, "telegram pointer in copy")
                    continue
                # Link-level disclosure is an Amazon/FTC requirement on EVERY post
                # (the channel bio alone is not enough) and a common rejection
                # reason. Added last so it can never be cleaned off again.
                target_text = add_link_disclosure(safe_text)
            # Associates compliance: our tag may only ride on the channels that
            # are declared to Amazon (see AMAZON_TAG_TARGETS). Everywhere else the
            # SAME deal posts with an untagged link.
            # USER RULE (2026-09-06, FINAL): "only review channel lo anni
            # conditions tho post cheyali". Every programme condition - the
            # strict copy, the ratings strip, the disclosure, the Amazon-only
            # filter, the daily cap and the human pacing - belongs to
            # SHOPPING_TARGET and to nothing else. An ordinary channel receives
            # the source copy as the source wrote it: hype, MRP, percentages,
            # ratings, review counts, coupons, emoji and photos all intact.
            # Round 23's ratings strip was applied to every tagged channel and
            # is therefore removed here; it lives in the review branch only.
            tagless_copy = strip_amazon_tag_for_undeclared(target_text, target, affiliate)
            if STRICT_OUR_LINKS and tagless_copy != target_text:
                # Never publish a plain Amazon URL merely because Associates has
                # not declared this destination. Keep the tagged deal on its
                # approved targets and skip this target rather than leak a link
                # that does not earn for us.
                log.warning("TARGET SKIP | queue=%s @%s is not approved for our Amazon tag; "
                            "no untagged fallback will be posted", row["id"], target)
                await store.delivery_skipped(row["id"], target,
                                     "our Amazon affiliate link is not approved for this target")
                continue
            target_text = tagless_copy
            allow_preview = await store.preview_allowed(target_text)
            if (not STRICT_OUR_LINKS and ADD_OUR_CHANNEL_LINK_TOP
                    and row["source"] not in TRICKS_SOURCES
                    and target != SHOPPING_TARGET):
                # Never on the review channel: that header is a link into the
                # loot-channel folder, which is precisely what a marketplace
                # reviewer must not be shown.
                target_text = prepend_channel_header(target_text)
            # Repair runs in EVERY mode, not only strict: a stale queue row can
            # still carry the hop that was reported twice (is.gd over an untagged
            # Amazon page), and rewriting it earns the sale instead of skipping
            # the target. Nothing to repair is a no-op - no network call.
            target_text, send_repairs = await repair_links_if_possible(affiliate, target_text)
            fixed = [n for n in send_repairs if n["status"] == "repaired"]
            if fixed:
                log.info("LINK REPAIR | queue=%s target=%s rewrote %s unproven link(s) "
                         "to ours at pre-send", row["id"], target, len(fixed))
            still_bad = [n["url"] for n in send_repairs if n["status"] == "unrepairable"]
            if STRICT_OUR_LINKS:
                # Their links never post, our commission is never missed: the
                # final text is re-verified link by link right before the send.
                links_ok, bad_link = await store.presend_links_verified(target_text)
                if not links_ok:
                    log.warning("PRESEND LINK GUARD | queue=%s target=%s: refusing to post "
                                "an unverified link (%s) - the deal stays back so no foreign "
                                "link and no missed commission can reach the channel",
                                row["id"], target, bad_link[:80])
                    await store.delivery_skipped(
                        row["id"], target,
                        f"unverified link at pre-send: {bad_link[:120]}"
                        + (f" ({len(still_bad)} link(s) could not be repaired)" if still_bad else ""))
                    continue
            # LAST GATE BEFORE THE SEND: the copy has been cleaned, rewritten,
            # link-verified and headed by now, and this is the exact text the
            # channel would receive. Nothing that reads as adult / abusive /
            # betting / solicitation is published, whatever produced it (a queue
            # row from before the policy existed, a re-render, a source edit).
            try:
                verdict = safety_scan(target_text)
            except Exception as exc:  # noqa: BLE001
                log.warning("PRESEND SAFETY unavailable for queue=%s: %s", row["id"], exc)
                verdict = None
            if verdict and verdict.get("blocked"):
                log.warning("PRESEND SAFETY BLOCK | queue=%s target=%s category=%s "
                            "matched=%r why=%s", row["id"], target, verdict["category"],
                            verdict.get("matched", "")[:40], verdict.get("reason", "")[:120])
                await store.record_safety_block(
                    "presend", verdict, target_text, row["source"], row["msg_id"],
                    queue_id=row["id"], target=target)
                await store.delivery_skipped(
                    row["id"], target,
                    f"content policy: {verdict['category']} ({verdict.get('matched', '')[:40]})")
                continue
            # A forwarded deal photo is nearly always a marketplace screenshot -
            # the "images (screenshots/screen recordings)" the rejection cited.
            # The review channel goes text-only; every other channel keeps its
            # media, so no picture is lost anywhere else.
            target_media = media_path
            if target == SHOPPING_TARGET and SHOPPING_TEXT_ONLY:
                target_media = []
            if not await store.claim_target_products(row["id"], target, identity_keys,
                                                     resuming=start_chunk > 0):
                if premium_claimed:
                    await store.complete_premium(row["id"], False)
                await store.delivery_skipped(row["id"], target, "duplicate product or unsettled prior send")
                continue

            async def send_attempt(index, digest, state, qid=row["id"], name=target):
                nonlocal confirmed_chunks
                result = await store.send_attempt(qid, name, index, digest, state)
                if state == "sent":
                    confirmed_chunks += 1
                return result

            chunks_before_target = confirmed_chunks
            try:
                ok, error = await deliver(
                    client, entity, target_text, target_media,
                    start_chunk=start_chunk, progress_callback=checkpoint,
                    link_preview=allow_preview, media_refs=media_refs,
                    attempt_callback=send_attempt,
                )
            except AmbiguousDelivery as exc:
                held_targets += 1
                log.critical("DELIVERY HELD | queue=%s target=%s | %s", row["id"], target, exc)
                await store.delivery_held(row["id"], target, str(exc))
                if premium_claimed:
                    await store.complete_premium(row["id"], False)
                continue
            if ok:
                if confirmed_chunks > chunks_before_target:
                    new_sends += 1
                else:
                    settlement_retries += 1
                # The post is OUT on Telegram. Recording that fact must NEVER
                # throw the job back into fail_job's requeue mill: the target
                # would still read pending and the next pass would RE-SEND an
                # already-sent post. A ledger that stays unwritable after
                # patient retries is a CRITICAL alarm, not a reason to
                # duplicate - the next pass retries the write via
                # SETTLED_BUT_UNRECORDED without re-posting.
                try:
                    if premium_claimed:
                        await store.complete_premium(row["id"], True)
                    if identity_keys:
                        await store.mark_product_posted(target, identity_keys[0], price,
                                                        target_discount, identity_keys[1:], queue_id=row["id"])
                    await store.delivery(row["id"], target, True, error)
                    if target == SHOPPING_TARGET:
                        with contextlib.suppress(Exception):
                            await store.note_shopping_sent()
                except Exception as exc:
                    log.critical(
                        "SETTLE FAILED | queue=%s target=%s: sent to Telegram but the "
                        "ledger refused the record (%s). NOT re-sending; the write "
                        "will keep retrying without re-posting.",
                        row["id"], target, exc)
                    SETTLED_BUT_UNRECORDED[(row["id"], target)] = {"premium": premium_claimed}
                successes += 1
            else:
                # Only explicit rejections reach here. Keep a partially-sent
                # product fenced while its remaining chunks are retried.
                if not await store.delivery_progress(row["id"], target):
                    await store.release_target_products(row["id"], target)
                if premium_claimed:
                    await store.complete_premium(row["id"], False)
                await store.delivery(row["id"], target, False, error)
        await store.finish(row, successes, price, premium_defer_until)
        log.info("JOB %s | source=%s | sent=%s | settlement_retries=%s | held=%s | confirmed_chunks=%s",
                 row["id"], row["source"], new_sends, settlement_retries, held_targets, confirmed_chunks)
    except DuplicateDeal as exc:
        log.info("DEDUP | queue=%s | %s", row["id"], exc)
        await store.mark_done(row["id"], str(exc))
    except PermanentSkip as exc:
        log.info("SKIP | queue=%s | %s", row["id"], exc)
        await store.mark_done(row["id"], str(exc))
        # If this row was re-pointed at a better copy of the same product and the
        # better copy cannot be posted, the original copy goes back in the queue.
        with contextlib.suppress(Exception):
            await store.restore_superseded(row)
    except Exception as exc:
        log.exception("JOB FAIL %s: %s", row["id"], exc)
        await store.fail_job(row, str(exc))
    finally:
        for leftover in media_list(media_path):
            with contextlib.suppress(Exception):
                Path(leftover).unlink(missing_ok=True)

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
async def idle_wait(stop: asyncio.Event) -> None:
    """Park a worker until new queue work exists instead of polling.

    The wake flag is cleared *after* a direct pending check, so a wake-up can
    never be lost in the gap between claiming and sleeping; the short timeout
    is only a safety net (and keeps shutdown responsive).
    """
    if QUEUE_WAKE is not None:
        QUEUE_WAKE.clear()
        if await store.has_pending_work():
            return
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(QUEUE_WAKE.wait(), timeout=QUEUE_IDLE_POLL_SECONDS)
        return
    with contextlib.suppress(asyncio.TimeoutError):
        await asyncio.wait_for(stop.wait(), timeout=QUEUE_IDLE_POLL_SECONDS)


def refresh_dashboard_tag_keys():
    global AMAZON_TAG_TARGET_KEYS
    AMAZON_TAG_TARGET_KEYS = {normalize_channel_target_name(t) for t in AMAZON_TAG_TARGETS}


async def dashboard_live_loop(client, source_map, target_map, stop):
    """Optional dashboard subsystem must never take down posting workers."""
    try:
        try:
            from .live_channels import LiveChannels
        except ImportError:
            from live_channels import LiveChannels
        initial_names = {n.lower() for n in _dashboard_summary.get("added", [])}
        live_channels = LiveChannels(
            SOURCE_TO_TARGETS, AMAZON_TAG_TARGETS, DASHBOARD_CATEGORY_FILTERS,
            source_map, target_map,
            [c for c in _dashboard_data["channels"] if c["name"].lower() in initial_names],
            _dashboard_targets, CATEGORY_DEFINITIONS, TRICKS_SOURCES,
            lambda name: client.get_entity(name), refresh_dashboard_tag_keys,
            resolve_source=lambda source: resolve_dashboard_source(client, source),
            on_source_added=dashboard_source_added, builtin_sources=BUILTIN_SOURCE_NAMES,
            source_details=SOURCE_DETAILS, main_feed=NO_TRICKS_TARGETS,
            on_source_categories=dashboard_source_categories)
        await live_channels.run(stop)
    except Exception:
        log.exception("DASHBOARD LIVE ADD unavailable; existing posting continues")


async def channel_directory_publish(client, target_map=None) -> dict:
    """One pass: ask Telegram what this session can read, write it for the dashboard.

    Read-only: `iter_dialogs` lists what the account already has. Nothing is
    joined, nothing is sent, and no message history is fetched. The payload is
    written atomically so the dashboard can never read a half-written file.
    """
    try:
        from .channel_directory import build as build_directory
    except ImportError:
        from channel_directory import build as build_directory
    try:
        from . import channels_config as _config
    except ImportError:
        import channels_config as _config
    # 0 (the default) = every dialog Telegram will page through. A fixed 1000 was
    # a silent cap: on the live account (1122 dialogs) the picker hid 122 channels
    # and the counts still looked plausible. Set CHANNEL_DIRECTORY_LIMIT to a
    # positive number only to bound a very large account on purpose.
    limit = max(0, int(os.getenv("CHANNEL_DIRECTORY_LIMIT", "0")))
    entities = []
    async for dialog in client.iter_dialogs(**({"limit": limit} if limit else {})):
        entities.append(dialog.entity)
    payload = build_directory(entities, limit=max(1, int(
        os.getenv("CHANNEL_DIRECTORY_ROWS", "5000"))))
    payload["our_targets"] = sorted(str(t) for t in (target_map or {}))
    payload["our_sources"] = sorted(str(s) for s in SOURCE_TO_TARGETS)
    payload["watch_categories"] = {str(name): sorted(cats)
                                   for name, cats in SOURCE_CATEGORY_FILTERS.items()}
    path = _config.directory_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, path)
    log.info("CHANNEL DIRECTORY | %s channel(s), %s addable, %s target(s) -> %s",
             payload["count"], payload["addable"], len(payload["our_targets"]), path)
    return payload


async def channel_directory_loop(client, stop, target_map=None):
    """Refresh the directory so the dashboard's picker is the account's truth."""
    every = max(60, int(os.getenv("CHANNEL_DIRECTORY_SECONDS", "900")))
    while not stop.is_set():
        try:
            await channel_directory_publish(client, target_map)
        except Exception as exc:  # noqa: BLE001 - the picker is never worth a crash
            log.warning("CHANNEL DIRECTORY | refresh failed (picker keeps the last copy): %s", exc)
        try:
            await asyncio.wait_for(stop.wait(), timeout=every)
        except asyncio.TimeoutError:
            continue


async def main() -> None:
    global QUEUE_WAKE
    log.info("BestGAA Production Bot v19.0 starting "
             "(immediate dispatch, no duplicates, verbatim-clean text)")
    QUEUE_WAKE = asyncio.Event()
    client = TelegramClient(SESSION_PATH, API_ID, API_HASH)
    timeout = aiohttp.ClientTimeout(total=max(15.0, HTTP_TOTAL_TIMEOUT_SECONDS * 2))
    session = aiohttp.ClientSession(timeout=timeout)
    affiliate = AffiliateClient(session)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        with contextlib.suppress(NotImplementedError):
            loop.add_signal_handler(sig, stop.set)

    await client.start()
    me = await client.get_me()
    log.info("LOGIN %s (@%s)", me.first_name, me.username)
    source_map, target_map = await build_maps(client)
    log.info("LIVE | sources=%d targets=%d", len(source_map) // 2, len(target_map))

    @client.on(events.NewMessage())
    async def on_message(event):
        # Accept any chat-id convention (marked channel, raw entity id, legacy
        # negative chat id) so a live event is never silently unmatched - an
        # unmatched event is exactly "the source posted, we didn't".
        entry = source_map.get(event.chat_id) or source_map.get(raw_chat_id(event.chat_id))
        if not entry:
            return
        try:
            source, _ = entry
            msg = event.message
            if not source_message_is_current(source, msg):
                return
            raw = (msg.message or msg.text or "") if msg is not None else ""
            has_media = bool(
                msg is not None and msg.media is not None and
                not isinstance(msg.media, (MessageMediaWebPage, MessageMediaInvoice))
            )
            added = await store.enqueue(event.chat_id, event.message.id, source, raw, has_media)
            global LAST_INGEST_AT
            LAST_INGEST_AT = time.time()
            if added:
                queue_id = await store.queue_id_for(event.chat_id, event.message.id)
                log.info("QUEUED | queue=%s priority=%s media=%s source=%s chat=%s msg=%s",
                         queue_id, classify_priority(raw, has_media), has_media, source,
                         event.chat_id, event.message.id)
            else:
                log.info("INGEST DUP | source=%s chat=%s msg=%s (already queued/posted)",
                         source, event.chat_id, event.message.id)
        except Exception as exc:
            # Never let one bad event die silently — a lost event means a lost
            # deal, so make the failure loud (the rescan loop still recovers it).
            log.error("INGEST FAIL source=%s chat=%s msg=%s: %s",
                      entry[0], event.chat_id,
                      event.message.id if event.message is not None else "?", exc)

    @client.on(events.MessageEdited())
    async def on_message_edited(event):
        """An edit of a source post must not be lost (see revive_edited_job)."""
        entry = source_map.get(event.chat_id) or source_map.get(raw_chat_id(event.chat_id))
        if not entry or not source_message_is_current(entry[0], event.message):
            return
        try:
            outcome = await store.revive_edited_job(raw_chat_id(event.chat_id), event.message.id)
            if outcome == "revived":
                log.info("EDIT REVIVE | source=%s msg=%s re-queued (no target had it yet)",
                         entry[0], event.message.id)
        except Exception as exc:
            log.error("EDIT FAIL source=%s chat=%s msg=%s: %s", entry[0], event.chat_id,
                      event.message.id if event.message is not None else "?", exc)

    async def worker(index: int):
        # NEVER-DIE worker: any unexpected error (SQLite busy, disk hiccup,
        # transient bug) is logged and the loop continues. A dead worker task
        # would silently stop all posting while the process still looks alive.
        while not stop.is_set():
            # Night quiet window (02:00-06:00 IST): pause TARGET posting only.
            # Nothing is claimed, so every night deal stays safely queued and
            # goes out the moment the window ends.
            if in_post_quiet():
                try:
                    # Short poll, so posting restarts within seconds of 06:00
                    # instead of idling a full minute on top of the window.
                    await asyncio.wait_for(stop.wait(), timeout=15)
                except asyncio.TimeoutError:
                    pass
                continue
            try:
                row = await store.claim_job()
            except Exception as exc:
                log.warning("WORKER %s claim failed (retrying): %s", index, exc)
                try:
                    await asyncio.wait_for(stop.wait(), timeout=5)
                except asyncio.TimeoutError:
                    pass
                continue
            if not row:
                await idle_wait(stop)
                continue
            # USER RULE: a deal that arrived during 02:00-06:00 is DEAD by
            # 06:00 (loot prices do not survive) — skip it, never post it
            # late. Only multi-product LISTS (3+ links) earn the morning slot.
            if born_in_post_quiet(row["created_at"]) and not in_post_quiet():
                url_count = len(URL_RE.findall(row["rendered_text"] or "")) if row["rendered_text"] else 0
                if url_count < 3:
                    with contextlib.suppress(Exception):
                        msg_probe = await client.get_messages(row["chat_id"], ids=row["msg_id"])
                        if msg_probe:
                            url_count = len(extract_urls(msg_probe))
                if url_count < 3:
                    log.info("NIGHT SKIP | queue=%s source=%s (born in quiet window; lists only after 06:00)",
                             row["id"], row["source"])
                    await store.mark_done(row["id"], "night-born deal expired by 06:00 (lists only)")
                    continue
            try:
                await process_job(client, affiliate, target_map, row)
            except Exception as exc:  # process_job catches its own errors; belt & braces
                log.exception("WORKER %s crashed on job %s (continuing): %s", index, row["id"], exc)

    workers = [asyncio.create_task(worker(i)) for i in range(QUEUE_WORKERS)]
    # Independent task; access/config failures never stop normal posting workers.
    dashboard_reload_task = asyncio.create_task(dashboard_live_loop(client, source_map, target_map, stop))
    # The channel picker's source of truth: what this session can actually read.
    directory_task = asyncio.create_task(channel_directory_loop(client, stop, target_map))
    source_refresh_task = asyncio.create_task(refresh_missing_sources(client, source_map, stop, target_map))
    source_rescan_task = asyncio.create_task(source_rescan_loop(client, source_map, stop))
    maintenance_task = asyncio.create_task(maintenance_loop(stop))
    await stop.wait()
    # Allow pending workers a brief graceful drain; queue remains durable if interrupted.
    try:
        await asyncio.wait_for(asyncio.gather(*workers), timeout=30)
    except asyncio.TimeoutError:
        for worker_task in workers:
            worker_task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await source_refresh_task
    with contextlib.suppress(asyncio.CancelledError):
        await source_rescan_task
    with contextlib.suppress(asyncio.CancelledError):
        await maintenance_task
    with contextlib.suppress(asyncio.CancelledError):
        await directory_task
    with contextlib.suppress(asyncio.CancelledError):
        await dashboard_reload_task
    await client.disconnect()
    await session.close()
    store.conn.close()
    log.info("Shutdown complete")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
